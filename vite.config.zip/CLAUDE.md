# SnugWeek - Project Context

This file is auto-loaded by Claude Code at the start of every session. Detailed specifications live in `docs/`.

## Project

**SnugWeek** - a cozy weekly planner-journal: notebook-style week spread (task columns per day), sidebar backlog lists, drag-and-drop planning, day trackers (mood/energy/custom), habit grid, week note, page-fold week navigation, month overview, monthly/yearly stats, multiple cozy color themes. Offline-first with automatic sync; anonymous-first accounts with later linking. Default UI language: Ukrainian.

**Target platforms (v1):** responsive web (desktop + mobile layouts in MVP), installable PWA. Hosting: Vercel.

## Documentation

- **`docs/DESIGN.md`** - full v1 technical design: architecture, data model, core algorithms (carry-over, ordering, account merge), theming, transitions, project structure. Source of truth for any architectural question.
- **`docs/phase-N-plan.md`** - per-phase task breakdowns with step-by-step instructions and acceptance criteria. Phases 1–8; the active file is the current phase's plan.

Read these on demand. Do not summarize them into this file.

## Tech Stack (locked, do not propose alternatives)

- Build: Vite 8 + TypeScript 6
- UI: React 19 + Mantine 9 (+ @mantine/dates, @mantine/notifications; @mantine/charts in Phase 6) - no emotion
- State: Zustand 5
- Backend: Firebase 12 (Firestore with `persistentLocalCache` multi-tab + Auth, anonymous-first)
- DnD: @dnd-kit/core + @dnd-kit/sortable
- Animation: Motion (`motion/react`)
- Routing: react-router 7
- Dates: dayjs (plugins: isoWeek, localeData, customParseFormat) - only via `src/services/time.ts`
- i18n: i18next + react-i18next (en source, uk default)
- Fonts: @fontsource/nunito, @fontsource/caveat
- Package manager: **npm** (do not use pnpm or yarn)

## Architecture (one-line)

Pages read Zustand stores via hooks; stores mirror Firestore `onSnapshot` feeds and call repos for writes; repos (`src/services/repos/`) own all Firestore IO; Firestore's latency compensation makes every write appear instantly and work offline.

## Strict Conventions

- TypeScript `strict: true` and `noUncheckedIndexedAccess: true`. **No `any` type ever.** Use `unknown` and narrow.
- **Mantine only** for UI. No raw hand-styled `<button>`, no additional UI libs, no Tailwind.
- **No external icon libraries.** Inline SVG or emoji.
- **No comments in code.** No JSDoc, no inline comments, no commented-out code - naming must carry meaning. No exceptions.
- **React components are arrow consts with named exports.** No `function` declarations, no default exports (router lazy imports adapt via `lazy(() => import(...).then(m => ({ default: m.X })))`).
- **`erasableSyntaxOnly: true`.** No `enum`, `namespace`, TS `module`, or constructor parameter properties.
- **Zustand stores in `src/state/` only.** No React Context for cross-cutting state (Mantine providers excepted). Persisted stores wrap `devtools(persist(...))`, carry `version` + `migrate`, and `partialize` actions out of localStorage.
- **Components never import `firebase/*`.** All Firestore IO in `src/services/repos/*`; stores own snapshot subscriptions.
- **No manual optimistic-update state.** Rely on Firestore latency compensation; UI updates arrive via the same snapshot path as remote changes.
- **Everything must work offline.** Never gate UI on a network round-trip; never `await` a write before updating what the user sees.
- **Dates/weeks only through `src/services/time.ts`.** No direct `dayjs` imports elsewhere. Week ids are ISO `YYYY-W##` (zero-padded, Monday-first); days are ISO numbers 1–7.
- **Zero hardcoded colors/fonts in components.** Only `--sw-*` CSS tokens or Mantine theme values. Themes are data files in `src/data/themes/`; applying = `data-snug-theme` attr + Mantine override. New theme = data + var block, zero component changes.
- **Task ordering is a fractional `order: number`** via `services/ordering.ts` (midpoints, renormalize below 1e-6 gap). Never persist array indexes.
- **Tasks use flat location fields** (`bucket`/`weekId`/`day`/`listId`), kept mutually consistent. Carry-over and DnD are `order` + location updates, never copy-delete.
- **Week docs are lazy.** A missing `weeks/{weekId}` doc renders as defaults; first write creates it. Tracker/habit writes use dotted-path `updateDoc` for field-wise merging.
- **All user-visible strings via i18n** (`t('ns:key')`). en is the source; uk is hand-authored (default language, must read natively - no machine translation).
- **Responsive = same components, different arrangement.** `DayColumn` is shared; layout is decided at page level. No `isMobile` branches inside leaf components.
- **One responsibility per file.**
- **No premature abstractions.** Build interfaces when there are 2+ implementations, not earlier (the transition registry is the deliberate exception - `curl` is a planned second implementation).
- **Firebase web config via `VITE_FIREBASE_*` env vars,** never committed. `.env.local` stays out of git.
- **Module visibility only via `profile.moduleToggles`** (dayTrackers / habits / weekNote).

## Current Phase

**Phase 1 - Foundation. Not started.** Follow `docs/phase-1-plan.md` task by task; stop after each task's acceptance criteria pass.

## Working Mode

- **Prose with the user:** Russian. Code, commit messages, file names: English. UI strings: Ukrainian (uk) + English (en) locale files.
- **One clarifying question is better than guessing.** If a task is ambiguous, ask before coding.
- **Show before run:** before destructive commands (rm, force push, dependency changes), show the command and wait for confirmation.
- **Never commit or push - the user does all git himself.** Leave changes staged; aim for one clean commit per task. Show diffs before making changes.

## Owner

Bohdan. Solo developer. Strong at execution and polishing, prefers concrete tasks over open brainstorming. When in doubt, propose 2–3 specific options rather than asking open-ended questions.
