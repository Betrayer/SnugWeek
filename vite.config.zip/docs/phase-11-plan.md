# SnugWeek - Phase 11: Themes & Texture

**Goal:** more ways to make the notebook *yours* - five new palettes including a crisp minimal white and a black-and-white monochrome (light + dark), a picker reorganized into cozy groups, optional subtle paper textures, and an optional "follow system" light/dark mode. Pure data on the v1 token system: adding themes touches no components.

**Duration:** ~1 week part-time (~12 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §3. Best done after Phase 9 (the boot-splash theme map).

---

## Definition of Done

- [ ] Ten themes available total: existing `milk`, `lavender`, `sage`, `peach`, `midnight` + new `snow`, `mono`, `noir`, `sky`, `cocoa`
- [ ] `snow` reads as clean minimal white; `mono` is light greyscale with a near-neutral accent; `noir` is a dark greyscale; `sky` and `cocoa` are new cozy colored options
- [ ] Every theme passes a contrast check (body text ≥ 4.5:1 on paper; accent-ink legible on accent); the two dark themes render Mantine inputs/popovers/modals in dark scheme with no light flashes
- [ ] Settings → Тема groups themes under labelled headings (e.g. Світлі / Кольорові / Мінімал / Темні) with live mini-previews; selecting applies instantly and syncs across devices
- [ ] (If shipped) an "Авто - за системою" option follows `prefers-color-scheme`, switching between a chosen light and dark theme live when the OS toggles
- [ ] Optional paper texture: a settings toggle applies a subtle, readable texture per theme (default off); contrast still passes with it on
- [ ] No component changes were needed; a grep confirms zero new hardcoded colors; all new theme labels exist in en + uk
- [ ] Build, lint, `tsc -b` clean; the boot-splash inline theme map (Phase 9) includes the new ids so there's no flash on the new dark themes

**Out of scope:** user-authored custom themes, seasonal/auto-rotating themes, per-surface theming.

---

## Task Breakdown

### Task 1: Author the Five Palettes (4h)

**Steps:**

1. Create `src/data/themes/{snow,mono,noir,sky,cocoa}.ts`, each a full `ThemeSpec` mirroring the shape of `milk.ts` / `midnight.ts` (all `--sw-*` vars, `mantine` override, `preview`). Guidance:
   - `snow` (light): paper near-white (`#fcfcfb`-ish) with a barely-warm tint, soft grey lines, a single restrained accent (a muted slate-rose or soft denim) so it still feels cozy, not clinical. `--sw-shadow` very light.
   - `mono` (light): white paper, charcoal ink (`#2b2b2b`-ish), greyscale lines; **accent is a dark neutral grey** (no chroma) with light `accent-ink`; `--sw-done` a mid grey; keep `--sw-danger` faintly warm so destructive actions remain readable. Mantine `primaryColor` mapped to a grey tuple.
   - `noir` (dark): near-black paper (`#161616`-ish), light-grey ink, white/very-light accent, dark greyscale surfaces; tune `--sw-fold-shade` darker; Mantine `colors.dark` tuple like `midnight` but neutral.
   - `sky` (light): soft blue paper/highlight, deeper blue accent, cool but warm-balanced ink so text stays soft (avoid pure cold).
   - `cocoa` (light or "warm-dark" - choose light for variety): milky coffee paper, espresso ink, caramel accent; distinct from `milk`'s rose by being brown/gold-forward.
2. Add a matching block per theme to `src/styles/tokens.css` (`[data-snug-theme="snow"] { ... }` etc.), keeping the file hand-readable (one block per theme, same key order).
3. Register in `src/data/themes/registry.ts`: add to `THEMES`; update `THEME_ORDER`; `DEFAULT_THEME_ID` stays `milk`.
4. Update the **Phase 9 boot-splash inline id→paper map** in `index.html` to include `snow`, `mono`, `noir`, `sky`, `cocoa` paper colors (so a dark `noir` user gets no flash). Keep it in sync with the specs.

**Acceptance:**

- [ ] Toggling `data-snug-theme` in DevTools to each new id renders correctly before any picker work
- [ ] `noir` Mantine inputs/menus are dark; no light flash on reload with `noir` selected

### Task 2: Grouped Theme Picker (3h)

**Steps:**

1. Define a grouping structure (data, in `registry.ts` or a small `themeGroups.ts`): ordered groups with an i18n label key and member ids, e.g. `light: [milk, peach, sky, cocoa]`, `pastel: [lavender, sage]`, `minimal: [snow, mono]`, `dark: [midnight, noir]` (final grouping is a judgment call - keep ≤ 4 groups).
2. Update `ThemePicker.tsx` to render groups: a small Caveat/section label per group, then the existing preview cards. Preserve the live mini-preview cards (rendered from each spec's `preview`/vars) and the active ring; keep keyboard navigation and `aria` labels.
3. Localize group labels + any new theme display names (theme display names can be i18n keyed by id) in en + uk.

**Acceptance:**

- [ ] Picker shows labelled groups; all 10 cards preview correctly and apply on click; selection syncs to a second tab
- [ ] Picker remains fully themed and keyboard navigable

### Task 3 (optional): Follow-System Light/Dark (3h)

Drop this task if you'd rather keep theming purely manual - the phase stands without it.

**Steps:**

1. Profile: add optional `autoTheme: { light: string, dark: string } | null` (default `null`) to `profileRepo` normalize/defaults + a `setAutoTheme` writer; extend `profileStore` to mirror it.
2. Settings: an "Авто - за системою" control (e.g. a switch that, when on, reveals two small theme selects for the light and dark partners; defaults milk/midnight). Turning it on writes `autoTheme`; turning it off writes `null` and keeps the last manual `themeId`.
3. `Root.tsx` resolution: if `autoTheme` is non-null, choose `light`/`dark` by a `matchMedia("(prefers-color-scheme: dark)")` listener (resolve live on change); otherwise use `themeId` as today. Keep the boot-splash inline script honoring system preference when the cached value indicates auto (store e.g. `snugweek-theme = "auto:milk:midnight"` so the inline script can pick by `matchMedia` pre-paint).

**Acceptance:**

- [ ] With auto on, toggling the OS dark mode switches themes live; with auto off, behavior is unchanged
- [ ] No flash on cold start in either system mode

### Task 4 (optional): Paper Texture (2h)

Also droppable; the phase stands without it.

**Steps:**

1. Source 2–4 tasteful, very low-contrast paper textures (subtle grain/linen), as small data-URIs or files in `public/textures/`; pick values per theme so each stays readable (light textures on light paper, etc.).
2. Wire the existing `--sw-paper-texture` token: set it per theme block in `tokens.css` to the chosen texture, but only apply when enabled. Approach: gate via a `data-paper-texture="on"` attribute on `<html>` (set from `profile.paperTextureEnabled`), with the textured value living under `[data-paper-texture="on"][data-snug-theme="..."]` and `none` otherwise.
3. Profile: add `paperTextureEnabled: boolean` (default `false`) to `profileRepo` defaults/normalize + a setter; mirror in `profileStore`; a Settings switch under Appearance.
4. Re-run the contrast check with texture on for each theme.

**Acceptance:**

- [ ] Toggling the texture is subtle and readable in every theme; default is off; choice syncs
