# SnugWeek - Phase 9: Sensory Layer - Splash, Sound & Notifications

**Goal:** the app *feels* finished the instant it opens and reacts. A stable, flash-free splash and font load; gentle cozy sounds for page turns and task completion with a device-local volume control; and sparse, warm toast confirmations where they genuinely help.

**Duration:** ~1 week part-time (~16 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §2, §4, §6, §7.

---

## Definition of Done

- [ ] Cold load on a throttled connection paints the cozy paper + "SnugWeek" wordmark immediately, in the correct font, with **no font-swap flash** and **no light flash for dark-theme users**
- [ ] The splash transitions seamlessly into the app (same paper, same wordmark position); a gentle breathing animation plays during any auth/i18n wait and is disabled under reduced-motion
- [ ] Turning a week page plays a soft page-turn sound; completing a task plays a gentle check sound; adding/deleting a task plays a subtle pop/swoosh - all only when sound is enabled
- [ ] No sound on initial load, programmatic redirects, undo of a completion, or while the tab is hidden; rapid actions don't machine-gun
- [ ] Settings → Звук: enable switch + volume slider; moving the slider plays a quiet preview; both persist across reloads per device
- [ ] Sounds work after the first interaction on desktop and mobile (AudioContext unlock handled); muting the OS / browser is respected
- [ ] Cozy toasts appear for: carry-over moving ≥1 task, deleting a custom list, saving/linking an account, completing a merge - and **not** for adding a task, checking a box, editing, or switching theme/week
- [ ] All new strings exist in en + uk; build, lint, `tsc -b` clean; no console errors
- [ ] Sound assets are optional: with no `flip` asset present, page-turn falls back to a synthesized sound and nothing errors

**Out of scope:** reminder/notification *scheduling* (Phase 11), notification permission prompts (Phase 11), music/ambient loops, per-sound themes.

---

## Task Breakdown

### Task 1: Self-host Fonts & Preload (3h)

**Steps:**

1. Copy the five used faces from `@fontsource` into `public/fonts/` as stable files: `nunito-400.woff2`, `nunito-600.woff2`, `nunito-700.woff2`, `caveat-400.woff2`, `caveat-600.woff2` (latin + cyrillic subsets - keep the same coverage the app relies on; if subset files differ, include both latin and cyrillic woff2 and list both in `@font-face` `unicode-range`s or a combined file).
2. Replace the `@fontsource/*` `@import` lines in `src/styles/global.css` with explicit `@font-face` rules pointing at `/fonts/*.woff2`, `font-display: swap`, correct `font-weight`/`font-family`. Drop the `@fontsource` imports (keep the packages or remove from `package.json` if fully unused - verify nothing else imports them).
3. In `index.html` `<head>`, preload the splash-critical faces: `<link rel="preload" as="font" type="font/woff2" href="/fonts/caveat-600.woff2" crossorigin>` and the same for `nunito-400.woff2`.
4. Confirm the existing workbox `*.woff2` CacheFirst rule still matches the new same-origin paths (it does - pattern is by extension).

**Acceptance:**

- [ ] Network tab: the two critical woff2 load with high priority; no FOUT on the wordmark
- [ ] Repeat visit serves fonts from the SW cache (offline reload keeps fonts)

### Task 2: Flash-Free Boot Splash (3h)

**Steps:**

1. Put static splash markup **inside** `<div id="root">` in `index.html`: a centered wordmark (`font-family` = a Caveat-first stack so it upgrades cleanly) on a full-viewport box whose background is set from a CSS variable; minimal inline CSS in `<head>` (a tiny `<style>`), no external deps.
2. Add a small inline `<script>` in `<head>` (runs before paint): read `localStorage.getItem("snugweek-theme")`, validate against a hardcoded id list, set `document.documentElement.dataset.snugTheme`, and set the boot splash background to that theme's paper via a tiny inline id→paper map (milk/snow/.../midnight/noir). Unknown/missing → milk paper.
3. In `Root.tsx`, write through `localStorage.setItem("snugweek-theme", theme.id)` in the existing theme effect so the next cold start knows the theme. (Keep this a plain localStorage key, **not** part of `settingsStore`.)
4. React renders into `#root` and replaces the inline splash automatically; verify there's no double-splash flicker (the React `Splash` should match the inline one's layout).

**Acceptance:**

- [ ] First paint (JS disabled or very slow) shows themed paper + wordmark
- [ ] Switch to a dark theme, reload → boot splash is already dark, no white flash
- [ ] No visible jump when React takes over

### Task 3: Unify & Animate the React Splash (1h)

**Steps:**

1. Update the `Splash` component in `Root.tsx` to match the inline splash (same wordmark size/color/position).
2. Add a gentle breathing opacity/scale loop via Motion (`m.div`, e.g. opacity 0.7↔1 over ~1.6s, `easeInOut`, infinite), gated off when `reduceMotion` or `prefers-reduced-motion`.
3. Keep `AuthErrorScreen` and `PageFallback` visually consistent (paper + accent loader already fine).

**Acceptance:**

- [ ] Artificially delay auth/i18n → the breathing splash reads as calm and intentional; reduced-motion shows a static splash

### Task 4: Sound Service (4h)

**Steps:**

1. Create `src/services/sound/soundService.ts` (Web Audio only, no dependency):
   - Lazy `AudioContext`; a one-time `pointerdown`/`keydown` listener (installed from `Root` on mount) calls `resume()` to satisfy autoplay policy and marks the context unlocked.
   - A master `GainNode`; `setVolume(v)` and reads `useSettingsStore.getState()` for `soundEnabled`/`soundVolume` at call time.
   - Exports `playFlip()`, `playCheck()`, `playPop()`, `playSwoosh()`. Each: no-op if disabled, `document.hidden`, or context not unlocked; a per-sound throttle (e.g. min 60–120 ms between same-sound plays).
   - Synthesized envelopes for `check` (soft two-note blip), `pop`, `swoosh` (oscillator + gain ramp, ~80–160 ms, low velocity).
2. `flip` sampling with graceful fallback:
   - On unlock, attempt to fetch + `decodeAudioData` `public/sounds/flip.webm` (or `.mp3` chosen via a `canPlayType`-style check); cache the `AudioBuffer`. If the asset is missing or decode fails, `playFlip()` falls back to `playSwoosh()`.
   - Add `public/sounds/.gitkeep` and document the expected files; the build must not fail when they're absent.
3. Wire `settingsStore`: bump `version` to `3`, add `soundEnabled` (default `true`) + `soundVolume` (default `0.6`) to `PersistedSettings`, setters, and `partialize`; `migrate` spreads `defaultSettings` then stored.

**Acceptance:**

- [ ] First click/tap unlocks audio; subsequent sounds play; `document.hidden` silences them
- [ ] With no asset files, page-turn still produces a sound and there are no console errors
- [ ] Disabling sound in settings silences everything immediately

### Task 5: Wire Sound Hooks + Settings UI (2h)

**Steps:**

1. `playFlip()` in the **user-initiated** navigation handlers only: `WeekNav` arrow clicks, `WeekJumpPopover`/`WeekJumpCalendar` date pick, and the `Alt+←/→` keyboard handler. Do **not** call it from any route loader or the transition host effect.
2. `playCheck()` in `weekStore.toggleDone` and the list-task toggle path, only on the `open → done` edge (guard with the prior status). `playPop()` on task create (composer submit), `playSwoosh()` on task delete.
3. Settings → Звук section: a `Switch` bound to `soundEnabled` and a `Slider` (0–100 → 0..1) bound to `soundVolume`; on slider change-end, call `setVolume` then `playPop()` as a preview. Tokens only; localized labels.

**Acceptance:**

- [ ] Page turn, complete, add, delete each play the intended sound; undo is silent; initial load is silent
- [ ] Volume slider preview works; setting persists

### Task 6: Notifications Policy (3h)

**Steps:**

1. Create `src/services/notify.ts`: a thin wrapper over `@mantine/notifications` `notifications.show` with cozy defaults (soft, `withBorder`, accent border, autoClose ~3.5 s), a short de-dupe (ignore identical message within ~3 s), and a single place for tone. Export small helpers like `notifyInfo(messageKey, vars?)` / `notifySuccess(...)` that resolve i18n keys.
2. Apply at the right call sites (and **remove** any redundant ad-hoc toasts):
   - Carry-over: when `runCarryOver` actually moves ≥1 task, `notifyInfo("common:carriedToast", { count })`. (Pass the moved count back from the engine.)
   - Custom list delete (`deleteListAndRehomeTasks`): `notifyInfo("tasks:listDeletedToast")`.
   - Account saved/linked (`linkGoogle`/`linkEmail` success): `notifySuccess("auth:accountSavedToast")`.
   - Merge complete (existing flow): `notifySuccess("auth:mergeDoneToast")` (replace/augment the current message).
3. Audit: confirm **no** toast fires for add-task, toggle-done, rename, theme switch, or week navigation.
4. Add all keys to en + uk namespaces with cozy wording.

**Acceptance:**

- [ ] Each listed event shows exactly one cozy toast; the excluded actions show none
- [ ] i18n missing-key warnings = zero in both languages
