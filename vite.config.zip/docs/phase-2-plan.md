# SnugWeek - Phase 2: Tasks, Lists & Drag-and-Drop

**Goal:** the planner becomes usable: full task lifecycle in day columns and sidebar lists, default + custom lists, complete/edit/delete, and drag-and-drop everywhere on desktop with honest mobile equivalents.

**Duration:** ~2 weeks part-time (~30 h)
**Phase end criterion:** Definition of Done passes 100%.

---

## Definition of Done

- [ ] Add a task to any day via the column composer; Enter adds and keeps the composer focused for chained entry
- [ ] Add tasks to "Задачі" and "Ідеї та мрії"; create a custom list, rename it, delete it (its tasks move to "Задачі")
- [ ] Toggle done: round checkbox fills, title gets a soft strikethrough, `completedAt` set; untoggle reverts
- [ ] Inline edit a title (click → input → Enter/blur saves, Esc cancels); delete via the card menu
- [ ] Desktop DnD: reorder within a day, move day↔day, sidebar→day, day→sidebar, list↔list - order persists after reload in every case
- [ ] Drag overlay shows a slightly tilted cozy card; drop targets show an insertion line; edge autoscroll works in long columns and in the sidebar
- [ ] Mobile: long-press reorders within a list; the card menu "Перемістити…" moves a task to any day or list; day dots show open-task counts
- [ ] Keyboard DnD works (space to lift, arrows to move, space to drop)
- [ ] Everything above works offline and syncs cleanly afterwards
- [ ] Two tabs converge: dragging in one is reflected in the other
- [ ] Build, lint, tsc clean; no console errors

**Out of scope:** carry-over, transitions, month view, trackers/habits (Phase 3–4), task descriptions/due-times/labels (not in v1).

---

## Task Breakdown

### Task 1: Task & List Model, Repos, Ordering (4h)

**Steps:**

1. `npm i @dnd-kit/core @dnd-kit/sortable`.
2. `src/services/ordering.ts`: `orderForTop(items)`, `orderForBottom(items)`, `orderBetween(a, b)`, `needsRenormalize(items)` (gap < 1e-6), `renormalize(items)` → `[{id, order}]` for a batch write. Spacing constant 1024.
3. `src/services/repos/tasksRepo.ts`: `Task` type per DESIGN.md (flat `bucket`/`weekId`/`day`/`listId`); `createTask`, `updateTitle`, `setStatus` (sets/clears `completedAt`), `moveTask({ bucket, weekId, day, listId, order })`, `deleteTask`, `subscribeWeekTasks(uid, weekId, cb)` (`bucket=="day" && weekId==X`), `subscribeListTasks(uid, cb)` (`bucket=="list"`, one subscription for the whole sidebar, grouped client-side).
4. `src/services/repos/listsRepo.ts`: `ensureBuiltinLists(uid)` (idempotent `tasks`/`ideas` seed - call from `ensureProfile` flow), `createList`, `renameList`, `deleteListAndRehomeTasks(uid, listId)` (batch: tasks → `listId: "tasks"` at top, then delete the list doc), `subscribeLists`.
5. Create the composite indexes when Firestore's console links appear (expected set listed in DESIGN.md); note each in the task log.

**Acceptance:**

- [ ] Console-driven smoke (temporary dev page or browser console via store actions): create/move/complete/delete round-trip correctly
- [ ] Renormalize triggers after ~50 midpoint inserts between the same two neighbors and produces clean 1024-spaced orders

### Task 2: Stores for Tasks & Lists (3h)

**Steps:**

1. `src/state/weekStore.ts` extension: holds `tasksByDay: Record<number, Task[]>` (sorted by `order`), fed by `subscribeWeekTasks`; actions `addTask(day, title)`, `toggleDone(task)`, `renameTask`, `removeTask` - thin repo calls (no optimistic state, latency compensation covers it).
2. `src/state/listsStore.ts`: `lists: List[]`, `tasksByList: Record<string, Task[]>`; actions `addTask(listId, title)`, `addList(name)`, `renameList`, `removeList`.
3. `src/state/uiStore.ts`: `activeMobileDay`, `sidebarOpened` (mobile drawer), `dragging: { taskId } | null`.
4. Subscriptions start when auth is ready and (for week tasks) when `weekStore.open` runs; verify clean unsubscribe on week change (no listener leaks - log subscription count in dev).

**Acceptance:**

- [ ] Week switch via URL swaps task subscriptions without leaks
- [ ] Sidebar data lives independently of the open week

### Task 3: Task UI in Day Columns (4h)

**Steps:**

1. `TaskCard.tsx`: round custom checkbox (token-colored, animated check on toggle), title, hover/focus reveal of a kebab menu (Edit, Delete; "Перемістити…" added in Task 6). Done state: `--sw-done` tint + strikethrough.
2. `TaskComposer.tsx`: ghost "+ Додати" row → swaps to an input; Enter submits and refocuses; Esc/blur-empty collapses. Guard: trim, 1–500 chars, IME composition-safe Enter handling.
3. `TaskList.tsx`: renders a day's tasks; open above done (done sink to the bottom, each group ordered by `order`).
4. Wire into `DayColumn` for both desktop and mobile arrangements; empty day shows a faint Caveat hint ("вільний день").

**Acceptance:**

- [ ] Chained entry: type → Enter → type → Enter adds consecutive tasks at the bottom
- [ ] Toggling done reorders open-above-done without jumps on reload
- [ ] All states (hover, focus-visible, done) use tokens only

### Task 4: Sidebar Lists UI (4h)

**Steps:**

1. `ListsPanel.tsx` in the aside: sections per list ordered by `order`; builtin names from i18n (`tasks` → "Задачі", `ideas` → "Ідеї та мрії"), Caveat section headers.
2. `ListSection.tsx`: header (name, count, kebab: rename/delete for custom), its `TaskList` + `TaskComposer` (same components as days).
3. `AddListControl.tsx`: bottom ghost button → inline input.
4. Rename/delete dialogs via Mantine Modal; delete warns that tasks move to "Задачі".
5. Mobile: `Drawer` from a header button (lists icon with total open count); panel reused as-is. Sidebar scrolls independently when overflowing.

**Acceptance:**

- [ ] Custom list CRUD round-trips; deletion verifiably re-homes tasks
- [ ] Builtin lists are not renamable/deletable
- [ ] Drawer UX comfortable on a phone viewport

### Task 5: Desktop Drag-and-Drop (6h)

**Steps:**

1. `DndContext` at `WeekPage` level wrapping board + sidebar. Sensors: `PointerSensor` (activationConstraint distance 6), `KeyboardSensor` (sortable coordinates).
2. Each day's `TaskList` and each `ListSection` is a `SortableContext` (vertical strategy); droppable ids encode the container (`day:3`, `list:ideas`) - a parse helper in one place.
3. Collision detection `closestCorners`; `onDragOver` handles container switching for live preview; `onDragEnd` computes the destination container + neighbor-based `orderBetween` and calls `moveTask` once.
4. `DragOverlay`: clone of `TaskCard` with ~2° tilt, lifted shadow, slight scale - Motion-free CSS is fine here.
5. Drop indicator line between cards (token accent), empty containers accept drops (min-height drop zones).
6. Autoscroll defaults verified for tall columns and the sidebar panel.
7. Moving a `done` task into a day keeps status (no implicit reopen).

**Acceptance:**

- [ ] Every DoD drag direction works and persists; rapid consecutive drags don't reorder wrongly (orders audited in console)
- [ ] Keyboard DnD passes (announce via `aria-live` defaults from dnd-kit)
- [ ] Dropping onto the original position is a no-op (no write issued)

### Task 6: Mobile Interactions (4h)

**Steps:**

1. Add `TouchSensor` (delay 220ms, tolerance 8) - long-press reorder within the current day list and within an open drawer list; page scroll preserved for normal swipes.
2. `MoveTaskMenu.tsx` from the card kebab: bottom-sheet style Modal - pick a destination: 7 day chips of the open week (labels + dates) or any list; moves to top of destination.
3. Day pager dots: open-task count badges; the drawer button shows the sidebar total.
4. Verify the pager swipe vs long-press don't fight (activation delay separates them).

**Acceptance:**

- [ ] On a real phone: reorder by long-press is reliable; accidental drags during scroll don't happen
- [ ] "Перемістити…" covers every cross-container move available on desktop DnD

### Task 7: Guards & Polish (3h)

**Steps:**

1. Error surface: repo write failures (rules rejection etc.) → Mantine notification ("не вдалося зберегти - спробуйте ще раз") + console detail; offline is NOT an error (writes queue silently).
2. Title length counter past 400 chars; paste-trim.
3. Empty states: empty sidebar list, fully empty week - short Caveat phrases (i18n).
4. Sweep: tab order through a day column is sane; all new strings exist in en+uk; no hex colors snuck in.

**Acceptance:**

- [ ] Forced rules failure (temporarily tighten a rule) produces the friendly notification and no broken state
- [ ] i18n key audit clean (`i18next` missing-key console warnings = zero in both languages)
