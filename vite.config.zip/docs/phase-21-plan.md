# SnugWeek - Phase 21: Onboarding & Guided Tour

**Goal:** welcome new users with a gentle guided tour - the "coach marks" pattern where the screen dims, a spotlight highlights an element, and a cozy bubble explains it ("ось тут ваш тиждень" → Далі → "а тут - налаштування") - plus a lightweight contextual-hint pattern so advanced features introduce themselves the first time they're opened. Built last, so it covers the finished feature set.

**Duration:** ~1 week part-time (~16 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §9. Built on Mantine primitives only (custom overlay + Popover), no tour library.

---

## Definition of Done

- [ ] On first run (after seeding), a gentle "Show me around?" prompt offers the tour; accepting runs it, declining dismisses it and it doesn't nag again
- [ ] The tour dims the screen with a spotlight cutout over the current target and shows a cozy bubble (title + body) with Back / Next / Skip and progress dots; it walks ~6–10 core steps, then ends warmly
- [ ] The tour is fully skippable at any step, keyboard-operable (arrows/enter/escape), and adapts to mobile (anchors to mobile elements / bottom bar; sheet-style bubble where needed)
- [ ] It can be re-run anytime from Settings → "Повторити тур"
- [ ] Advanced features (tags, attachments, reminders, decorations, focus, lock, sharing) show a **one-time contextual hint** the first time their surface is opened; each hint is dismissible and never repeats
- [ ] The tour and hints are robust to missing targets (skip a step whose element isn't present rather than breaking) and respect reduced-motion (no flashy transitions)
- [ ] Strings en + uk; build/lint/tsc clean; no console errors

**Out of scope:** branching/interactive tutorials, analytics on tour completion, video/animation walkthroughs, a tour authoring UI.

---

## Task Breakdown

### Task 1: Tour Engine (5h)

**Steps:**

1. `shell/components/tour/TourProvider.tsx` + a tiny ref-registry context: components register an anchor ref under a key (e.g. `useTourAnchor("week-board")`) without coupling to tour content. The provider holds the active step index and current target.
2. `Spotlight overlay`: a full-screen dimming layer with a cutout around the target's bounding rect (an SVG mask or four positioned panels), updating on scroll/resize; pointer-blocking except optionally the highlighted element.
3. `Bubble`: a Mantine `Popover`/floating card anchored to the target (paper + tokens, Caveat title), with Back / Next / Skip and progress dots; on mobile, a bottom sheet-style bubble when a popover would be cramped.
4. Robustness: if a step's target ref is absent, skip to the next; clamp the bubble within the viewport; reduced-motion disables transitions.

**Acceptance:**

- [ ] A throwaway 2–3 step tour highlights elements correctly on desktop + phone, navigates, skips missing targets, and respects reduced-motion

### Task 2: Core Tour Content (3h)

**Steps:**

1. Define the step registry (`data/tourSteps.ts`): ~6–10 steps over the core - week board, the add affordance, the Task Detail surface, drag-and-drop, sidebar lists, day trackers + habits, the week note, month overview, stats, themes/settings. Each step: `{ id, anchorKey, title, body, placement, mobileOnly?/desktopOnly? }` with cozy localized copy.
2. Register the anchors in the relevant components (`useTourAnchor`) - minimal, non-invasive.
3. Order and copy tuned so it flows as a calm walk, not a lecture; keep bodies short.

**Acceptance:**

- [ ] The core tour runs end-to-end on desktop + phone, each step lands on the right element with sensible placement

### Task 3: Trigger, Re-run & First-Run Wiring (2h)

**Steps:**

1. First-run: after seeding completes (the existing fresh-account path), show a gentle prompt ("Показати, як усе влаштовано?") gated by the device-local `tourSeen` flag (§2); accept → run; either outcome sets `tourSeen = true`.
2. Settings → Про застосунок (or Вигляд): a "Повторити тур" action that resets the run and starts it.
3. Ensure the tour waits for the app to be ready (data loaded) so anchors exist.

**Acceptance:**

- [ ] New accounts get the prompt once; re-run works; an existing user is never surprised by it

### Task 4: Contextual Hints (3h)

**Steps:**

1. `shell/components/tour/Hint.tsx`: a one-time themed `Popover` shown the first time a given feature surface opens, tracked by per-feature localStorage flags (e.g. `snugweek-hint-tags`). Dismissible ("Зрозуміло"), never repeats; reduced-motion-safe.
2. Register hints in the features that shipped earlier: tags, attachments, reminders, decorations, focus timer, lock, sharing - each a short, friendly one-liner pointing at the key control.
3. A way to reset all hints (alongside "Повторити тур") for users who want the guidance again.

**Acceptance:**

- [ ] Each feature shows its hint exactly once on first open; resetting brings them back; none nag

### Task 5: i18n, A11y & Sweep (3h)

**Steps:**

1. en + uk for all tour steps, hints, prompts, and buttons.
2. A11y: the tour bubble is focus-trapped with a clear reading order, controls labelled, escape skips; the overlay announces context to screen readers; hints are dismissible by keyboard.
3. Real-phone test of the full tour + a couple of hints; verify robustness when a feature/module is toggled off (skip its step/hint); token/contrast sweep in light + dark.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; tour and hints are calm, skippable, and never nag; i18n missing-key warnings zero
