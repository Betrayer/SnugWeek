# SnugWeek - Phase 12: Tasks Deepened - Subtasks & Tags

**Goal:** two of the most-requested planner depth features - checklists *inside* a task, and colored tags for organizing and filtering - both living in the Phase 10 Task Detail surface and showing as calm indicators on the card.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §1, §8. Depends on Phase 10 (Task Detail, ActionMenu).

---

## Definition of Done

- [ ] A task can hold a checklist of sub-items (add, rename, check, reorder, delete) inside its detail surface; the card shows a small progress pill ("2/5") when sub-items exist
- [ ] Checking a sub-item updates the progress instantly and persists; completing all sub-items does **not** auto-complete the parent (the parent stays user-controlled) but is reflected in the pill
- [ ] Tags can be created (name + a curated color), renamed, recolored, reordered, and deleted (deleting a tag removes it from all tasks)
- [ ] A task can be given/removed tags in its detail; the card shows small tag dots/chips
- [ ] A week (and a list) can be filtered by one or more tags; clearing the filter restores the full view; the filter state is obvious and easy to clear
- [ ] All of it works offline and syncs; two tabs converge; counts/dots stay correct
- [ ] Tag colors read well in all 10 themes (incl. mono/noir); strings en + uk; build/lint/tsc clean; no console errors

**Out of scope:** nested sub-subtasks, per-subtask due times, tag-based smart lists/saved filters (could be a later nicety), tag colors as freeform hex.

---

## Task Breakdown

### Task 1: Subtasks Model & Repo (4h)

**Steps:**

1. `users/{uid}/tasks/{taskId}/items/{itemId}` subcollection per addendum §1 (`title`, `done`, `order`, `createdAt`). Add `services/repos/subtasksRepo.ts`: `subscribeSubtasks(uid, taskId, cb)`, `createSubtask`, `renameSubtask`, `toggleSubtask`, `deleteSubtask`, `reorderSubtasks` (uses `services/ordering.ts`).
2. Maintain denormalized `subtaskCount` + `subtaskDone` on the parent task **in the same `writeBatch`** as each add/remove/toggle. Extend `normalizeTask` (defaults `0`).
3. `firestore.rules`: validate item shape + a sane cap on count; allow the parent's count fields as numbers `>= 0`.

**Acceptance:**

- [ ] Add/check/reorder/delete round-trip offline; parent counters always match the item set; cap enforced

### Task 2: Subtasks UI (4h)

**Steps:**

1. In `TaskDetail` (Phase 10), fill the Subtasks slot: a compact checklist - round checkboxes (reuse the card's check style + sound `playCheck` on complete), inline add row (chained Enter), inline rename, delete, and drag-reorder via dnd-kit sortable within the detail.
2. Card indicator: a small "2/5" progress pill (token-styled, near the title) shown only when `subtaskCount > 0`; subtle ring/fill optional.
3. Mobile: the checklist sits in the bottom-sheet detail with large targets.

**Acceptance:**

- [ ] Editing sub-items is smooth on desktop + phone; the card pill updates live; completing all does not toggle the parent

### Task 3: Tags Model & Repo (4h)

**Steps:**

1. `users/{uid}/tags/{tagId}` per addendum §1 (`name`, `color`, `order`, `createdAt`), where `color` is an id into a **curated palette** defined in `data/tagColors.ts` (8–12 swatches chosen to sit well on every theme's paper; each maps to a token-aligned value). `services/repos/tagsRepo.ts`: CRUD + `subscribeTags`.
2. Task tagging: `tagIds: string[]` on the task (default `[]`, extend `normalizeTask`); `addTagToTask` / `removeTagFromTask` writers (array union/remove). Deleting a tag also strips it from tasks (batched query `tagIds array-contains <id>` → remove). Add the `array-contains` index.
3. `tagsStore.ts`: mirror definitions; small helper to resolve id → swatch.

**Acceptance:**

- [ ] Tag CRUD round-trips; deleting a tag removes it everywhere; offline-safe

### Task 4: Tag UI & Filtering (5h)

**Steps:**

1. Tag management UI: a section in Settings → (its own "Мітки" area) to create/rename/recolor/reorder/delete tags using the curated swatch picker (no freeform color).
2. Task tagging in `TaskDetail`: a tag selector (chips with swatches, multi-select); card shows up to N small tag dots/chips with overflow "+k".
3. Filtering: a filter control (in the header overflow or a sidebar/week toolbar) to select one or more tags; the week board + lists show only matching tasks; a clear, dismissible "filtered by …" indicator. Filter is client-side over loaded tasks (optionally an `array-contains-any` query for lists). Filter state in `uiStore` (not persisted, or device-local if you want it to stick).
4. Ensure DnD + composer still behave under an active filter (adding a task while filtered should still appear sensibly - e.g. auto-apply the active tag, or surface it; pick one and document).

**Acceptance:**

- [ ] Filtering by tag works on week + lists and is easy to clear; dots read well in all themes; adding under a filter behaves predictably

### Task 5: i18n, A11y & Sweep (3h)

**Steps:**

1. en + uk for all new strings (subtask add/empty, tag management, filter labels).
2. A11y: checklist and tag selector keyboard-operable; tag dots have accessible names; filter state announced.
3. Token/contrast sweep for swatches across themes; real-phone test of subtasks + tagging + filtering; offline verification.

**Acceptance:**

- [ ] Full DoD passes on desktop + phone, light + dark; i18n missing-key warnings zero
