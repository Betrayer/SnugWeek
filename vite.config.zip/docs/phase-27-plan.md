# SnugWeek — Phase 27: Stickers Expansion & Authoring

**Goal:** many more stickers in the current cozy style, a dead-simple file-drop way to keep adding them, and a palette that stays usable at scale.

**Duration:** ~1 week part-time (~16 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `data/decorations.tsx`, `DecorationPalette.tsx`.

---

## Definition of Done

- [ ] The built-in decoration set grows substantially (dozens of new stickers across cozy categories) in the existing inline-SVG style; all tint correctly across the 10 themes; placement and animation unchanged
- [ ] A file-drop authoring path exists: dropping a conforming SVG into a folder makes it appear in the palette with no component changes, supporting both tintable (single-color) and as-is colorful SVGs
- [ ] `docs/STICKERS.md` documents the workflow: format, where to put it, how to name it, sizes, colors, and the animated flag, with a copy-paste template
- [ ] The palette stays browsable with the larger set (category tabs/scroll + a filter) on desktop + mobile
- [ ] Strings en + uk; build/lint/tsc clean

**Out of scope:** end-user sticker uploads (that's the attachments/storage path), animated multi-frame stickers.

---

## Task Breakdown

### Task 1: Expand The Built-In Set (6h)

**Steps:**

1. Add a large batch of new `DecorationAsset` entries in `data/decorations.tsx`, same shape and token tints, across cozy categories: animals, food/drinks, plants, weather, celestial, hearts/sparkles, seasonal, tiny scenes. Keep the flat/geometric style consistent with the current set.
2. Assign sensible `tint`, `w/h/viewBox`, and the `animated` flag per asset; group by `kind`.

**Acceptance:**

- [ ] The palette grows substantially; new stickers tint correctly in every theme; placement/animation behave as before

### Task 2: File-Drop Authoring Path (5h)

**Steps:**

1. Add a `public/stickers/` (or `src/data/stickers/`) convention auto-registered via `import.meta.glob`, merged into the decoration registry alongside the inline set.
2. Support two kinds by convention: **tintable** SVGs (use `currentColor`, themed via tokens) and **as-is** colorful SVGs (rendered unmodified); infer kind from a filename suffix or a folder.
3. Normalize sizing from the SVG `viewBox` so dropped files place consistently.

**Acceptance:**

- [ ] Dropping a conforming SVG into the folder makes it appear in the palette with no code changes; both tintable and colorful render correctly

### Task 3: Authoring Guide `docs/STICKERS.md` (2h)

**Steps:**

1. Write `docs/STICKERS.md`: **format** (SVG, single vs multi-path, `currentColor` for tintable), **where** (the folder), **naming** (filename/id → category and label), **sizes** (recommended w/h + viewBox conventions), **colors** (token tints vs fixed), **animated** flag — with a copy-paste template and one tintable + one colorful example.

**Acceptance:**

- [ ] The guide is followable by you or a designer to add a sticker without touching component logic

### Task 4: Palette UX At Scale (3h)

**Steps:**

1. Add light category tabs (or grouped scroll) and a name/category filter to `DecorationPalette.tsx` so the larger set stays easy to browse; keep the target (week/day) selector.
2. Verify usability on desktop + mobile (the responsive dialog).

**Acceptance:**

- [ ] Browsing dozens of stickers stays quick and tidy on both layouts
