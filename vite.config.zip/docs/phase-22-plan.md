# SnugWeek — Phase 22: Refactor, Load & Splash/Cover

**Goal:** pay down code duplication, make the first paint seamless with no font pop, and surface the notebook cover so it reads as intentional.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `CLAUDE.md`, `docs/design-addendum.md` §6.

---

## Definition of Done

- [ ] Throttled cold load in Ukrainian shows the real fonts immediately — no fallback→real swap, no reflow when React replaces the boot splash; dark themes stay flash-free
- [ ] The pill/chip styles and the repeated Mantine field styles are collapsed to single shared sources; a grep confirms the old duplicates are gone; visuals unchanged
- [ ] Repeated inline SVG glyphs and the repeated card-surface style are deduplicated into shared modules/helpers, tokens-only, with no visual regressions
- [ ] The notebook cover is clearly visible at launch (cover paints during load, then a short reveal into the week) and reads as intentional on desktop + mobile, with no added load delay
- [ ] Build, lint, `tsc -b` clean; no behavior change beyond the above

**Out of scope:** new themes, new cover styles, font-choice UI (Phase 26), any feature work.

---

## Task Breakdown

### Task 1: Font Load — Kill the Pop (4h)

**Steps:**

1. In `index.html`, add `<link rel="preload">` for the Cyrillic splash-critical subsets (`nunito-cyrillic-400`, `caveat-cyrillic-600`) alongside the existing latin preloads, so the first Ukrainian text and a Cyrillic notebook name paint in the real font.
2. In `global.css`, switch the splash-critical faces (Nunito 400, Caveat 600 — latin + cyrillic) to `font-display: optional` (fall back permanently rather than swap mid-view; with preload they'll be ready) — keep `swap` for non-critical weights.
3. Make the React `Splash` in `Root.tsx` pixel-match `#sw-boot` (same family, size, weight, color) so the hand-off from boot splash to React causes no reflow.

**Acceptance:**

- [ ] DevTools throttled cold load (uk, light and a dark theme): real fonts on first paint, no swap, no jump when React mounts

### Task 2: Shared Primitives — Chips & Fields (5h)

**Steps:**

1. Create one `Pill` component (icon slot + label + tone variants: `accent` / `accent-2` / `muted` / `done`) and replace the four near-identical pills in `TaskCard.tsx` (`TimeChip`, `AttachmentChip`, `RepeatChip`, the `carriedFrom` chip) plus any others with the same `borderRadius: 999` pattern.
2. Extract the repeated Mantine `fieldStyles` object (in `TaskTimeReminder.tsx`, `RoutinesSection.tsx`, and other forms) into one exported `fieldStyles` / `useFieldStyles` and use it everywhere.

**Acceptance:**

- [ ] Grep for the duplicated pill markup and `fieldStyles` returns one source each; chips and form fields look identical to before

### Task 3: Shared Primitives — Glyphs & Surfaces (5h)

**Steps:**

1. Consolidate repeated inline SVG icons into one `icons/` module (extend existing icon files); replace inline copies across the shell.
2. Extract the repeated "card surface" style (day column / card / sheet backgrounds) into one helper or CSS class, tokens-only; apply it where the same block is currently inlined.

**Acceptance:**

- [ ] Icon and surface duplication reduced to shared sources; no visual regressions in any theme

### Task 4: Cover / Splash (5h)

**Steps:**

1. Cover paints during load: write a `snugweek-cover` localStorage hint (same pattern as the `snugweek-theme` hint), read it in the `index.html` inline script, and paint the chosen cover behind `#sw-boot`.
2. Add a short, reduced-motion-aware "open the notebook" reveal from the cover into the week board on first mount (a gentle fold/fade), driven by `profile.coverStyle` via `data/covers.ts`.
3. Keep the in-app cover frame behind the board consistent with the new launch treatment.

**Acceptance:**

- [ ] The selected cover is visible at launch and transitions into the week without delay; reduced-motion shows an instant, non-jarring switch; works on desktop + mobile

### Task 5: General Fixes Sweep (3h)

**Steps:**

1. Low-risk correctness/cleanup found during the refactor: dead props, stray `console`, inconsistent spacing constants, obvious small bugs.
2. Keep changes behavior-neutral beyond the above tasks.

**Acceptance:**

- [ ] Build/lint/tsc clean; quick regression of week/month/stats/settings shows no behavior change
