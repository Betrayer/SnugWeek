# SnugWeek - Phase 6: Statistics

**Goal:** the rewarding mirror: a stats page with month and year views - task completion dynamics, habit streaks and percentages, mood/energy trends, a year heatmap - built on cheap increment-only aggregates plus on-demand week-doc reads.

**Duration:** ~1 week part-time (~16 h)
**Phase end criterion:** Definition of Done passes 100%.

---

## Definition of Done

- [ ] Completing/un-completing a task updates `stats/{YYYY-MM}` via increments (verified in console), correctly attributed to the completion date, offline included
- [ ] One-time backfill computes aggregates for all pre-phase-6 completed tasks and is safely re-runnable
- [ ] `/stats` opens with a Місяць / Рік segmented switch and period navigation arrows + "Сьогодні"
- [ ] Month view: per-day completed chart, completion ring (done / created in period), carried-over count, habit per-week percentages, mood and energy trend lines
- [ ] Year view: 12-month bar chart of completions, a year heatmap (weeks × days, intensity by per-day counts), longest + current streak per habit
- [ ] All charts follow the active theme (axes, grids, series colors from tokens/Mantine), readable in midnight
- [ ] Sparse/empty periods render friendly placeholders, no NaN or broken axes
- [ ] Charts code ships in a lazy route chunk (network tab: loaded only on first `/stats` visit)
- [ ] Works offline from cache; module-toggled-off habits/trackers sections hide accordingly
- [ ] Build, lint, tsc clean; all strings in en+uk

**Out of scope:** export/share of stats, custom date ranges, per-list breakdowns, comparisons between periods.

---

## Task Breakdown

### Task 1: Aggregates & Backfill (4h)

**Steps:**

1. `npm i @mantine/charts@^9` (charts pulled lazily; recharts comes as its dependency).
2. `src/services/repos/statsRepo.ts`: `bumpCompletion(uid, isoDate, delta)` → `setDoc(stats/{month}, { tasksCompleted: increment(delta), perDay: { [isoDate]: increment(delta) }, updatedAt }, { merge: true })`; `subscribeMonthStats(uid, monthId, cb)`; `getMonthsStats(uid, year)` (12 gets, cache-first).
3. Wire into `weekStore.toggleDone` / list toggle path: on done → `bumpCompletion(today, +1)`; on undone → `bumpCompletion(dateOf(completedAt), -1)` before clearing `completedAt`.
4. `backfillStats(uid)` dev utility (callable from a hidden Settings dev row or console): query all `status=="done"` tasks ordered by `completedAt`, rebuild month docs from scratch (set, not increment - deterministic), mark `profile.statsBackfilledAt`. Composite index per DESIGN.md.
5. Edge rules: undone-after-month-rollover decrements the original month (derived from stored `completedAt`), never today's.

**Acceptance:**

- [ ] Toggle done/undone across a simulated month boundary keeps both month docs correct
- [ ] Backfill twice → identical docs (idempotent)

### Task 2: Stats Page Frame & Month View (5h)

**Steps:**

1. `StatsPage.tsx`: lazy route (`lazy(() => import(...))`), period state in URL (`/stats?p=2026-06` | `?p=2026`), segmented Місяць/Рік, arrows + Сьогодні; reuses `time.ts` month helpers.
2. `monthStatsData` assembler: month stats doc + the month's week docs (≤ 6 reads, already cached if visited) + a tasks count query for "created in period" (single `createdAt` range query) → view model.
3. Month components in `shell/components/stats/`: `CompletedPerDayChart` (Area or Bar from @mantine/charts, day-of-month axis), `CompletionRing` (RingProgress: completed vs created), `CarriedCount` stat card, `HabitMonthList` (per habit: % of tracked days checked, mini 4–5-week dot strip), `TrackerTrendChart` (mood mapped to 1–5, energy as-is; LineChart, two series, gaps skipped).
4. Theming: series colors from theme accent/done tokens via Mantine theme; grid/axis use `--sw-line`/`--sw-ink-3`.

**Acceptance:**

- [ ] Numbers reconcile with a hand-counted seeded month
- [ ] Mood emoji → numeric mapping documented in code via naming (`moodScale`) and consistent

### Task 3: Year View (4h)

**Steps:**

1. `yearStatsData`: 12 month docs → per-month totals + flattened perDay map.
2. `YearHeatmap.tsx`: custom CSS grid (53 columns × 7 rows, Monday-first), cell intensity = 4-step alpha scale of the accent token by per-day count; month labels on top, weekday labels left; hover tooltip (date + count); compact horizontal scroll on mobile.
3. `MonthsBarChart`: 12 bars, current month highlighted.
4. `HabitStreaks`: per habit - current and longest streak; longest computed by walking the year's week docs once (≤ 53 cached reads), memoized per habit+year.

**Acceptance:**

- [ ] Heatmap day alignment correct (spot-check known dates), year boundaries clean
- [ ] Streak math verified against a constructed pattern (gap resets, weekend-spanning runs)

### Task 4: Empty States, Perf & Sweep (3h)

**Steps:**

1. Sparse handling: months with zero data → Caveat placeholder + doodle; charts with < 3 points render dots instead of misleading lines.
2. Confirm the charts chunk loads lazily (build analyze + network tab); stats route prefetch on tab-bar hover/visible idle (nice-to-have, `import()` warm-up).
3. Module toggles: habits/trackers sections hidden when toggled off (data retained).
4. i18n + token + a11y sweep (chart aria-labels, tab order); real-phone check.

**Acceptance:**

- [ ] Fresh account → friendly empty stats; seeded account → full DoD on desktop + phone, light + midnight themes
