# SnugWeek — Phase 32: Cozy Stats Redesign

**Goal:** make the statistics page friendlier, more compact, and more playful without losing information — replace stretched single-value cards with a tidy KPI strip, and restyle the charts to feel hand-made and warm.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `CLAUDE.md`. Touches `MonthStatsView.tsx`, `YearStatsView.tsx`, `StatCard`/`StatTile`, the `stats/*` chart components.

---

## Definition of Done

- [ ] Headline numbers (completed, completion %, carried, and a streak/total) read as a compact KPI strip of small tiles, not full-height stretched cards
- [ ] No card looks empty or stretched: cards size to their content, related cards group tightly, and the overall page feels denser and cozier
- [ ] Charts are restyled playfully (soft cozy palette, rounded bar tops, gentle/dotted gridlines, a friendlier thick rounded completion ring with a hand-written number, doodle accents on empties) while keeping every existing stat and its information
- [ ] The redesign applies to both Month and Year views; all themes read well (incl. mono/noir); empty/sparse states stay graceful
- [ ] Build/lint/tsc clean; strings unchanged or added in en + uk

**Out of scope:** new stat computations (Phase 28 already added the data), removing any existing stat, charting-library swap.

---

## Task Breakdown

### Task 1: Compact KPI Strip (4h)

**Steps:**

1. Replace the top two stretched cards (CompletionRing card + the single-number carried card) with one compact KPI row: small tiles for completion % (or the ring, shrunk), completed, carried, and a streak/total — using a tighter `StatTile`/`StatCard` variant that sizes to content (drop the forced `h="100%"` stretch where it causes emptiness).
2. Introduce a small `KpiTile` (number in the hand font + caption + a tiny doodle/icon) and a responsive row (2 cols mobile, 4 desktop).

**Acceptance:**

- [ ] The headline area is a tidy compact strip; no stretched empty card; reads on mobile + desktop

### Task 2: Playful Chart Restyle (6h)

**Steps:**

1. Restyle the recharts/@mantine/charts components (`CompletedPerDayChart`, `WeekdayChart`, `TimeOfDayChart`, `MonthsBarChart`, `TrackerTrendChart`, `CompletionRing`, `YearHeatmap`): a soft cozy palette from tokens, rounded bar corners, thinner/dotted gridlines, gentle axis text, smooth lines with soft dots; the completion ring becomes thicker and rounded with a hand-written central number.
2. Keep all series/data intact and legible; ensure mono/noir use opacity/shape, not just hue.
3. Tasteful doodle accents on empty/sparse chart states (reuse `doodles.tsx`).

**Acceptance:**

- [ ] Charts look hand-made and warm, remain informative and legible in every theme; no data lost

### Task 3: Layout Density & Grouping (5h)

**Steps:**

1. Rework `MonthStatsView`/`YearStatsView` layout for density: group related cards (e.g. weekday + time-of-day; trackers; habits) into tighter sections, let cards auto-height, and reduce vertical gaps; consider a compact two-column rhythm that doesn't leave half-empty rows.
2. Make `StatCard` lighter (softer border/shadow, cozier title) and stop forcing equal heights where it creates emptiness.

**Acceptance:**

- [ ] The page is visibly more compact and cohesive; no stretched/empty blocks; grouping reads naturally

### Task 4: Empty States & Sweep (3h)

**Steps:**

1. Friendly empty/sparse handling per card (short Caveat line + doodle) consistent across Month + Year.
2. Token/contrast/a11y sweep (chart aria/legends), real-phone check, verify lazy chunking still holds.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; empties are cozy; i18n missing-key warnings zero

### Task 5: Year View Parity (4h)

**Steps:**

1. Apply the same KPI strip, chart restyle, and density treatment to `YearStatsView` (heatmap, months bar chart, streak summaries) so Month and Year feel like one redesigned surface.

**Acceptance:**

- [ ] Year view matches the cozy redesign; heatmap + bars read well in all themes
