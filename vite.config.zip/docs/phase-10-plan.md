# SnugWeek - Phase 10: UX & Layout Refinement

**Goal:** make the existing app *feel* effortless before stacking on features - put controls where the hand and eye expect them on desktop and phone, and build the shared UI primitives (above all a **Task Detail** surface) that nearly every later feature plugs into. This is foundation work: it changes how things are arranged and introduces reusable patterns, with little new "feature" surface of its own.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §8 (binding for this and every later phase). Best done right after Phase 9.

---

## Definition of Done

- [ ] **Task Detail surface exists and is reused:** tapping a task's body opens a detail view - a side panel/popover on desktop, a bottom sheet on mobile - currently hosting the title, notes affordance, and clearly-labelled empty slots for the features that land later (subtasks, tags, time/reminder, attachments). The card itself shows only checkbox, title, and small indicators
- [ ] **One obvious "add" per surface:** every day column and list has the same add affordance; on mobile a thumb-reachable quick-add (e.g. a FAB or a docked composer) adds to today or the open list without reaching the top of the screen
- [ ] **Mobile menus are bottom sheets, not top-anchored dropdowns:** the task/list kebab, the Move-to picker, and any editor open as sheets with ≥44px targets within thumb reach; a shared primitive backs them
- [ ] **Consistent action surface:** all kebabs (task, list, habit, tag-to-come) use the same component, order, destructive styling, and confirmation behavior
- [ ] **Settings are sectioned and navigable:** grouped into clear sections (Appearance, Modules, Schedule, Sound, Reminders-to-come, Account, About) via tabs or an accordion index - no single long scroll
- [ ] **Header carries only essentials** and stays minimal on mobile; week navigation is prominent; overflow folds into a menu
- [ ] Empty/loading/skeleton states are consistent and cozy via shared components
- [ ] A11y pass: logical tab order, themed focus rings, ARIA on menus/sheets/dialogs, escape-to-close, contrast verified in all themes
- [ ] No regressions to existing flows (tasks, DnD, trackers, habits, notes, month, stats, account); build/lint/tsc clean; strings en + uk

**Out of scope:** the features that will fill the Task Detail slots (Phases 12/13/16), the command palette (Phase 15) - though this phase may leave a header slot for its entry.

---

## Task Breakdown

### Task 1: Shared Primitives (5h)

**Steps:**

1. `shell/components/common/BottomSheet.tsx` (a.k.a. `ResponsiveMenu`): a wrapper that renders a Mantine `Menu`/`Popover` on desktop and a bottom `Drawer`/sheet on mobile (`useIsMobile`), with consistent padding, drag-affordance, large targets, focus trap, escape-close.
2. `shell/components/common/ActionMenu.tsx`: a standard kebab built on the above - takes a list of actions (`{ label, icon?, onClick, danger? }`); centralizes order and `--sw-danger` styling and the optional confirm pattern.
3. `shell/components/common/SkeletonBlock.tsx` + consolidate empty states into the existing `EmptyState`/`doodles` so all loading/empty UI is one set.
4. Ensure all primitives are tokens-only, reduced-motion-aware, and keyboard-operable.

**Acceptance:**

- [ ] A throwaway demo route mounts each primitive on desktop + mobile and they behave (sheet vs dropdown, focus, escape)

### Task 2: Task Detail Surface (5h)

**Steps:**

1. `shell/components/tasks/TaskDetail.tsx`: opened from a task (tap on the card body; the card's existing inline rename becomes a field inside the detail, or stays as a quick inline edit with the detail as the deeper view - pick one and be consistent). Desktop: a right-side panel or a wide popover; mobile: a full-height bottom sheet via the Task 1 primitive.
2. Content now: title (editable), the day/list it belongs to, the `carriedFrom` info, a notes affordance, and **labelled placeholder sections** (visually present but inert) for Subtasks, Tags, Time & reminder, Attachments - so later phases drop in without rework. Mark placeholders clearly (e.g. a muted "скоро" affordance) or hide behind a flag; do not ship dead buttons that look active.
3. Wire open/close through `uiStore` (`openTaskId`), ensuring it closes on navigation and doesn't fight DnD (no detail open while dragging).
4. Keep the card lean: remove anything that now belongs in the detail; the card shows checkbox, title, indicators (`carriedFrom`, and counters once features land).

**Acceptance:**

- [ ] Opening/closing the detail works on desktop + phone; it never blocks DnD; closing on route change works; the card is visibly calmer

### Task 3: Add Affordance & Mobile Quick-Add (3h)

**Steps:**

1. Standardize the day/list composer into one `AddControl` used everywhere (it largely exists - unify styling/behavior, IME-safe Enter, chained entry).
2. Mobile quick-add: a thumb-reachable entry (a small FAB above the bottom tab bar, or a docked mini-composer) that adds to **today** (on the week view) or the **open list/day** contextually; opens the composer focused. Avoid covering content; respect safe-area insets.
3. Optional keyboard `n` to focus the composer on desktop (low-risk; gate so it doesn't fire in inputs).

**Acceptance:**

- [ ] Adding a task on mobile never requires reaching the top of the screen; desktop chained entry unchanged

### Task 4: Header & Navigation Reorg (3h)

**Steps:**

1. Audit the current `HeaderBar` and rebalance: left - wordmark + account; center - week title + prominent nav arrows + "Сьогодні"; right - a reserved slot for the future search/command entry (Phase 15) + the sync badge; fold language and less-used items into the account/overflow menu.
2. Mobile header: minimal (wordmark + account + sync); navigation belongs to the bottom tab bar and the in-view week arrows. Ensure the title/arrows are reachable and not cramped.
3. Keep `WeekNav`/`WeekJumpPopover` behavior intact; only placement/prominence changes.

**Acceptance:**

- [ ] Header reads clearly on desktop and is uncluttered on mobile; week navigation is the obvious primary action; nothing lost

### Task 5: Sectioned Settings (3h)

**Steps:**

1. Restructure `SettingsPage` into grouped sections with a sub-navigation (Mantine `Tabs` vertical on desktop / an accordion or segmented index on mobile): **Вигляд** (theme/texture/cover-to-come), **Модулі**, **Розклад** (weekend, columns), **Звук**, **Нагадування** (placeholder until Phase 13), **Акаунт**, **Про застосунок**.
2. Move existing controls into their sections without changing their behavior; leave clearly-labelled anchors for sections that fill in later phases.
3. Ensure deep, scrollable sections remain comfortable on mobile.

**Acceptance:**

- [ ] Settings is navigable by section on both layouts; every existing control still works; future sections have obvious homes

### Task 6: A11y, Polish & Regression Sweep (3h)

**Steps:**

1. Tab order and focus-visible across the reorganized surfaces; ARIA roles/labels on the new sheet/menu/detail; escape-to-close everywhere; ensure the detail and sheets trap focus correctly.
2. Density/spacing pass for a calmer rhythm (consistent paddings, card spacing) using tokens.
3. Full regression of v1 flows + Phase 9 (sound/notify still correct after the reorg); contrast check in light + dark themes; real-phone session focusing on thumb reach.

**Acceptance:**

- [ ] No functional regressions; a11y checks pass; the app demonstrably feels easier to use one-handed on a phone
