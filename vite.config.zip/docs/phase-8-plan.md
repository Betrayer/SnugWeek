# SnugWeek - Phase 8: PWA & Release

**Goal:** ship it: installable PWA with offline shell and update prompts, real icons and meta, performance within budget, graceful failure states, and a release checklist pass - v1 live on the production domain.

**Duration:** ~1 week part-time (~16 h)
**Phase end criterion:** Definition of Done passes 100% - this is the v1 release gate.

---

## Definition of Done

- [ ] App is installable (Chrome desktop + Android "Add to Home Screen" + iOS Safari) with proper name, icons, theme color; launches standalone without browser chrome
- [ ] Cold offline launch of the installed app works: shell, fonts, last-cached data all render
- [ ] New deploy → running clients show a cozy "Нова версія" prompt; accepting reloads onto the new build
- [ ] Favicon, app icons, OG/social meta (title, description, preview image) in place
- [ ] Bundle budget holds: initial JS ≤ 250 KB gzip excluding the firebase chunk; firebase split out; charts chunk loads only on `/stats`
- [ ] Lighthouse on production: PWA installable, performance ≥ 90 desktop / ≥ 80 mobile, a11y ≥ 95
- [ ] Firestore read audit: opening a week costs ≤ 2 listeners; month ≤ 1 query + ≤ 6 doc reads; no accidental unbounded queries
- [ ] ErrorBoundary shows a cozy recovery screen (doodle + "щось пішло не так" + reload button) instead of a white page; invalid routes/ids redirect cleanly
- [ ] Smoke matrix passes: desktop Chrome/Firefox/Safari + Android Chrome + iOS Safari (installed PWA), each: open, add/complete/drag task, switch week with fold, edit tracker, go offline and back, theme switch
- [ ] README.md (public-safe: what it is, stack, env setup, scripts - no roadmap internals), `.env.local.example` current, rules file matches deployed rules
- [ ] Production domain connected (Vercel + Firebase authorized domains updated)

**Out of scope:** Telegram Mini App wrapper, app stores, analytics/telemetry (decide post-launch), Sentry (optional post-launch).

---

## Task Breakdown

### Task 1: PWA Setup (4h)

**Steps:**

1. `npm i -D vite-plugin-pwa`.
2. Plugin config: `registerType: "prompt"`; manifest - name "SnugWeek", short_name "SnugWeek", description (uk), `display: "standalone"`, `start_url: "/"`, `background_color`/`theme_color` from milk paper/accent, icons 192/512 + maskable.
3. Workbox: precache build assets; runtime cache `@fontsource` font files (CacheFirst, 1y) - Firestore needs no SW caching (IndexedDB already covers data).
4. `UpdatePrompt.tsx` on `useRegisterSW` hooks: bottom toast "Нова версія SnugWeek - оновити?" → `updateServiceWorker(true)`; offline-ready first-visit toast optional and quiet.
5. iOS specifics: `apple-touch-icon`, status-bar meta; verify standalone launch on an iPhone (or simulator note for the owner).

**Acceptance:**

- [ ] Install + cold offline launch on Android and desktop verified; update prompt appears on a redeploy and swaps versions cleanly

### Task 2: Icons & Meta (2h)

**Steps:**

1. App icon: simple inline-SVG mark (rounded notebook page with a fold corner, accent on paper) → export 192/512/maskable PNGs + favicon.svg/ico (generation commands or a tiny script in `scripts/`).
2. `index.html` meta: lang per default (`uk`), title "SnugWeek - затишний тижневик", description, `og:*` + `twitter:card` with a static preview image (simple branded card, 1200×630, committed to `public/`).
3. `theme-color` meta synced to the active theme at runtime (small effect in Root).

**Acceptance:**

- [ ] Link previews render correctly (validator spot-check); browser UI tint follows the theme

### Task 3: Performance Pass (4h)

**Steps:**

1. Build analysis (`rollup-plugin-visualizer` dev-only or `vite build --report`-style inspection): confirm chunking - firebase split via rollup `advancedChunks` (Klikta pattern), charts lazy with `/stats`, motion in the main chunk (small), locales per-language chunks.
2. Trim: ensure `@mantine/charts`/recharts never leaks into the main chunk (import audit), tree-shake icon registry, font subsets limited to the weights actually used.
3. Lighthouse runs (prod URL, desktop + mobile emulation); fix the usual: preconnect to Firebase origins, image sizes, unused CSS.
4. Firestore audit: log listener registrations in dev for a full session walkthrough; verify month view batches, stats caching, no listener leaks across navigation (counts return to baseline).
5. Fold transition trace re-check on a mid Android phone post-PWA.

**Acceptance:**

- [ ] Budgets + Lighthouse targets met and recorded in the task log

### Task 4: Robustness (3h)

**Steps:**

1. `ErrorBoundary` at Root: cozy fallback (doodle, message, "Перезавантажити" button), error logged to console with component stack.
2. Route guards re-checked: invalid `weekId`/`monthId` formats and absurd ranges (year < 2020 or > 2100) redirect to current; `/stats?p=` garbage falls back to current month.
3. Firestore failure modes: permission-denied (rules drift) shows the Phase 2 friendly notification, not a crash; auth bootstrap failure (rare) shows a retry screen instead of an infinite splash.
4. `beforeunload` is NOT used (offline queue makes it unnecessary) - verify a mid-write tab close loses nothing after reopen.

**Acceptance:**

- [ ] Thrown render error (dev-forced) → boundary; all guard paths land on a working screen

### Task 5: Release Checklist (3h)

**Steps:**

1. Security: rules file vs deployed diff = none; App Check decision recorded (off for v1, roadmap note); Firebase quotas sanity (alerts at 80% of free tier reads/writes).
2. Env audit: Vercel envs complete, no secrets in the repo, `.env.local.example` matches reality.
3. README.md authored (public-safe); LICENSE decision (private repo - skip or "All rights reserved").
4. Production domain: purchase/connect (owner action), add to Vercel + Firebase authorized domains, re-run auth smoke on the final origin.
5. Full smoke matrix from the DoD on the production domain; tag `v1.0.0` (owner does git).

**Acceptance:**

- [ ] Every DoD line checked on production; v1 is live
