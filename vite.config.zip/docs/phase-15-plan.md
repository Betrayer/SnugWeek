# SnugWeek - Phase 15: Search & Quick Actions

**Goal:** one calm place to find anything and jump anywhere - search tasks and notes, go to a week or date, and quick-add a task - reachable by a visible button (and an optional ⌘/Ctrl-K). As the notebook fills up, nothing is more than a couple of keystrokes or taps away.

**Duration:** ~1 week part-time (~16 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §8. Depends on Phase 10 (header slot, primitives).

---

## Definition of Done

- [ ] A visible search/command entry in the header (the slot reserved in Phase 10) opens the surface; an optional ⌘/Ctrl-K also opens it (and is easy to ignore if you don't use it)
- [ ] Typing searches task titles (and day/week notes) across the user's data and shows ranked results grouped (Tasks / Notes / Go to)
- [ ] Selecting a task result opens that task (navigating to its week and opening its detail); selecting a note result opens that week/day
- [ ] "Go to" actions: jump to a week, to today, to a specific date (parsed via `time.ts`), to Month/Stats/Settings
- [ ] Quick-add: typing an add intent (or an explicit "Додати: …" action) creates a task on today/the open context without leaving the surface
- [ ] Fully keyboard-operable (arrows, enter, escape) and equally usable by tap on mobile (a full-height sheet); recent searches/commands are remembered (device-local)
- [ ] Works offline over loaded/cached data; strings en + uk; build/lint/tsc clean; no console errors

**Out of scope:** server-side full-text search/indexing, fuzzy search over attachment contents, search within subtask items (could be a later nicety), natural-language scheduling ("tomorrow 5pm").

---

## Task Breakdown

### Task 1: Command Surface (4h)

**Steps:**

1. Add `@mantine/spotlight` (Mantine-official; install + styles). Build `shell/components/search/CommandSurface.tsx` on top of it - themed to match (paper, tokens), cozy empty state, grouped sections.
2. Trigger: a header button (the Phase 10 reserved slot) + register the ⌘/Ctrl-K shortcut (guarded so it doesn't fire inside inputs); on mobile it presents as a full-height sheet.
3. Recents: store the last handful of queries/commands in a device-local localStorage key; show them when the input is empty.

**Acceptance:**

- [ ] Opens via button, shortcut, and on mobile as a sheet; keyboard nav + escape work; themed correctly

### Task 2: Search Index & Querying (4h)

**Steps:**

1. `services/search/searchIndex.ts`: build an in-memory index over currently-loaded data (open week tasks, sidebar list tasks, week notes already in stores) for instant results; for broader reach, add bounded queries - e.g. a task-title query and a recent-weeks note scan - triggered on demand, not eagerly. Keep it offline-friendly (cache-first).
2. Ranking: title prefix/substring matches first, then notes; recent items weighted up. Debounce input.
3. Result types: `task` (with its weekId/location), `note` (week/day), `goto` (week/date/route).

**Acceptance:**

- [ ] Results are instant for loaded data and reasonably complete via the on-demand queries; ranking feels sensible

### Task 3: Actions & Navigation (4h)

**Steps:**

1. Wire result selection: task → navigate to its week (`/w/:weekId`) and open its `TaskDetail` (via `uiStore.openTaskId`), landing the mobile pager on its day; note → navigate to the week/day; goto → route or `goTo(weekId)`.
2. "Go to date": parse free input ("2026-07-01", "1 липня", "today/сьогодні") via `time.ts` helpers (add a tolerant parser); offer a "go to <week>" action.
3. Quick-add: an always-available "Додати: <text>" action that creates a task on today (week view) or the open list/day; close the surface and (optionally) flash the created task.

**Acceptance:**

- [ ] Each action lands correctly on desktop + phone; quick-add creates the task in the expected place

### Task 4: i18n, A11y & Sweep (4h)

**Steps:**

1. en + uk for labels, group headings, quick-add, date-parse hints; ensure date parsing respects the locale.
2. A11y: combobox semantics from Spotlight verified, focus management, escape; mobile sheet reachable and dismissible.
3. Offline test (search over cache); real-phone pass; confirm the shortcut never hijacks text input.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, online + offline; i18n missing-key warnings zero
