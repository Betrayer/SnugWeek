# SnugWeek - Phase 20: Output & Sharing

**Goal:** get a week *out* of the app - a clean print/PDF of a week for paper lovers and archiving, a read-only share link to show a friend your plan, and PWA shortcuts for one-tap capture from the home screen.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §1 (`shares` snapshot model), §7.

---

## Definition of Done

- [ ] "Друк тижня" produces a clean printout / print-to-PDF of the current week: the spread with tasks (and chosen extras - notes/trackers/habits) on paper, no app chrome, high-contrast and legible
- [ ] A week can be shared as a **read-only** link: the user picks what's included (tasks/note/trackers/habits/decorations), gets a link, and can revoke it; opening the link (even signed-out, even by someone else) shows a clean read-only render of that snapshot
- [ ] Sharing copies a **snapshot** (never grants public access to live data); revoking deletes the snapshot; private things (notes/attachments) are excluded unless explicitly opted in
- [ ] PWA manifest shortcuts offer quick actions from the installed icon (e.g. "Додати справу", "Сьогодні") that deep-link into the app
- [ ] Print and share work on desktop + phone; the public share render is responsive and offline-irrelevant (it's a fetch of a snapshot doc); strings en + uk; build/lint/tsc clean; no console errors

**Out of scope:** editable/collaborative shares, multi-week or month/stats sharing, password-protected shares, custom print themes/templates, native share-target receiving.

---

## Task Breakdown

### Task 1: Print / PDF of a Week (5h)

**Steps:**

1. A dedicated print layout: either a `@media print` stylesheet that reflows the current week into a clean paper layout (hide chrome, expand columns, ensure tasks/sections print), or an off-screen `PrintView` rendered for printing. Prefer high-contrast, token-light output (paper white, ink black) regardless of the active theme, so it prints well.
2. Include options: a small pre-print choice of what to include (tasks always; notes/trackers/habits optional). Browser print-to-PDF is the baseline (no PDF lib).
3. A "Друк тижня" action (week toolbar / overflow). Handle page breaks gracefully for long days.

**Acceptance:**

- [ ] Printing a busy week yields a clean, readable page/PDF on desktop + mobile browsers; chrome is gone; long content paginates sensibly

### Task 2: Share Snapshot - Service & Rules (4h)

**Steps:**

1. `services/share/shareService.ts`: `createShare(uid, weekId, include)` builds a denormalized snapshot of the chosen week data → writes `users/{uid}/shares/{shareId}` **and** a public-readable mirror (or a top-level `shares/{shareId}` doc) with an unguessable id; returns the link. `revokeShare(shareId)` deletes it. `listShares(uid)` for management.
2. `firestore.rules`: the public shares path is world-readable by id, owner-only writable; the snapshot contains only included fields; ensure no path exposes live user docs.
3. Decide storage of the public doc: a top-level `shares/{shareId}` collection (readable by anyone with the id) is simplest for a public render; keep an owner-side index under `users/{uid}/shares` for management/revocation.

**Acceptance:**

- [ ] Creating a share writes a snapshot readable by id while live user data stays private; revoke deletes it; security verified with a signed-out fetch

### Task 3: Public Read-Only Render (4h)

**Steps:**

1. A public route (e.g. `/s/:shareId`) outside the authed AppShell that fetches the snapshot and renders a clean, responsive read-only week (reusing presentational pieces where possible, no editing affordances, no stores/subscriptions). Themed but self-contained; a gentle "made with SnugWeek" footer.
2. Handle missing/revoked shares with a friendly "це посилання більше не діє" page.
3. Decorations (if included) render statically; attachments only if opted in (as view links/thumbnails).

**Acceptance:**

- [ ] Opening a share link (signed-out / another browser) shows the snapshot cleanly; revoked/invalid links show the friendly page; responsive on phone

### Task 4: Share UX (3h)

**Steps:**

1. A "Поділитися тижнем" flow (week toolbar): a dialog to choose what's included (clear privacy note - notes/attachments off by default), create the link, copy it (and use the Web Share API on mobile where available), and manage/revoke existing shares.
2. `notify` confirmations for created/revoked (per §7).

**Acceptance:**

- [ ] Creating, copying, sharing, and revoking are clear on desktop + phone; privacy defaults are conservative

### Task 5: PWA Shortcuts, i18n & Sweep (3h)

**Steps:**

1. Manifest `shortcuts`: "Додати справу" (deep-link that opens the app with the quick-add composer focused on today) and "Сьогодні" (open the current week); wire the deep-link handling in routing/`Root`.
2. en + uk for print options, share dialog, public render, and the "link expired" page; ensure the public render is localized by the snapshot's language or a sensible default.
3. A11y (print readability, share dialog, public page landmarks), token sweep, real-device test (install → shortcuts; print; open a share link on a phone).

**Acceptance:**

- [ ] Shortcuts work from an installed icon; full DoD passes desktop + phone; i18n missing-key warnings zero
