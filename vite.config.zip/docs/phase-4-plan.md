# SnugWeek - Phase 4: Day Trackers, Habits, Week Modules

**Goal:** the journal half of the product: customizable day indicators (mood, energy, anything), the weekly habit grid, an upgraded week note, and module/layout settings - days off, column widths, module toggles.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.

---

## Definition of Done

- [ ] Each day header shows the enabled trackers; mood (emoji) and energy (1–5) work out of the box
- [ ] Tracker values persist per day per week, render after reload, work offline, merge across two tabs editing different days
- [ ] Settings → Показники дня: add a tracker (name, type: шкала 1–5 / емодзі / число / чекбокс, icon), rename, reorder, disable; changes reflect in day headers immediately
- [ ] Habit grid below the board: rows = habits, columns = Mon–Sun checks; add/rename/archive habits; current-streak badge per habit
- [ ] Week note shows a save tick and a Caveat handwriting style
- [ ] Settings → Модулі: toggles for Показники дня / Звички / Нотатка тижня hide/show their UI everywhere (week view, month enrich, future stats)
- [ ] Day header menu: "Зробити вихідним / робочим" toggles per-week day-off (dims column); Settings has the default weekend picker and the column mode (Затишний / Однакові колонки)
- [ ] Month view cells now show the mood emoji when set
- [ ] Build, lint, tsc clean; all new strings in en+uk; no console errors

**Out of scope:** tracker statistics (Phase 6), tracker value history editing for past weeks beyond normal navigation, custom icon uploads (curated set only).

---

## Task Breakdown

### Task 1: Tracker Definitions (4h)

**Steps:**

1. `src/services/repos/trackersRepo.ts`: `Tracker` type per DESIGN.md; CRUD + `subscribeTrackers`; `seedDefaultTrackers(uid)` (idempotent: `mood` emoji, `energy` scale5) hooked into the `ensureProfile` flow.
2. Curated icon set: `src/data/icons.ts` - a small registry of inline-SVG paths (heart, star, drop, flame, book, dumbbell, moon, leaf…) + the option of a raw emoji char; one `TrackerIcon` component resolves either.
3. `trackersStore` slice (inside `profileStore` or its own `trackersStore.ts` - own store, consistent with one-responsibility): mirrors definitions sorted by `order`.
4. `TrackerSettings.tsx` in Settings: list with drag-handle reorder (reuse dnd-kit sortable), add modal (name, type segmented control, icon picker grid), enable switch, rename, delete (with "values stay in old weeks" note).

**Acceptance:**

- [ ] Defaults appear for a fresh account exactly once
- [ ] Reorder/disable reflects in the week view live

### Task 2: Day Tracker Row (5h)

**Steps:**

1. `weeksRepo` additions: `setTrackerValue(uid, weekId, day, trackerId, value)` / `clearTrackerValue(...)` via dotted-path `updateDoc` with `setDoc`-merge fallback when the week doc doesn't exist yet.
2. `DayTrackerRow.tsx` in `DayHeader`, gated by `moduleToggles.dayTrackers`: compact icon row; unset trackers ghosted.
3. `TrackerControl.tsx` per type:
   - `emoji`: popover with a 5-emoji mood row (😞 🙁 😐 🙂 😄) - value is the emoji char
   - `scale5`: 5 dots, tap n fills 1..n (accent), tap same value clears
   - `number`: popover stepper (0–999)
   - `checkbox`: single round check
4. Desktop: controls inline in the header (week columns are wide enough in cozy mode); mobile pager: a roomier tracker strip at the top of the day card.
5. Values render from `weekStore.week.trackerValues`; concurrent-tab field merge verified (edit day 2 in tab A, day 5 in tab B).

**Acceptance:**

- [ ] All four types set/clear/persist correctly, offline included
- [ ] Disabled trackers vanish from headers but old values stay in Firestore untouched

### Task 3: Habit Grid (5h)

**Steps:**

1. `src/services/repos/habitsRepo.ts`: CRUD + `subscribeHabits`; `weeksRepo.toggleHabitCheck(uid, weekId, habitId, day)` (dotted-path set/delete of `habitChecks.<habitId>.<day>`).
2. `habitsStore.ts`: definitions; checks come from the open week doc.
3. `HabitGrid.tsx` under the board (desktop bottom-left zone per the sketch; mobile: a section below the pager), gated by `moduleToggles.habits`: rows = active habits (icon + name), 7 round check cells aligned with day columns; today's column subtly highlighted; horizontal scroll on overflow (mobile).
4. Add habit inline composer; kebab: rename / archive (archived hidden, history preserved).
5. Streak badge: current streak computed client-side - walk back day by day from today across week docs; cap the lookback at 8 weeks of reads (cached); show 🔥n for n ≥ 2.
6. `HabitSettings.tsx` (Settings): full list incl. archived, restore, reorder.

**Acceptance:**

- [ ] Checks persist per week; navigating weeks shows that week's checks
- [ ] Streak math verified across a week boundary (e.g., checks Sat+Sun+Mon → 3)
- [ ] Archive hides the row without data loss

### Task 4: Week Note & Layout Settings (4h)

**Steps:**

1. `WeekNote` upgrade: Caveat 1.35em ink styling, faint ruled-lines background (token line color), autosize bounds, "збережено ✓" tick after the debounced write confirms locally; gate by `moduleToggles.weekNote`.
2. Day-off toggling: `DayHeader` kebab → "Зробити вихідним/робочим" → `weeksRepo.setDaysOff(uid, weekId, days)` (writes the explicit array; first toggle initializes from the effective default).
3. Settings → Розклад: default weekend day-picker (writes `profile.weekend`), column mode segmented control (`cozy` / `equal`) - board grid reacts live.
4. Settings → Модулі: three switches writing `profile.moduleToggles`; every gated component already reads the store - verify each toggle end-to-end including mobile.

**Acceptance:**

- [ ] Per-week day-off overrides the default and survives reload; other weeks keep the default
- [ ] Column mode switch re-lays the board without breaking DnD
- [ ] All module toggles hide/show their UI everywhere

### Task 5: Month Enrichment & Sweep (3h)

**Steps:**

1. Month data: extend the month query bundle with the month's week docs (≤ 6 reads) → `MonthDayCell` shows the mood emoji (the tracker with id `mood` if enabled and set).
2. i18n sweep (en+uk), token sweep (no hex), a11y pass on new controls (labels, focus order, popovers escape-close).
3. Real-phone session: trackers, habits, note, toggles, offline.

**Acceptance:**

- [ ] Month view reflects moods; cells without data stay clean
- [ ] Full DoD passes on desktop + phone
