# SnugWeek - Phase 7: Accounts & Sync UX

**Goal:** the friendly account story: anonymous users can save their account in one click (Google or email) without losing a single task; signing into an *existing* account merges local data instead of discarding it; sign-out is safe and explained; sync status is honest; security rules stop trusting the client.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.

---

## Definition of Done

- [ ] Header shows an account menu: anonymous → soft "Зберегти акаунт" CTA; linked → avatar/initial, email, sign-out
- [ ] AuthModal offers Google and email/password (create), with localized validation and error messages
- [ ] Link happy path: anonymous + Google/email link keeps the same uid - every task/week/theme survives, verified explicitly
- [ ] Merge path: linking a credential that already has an account explains the situation and, on confirm, signs into the existing account and merges all anonymous data into it (tasks, lists, weeks incl. tracker values/habit checks/notes, habits, trackers, stats) with a progress modal; nothing is lost on either side
- [ ] Merge is idempotent: killing the page mid-merge and retrying produces no duplicates (deterministic migrated ids + marker doc)
- [ ] Sign-out shows a confirm dialog explaining that data stays in the cloud and the device starts a fresh notebook; after sign-out a new anonymous session works immediately
- [ ] Sign-in from an anonymous session that already has data offers the merge flow instead of silently abandoning local data
- [ ] Sync badge v2: offline state + "є незбережені зміни" (pending writes) + quiet "синхронізовано" - truthful in airplane-mode tests
- [ ] Hardened `firestore.rules` deployed: owner-only plus shape validation; manual negative tests (oversized title, inconsistent bucket fields, wrong types) are rejected
- [ ] Multi-device test: phone + desktop on one account stay consistent through edits, merges, and offline periods
- [ ] Build, lint, tsc clean; all strings in en+uk

**Out of scope:** password reset email flows beyond Firebase defaults (use `sendPasswordResetEmail` with a minimal UI), account deletion UI (roadmap), orphaned-anon-data TTL cleanup (documented as accepted v1 debt).

---

## Task Breakdown

### Task 1: Auth UI (4h)

**Steps:**

1. `AccountMenu.tsx` in HeaderBar: anonymous → accent-soft pill "Зберегти акаунт"; linked → Menu (email/displayName, "Вийти"). Mobile: same menu from the header.
2. `AuthModal.tsx`: two paths - Google button (inline-SVG G mark), email/password form (email format check, password ≥ 8, show/hide); mode copy: "збережемо ваш блокнот за цим акаунтом".
3. `authStore` actions: `linkGoogle()` (`linkWithPopup`), `linkEmail(email, pass)` (`linkWithCredential(EmailAuthProvider.credential(...))`), surfaced loading/error state; error map → i18n (`auth/email-already-in-use`, `auth/credential-already-in-use`, `auth/weak-password`, popup-closed, network).
4. Post-link: write `email`/`displayName` to the profile doc; success notification.

**Acceptance:**

- [ ] Fresh anonymous → link via email and (separately tested) via Google: uid unchanged, data intact, header reflects the account
- [ ] All error branches show friendly uk/en messages, no raw codes

### Task 2: Existing-Account Merge - Service (6h)

**Steps:**

1. `src/services/migration.ts` per DESIGN.md: `exportAnonData(uid)` (reads all collections into memory - counts logged), `runMerge(exported, targetUid)`:
   - marker `users/{target}/migrations/{anonUid}` `{ status: "pending", startedAt, counts }`
   - deterministic ids `m_{anonUid}_{oldId}` for tasks/habits/trackers/custom lists (idempotent re-runs overwrite themselves)
   - builtin lists: skip docs, tasks just retarget `listId`
   - weeks: deep merge - `trackerValues`/`habitChecks` union per dotted path (anon habit/tracker ids rewritten to migrated ids), `note` concatenation with `\n···\n` when both non-empty, target scalars win
   - stats: `increment()` by exported values
   - batches ≤ 450 writes; finally `{ status: "done", finishedAt }`
2. Flow wrapper `mergeAnonIntoExisting(credentialOrProvider)`: export FIRST → `signInWithCredential`/`signInWithPopup` → run merge → resubscribe stores under target uid.
3. Interruption safety: merge re-runnable from the same export; if the page died after sign-in but before completion, on next login a `pending` marker without a matching export is surfaced as a notice (best-effort; data risk limited to the un-merged anon orphan, documented).

**Acceptance:**

- [ ] Scenario test: account A (existing, has data) + anonymous B (has data) → link attempt → merge → A contains both datasets, week maps merged field-wise, no id collisions, chips/orders sane
- [ ] Re-running `runMerge` with the same export changes nothing (doc count stable)

### Task 3: Merge - UX (4h)

**Steps:**

1. Detect `auth/credential-already-in-use` (Google) and `auth/email-already-in-use` (email) in link actions → `MergeDialog`: explains "цей акаунт уже існує; об'єднати поточний блокнот із ним?" with item counts from the would-be export; actions: Об'єднати / Скасувати.
2. Progress modal during merge (steps: експорт → вхід → перенесення n/N → готово); blocks interaction; failure → retry button (re-runs merge from memory).
3. Sign-in entry point for anonymous-with-data sessions ("Вже маю акаунт"): same dialog before signing in, since plain sign-in would orphan local data.
4. After merge: stores resubscribed, theme/profile of the target applied, success notification.

**Acceptance:**

- [ ] Full happy path and a forced mid-merge reload both end with a consistent merged account
- [ ] Cancel keeps the anonymous session untouched

### Task 4: Sign-out & Session Semantics (3h)

**Steps:**

1. Sign-out confirm dialog: data-safe copy; on confirm → `signOut()` → `authStore.bootstrap` starts a fresh anonymous uid; stores reset and resubscribe; `ensureProfile` seeds the new notebook (Phase 5 seed applies - fresh-account guard).
2. Linked-account sign-in on a *fresh* (no data) anonymous session skips the merge dialog and just signs in.
3. Guard subscriptions against uid races (all `subscribe*` paths key off the current uid snapshot; switching uid tears down everything first - audit each store).

**Acceptance:**

- [ ] Sign-out → new empty seeded notebook; sign back in → full data returns; repeat twice without leaks (listener count audit)

### Task 5: Sync Indicator v2 & Rules Hardening (4h)

**Steps:**

1. `SyncBadge` v2: combine `navigator.onLine` with a pending-writes signal - a lightweight `syncStore` flipping on repo writes and clearing via `waitForPendingWrites(db)` (re-armed per write burst, debounced); states: offline / pending / synced (synced renders as nothing after a 1.5s quiet tick).
2. `firestore.rules` hardening per DESIGN.md: per-collection `allow create/update` validators - task shape (title size 1..500, status/bucket whitelists, bucket-field consistency, numeric `order`/timestamps, `carriedFrom` string|null), list kinds, week doc field types, tracker/habit shapes, stats writes restricted to expected keys; deploy + keep the file in repo.
3. Negative tests from the console/dev page: each invalid write rejected; all normal app flows still pass (full regression of Phases 2–6 quick paths).

**Acceptance:**

- [ ] Airplane-mode edit → badge shows pending → reconnect → quiet synced
- [ ] Every negative rule test rejects; the app's own writes all pass
