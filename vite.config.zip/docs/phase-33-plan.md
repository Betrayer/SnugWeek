# SnugWeek — Phase 33: Memories — Lightbox Fix & Photo Stickers

**Goal:** fix the photo viewer so it opens above the memories dialog instead of behind it, and let images be placed freely on a day like stickers (a pinned polaroid you can move, rotate, and scale).

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `CLAUDE.md`. Touches `Lightbox.tsx`, `AttachmentGrid.tsx`, the decoration layer (`decorations.tsx`, `DecorationLayer`), `weeksRepo.ts` (decorations), `attachmentsRepo.ts`.

---

## Definition of Done

- [ ] Opening a photo from a day's memories shows the image on top in the lightbox — the memories dialog no longer covers it; prev/next/close and keyboard nav work
- [ ] An image attachment can be pinned to a day/page as a placed photo (polaroid-style frame); it can be moved, rotated, scaled, and removed like a sticker, persists per week, syncs, and works offline-render
- [ ] Placed photos render in the decoration layer above the page without blocking task interaction in view mode; edit mode makes them draggable like stickers
- [ ] Removing the underlying image attachment removes/empties its placed photo; deleting a placed photo leaves the attachment intact
- [ ] Reads well in all themes; build/lint/tsc clean; strings en + uk

**Out of scope:** placing non-image attachments freely, photo filters/cropping, arbitrary stacking/z-order UI beyond add-order.

---

## Task Breakdown

### Task 1: Lightbox Layering Fix (3h)

**Steps:**

1. Ensure the `Lightbox` modal renders above the memories `ResponsiveDialog` it's launched from: give the lightbox a higher `zIndex` than the dialog (or render it through a root portal above all dialogs), so the image is never covered.
2. Verify across the day memories area and the task attachments area; confirm close returns focus correctly and the parent dialog stays usable afterward.

**Acceptance:**

- [ ] Tapping a photo shows it on top; nav/close work; no backdrop or dialog sits over the image

### Task 2: Photo Decoration Model (4h)

**Steps:**

1. Extend the decoration model to support a `photo` kind: add `attachmentId: string | null` and a cached `src`/`thumbSrc` to `Decoration` (keep `x/y/rotation/scale`); update `normalizeDecoration` and the `DecorationKind` union (`isDecorationKind`).
2. `weeksRepo` decoration writers already persist the array — ensure photo decorations round-trip; cap the count sensibly; `firestore.rules` allow the new fields.

**Acceptance:**

- [ ] A photo decoration round-trips on the week doc offline; invalid/missing fields are normalized safely

### Task 3: Pin-to-Page Flow (5h)

**Steps:**

1. Add a "Pin to day" / "Закріпити на сторінці" action on an image — from the `Lightbox` and/or the `AttachmentGrid` image item — that creates a `photo` decoration for the current week/day at a default position referencing the attachment.
2. Render placed photos in the `DecorationLayer`: an `<img>` (use the thumb for the layer, full on open) in a cozy polaroid frame (soft border, slight shadow, optional rotation), tinted-frame per theme.
3. Reuse the existing sticker placement/transform interactions (move/rotate/scale/remove) for photo decorations — view mode passes pointer events through to tasks; edit mode makes them draggable.

**Acceptance:**

- [ ] Pinning an image places a draggable polaroid on the spread; move/rotate/scale/remove work on desktop + phone; view mode doesn't block tasks

### Task 4: Attachment Linkage & Cleanup (4h)

**Steps:**

1. Keep placed photos consistent with their source attachment: if the attachment is deleted, remove (or visibly empty) its placed photo decorations.
2. Refresh `src`/`thumbSrc` if the attachment URL changes; handle a missing source gracefully (placeholder, removable).

**Acceptance:**

- [ ] Deleting the image removes its placed photo; deleting a placed photo keeps the image; missing sources don't break the layer

### Task 5: i18n, A11y & Sweep (3h)

**Steps:**

1. en + uk for the pin action, photo-frame labels, and any new controls; alt text from the attachment `name`.
2. A11y: placed photos have accessible names; edit-mode transforms reachable; lightbox keyboard nav intact.
3. Token/contrast sweep (polaroid frame across themes), real-phone test of pinning + lightbox.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; i18n missing-key warnings zero
