# Phase 8 - Build / Release Log

Internal record (docs/ is gitignored). Records what was implemented in code and what remains an owner action (deploy, real-device, domain).

## What shipped (code)

### Task 1 - PWA
- `vite-plugin-pwa` (`registerType: "prompt"`, `injectRegister: false`). Manifest: name/short_name "SnugWeek", uk description, `display: standalone`, `start_url:/`, `background_color`/`theme_color` = `#faf6ef` (milk paper), icons 192/512 + maskable.
- Workbox `generateSW`: precaches build assets (`js,css,html,svg,ico,webmanifest`); fonts (`*.woff2`) are runtime-cached CacheFirst, 1y. Firestore traffic is cross-origin and bypasses the SW (IndexedDB already covers data).
- `UpdatePrompt.tsx` (`useRegisterSW`) - bottom toast "Нова версія SnugWeek - оновити?" → `updateServiceWorker(true)`. Mounted always in `Root` (so registration happens on load).
- iOS: `apple-touch-icon`, `apple-mobile-web-app-*` meta, `viewport-fit=cover`.

### Task 2 - Icons & meta
- Brand mark: cozy notebook page with a folded corner + checklist lines on a rose gradient. Sources in `scripts/assets/` (`icon.svg`, `icon-maskable.svg`, `og.svg`); `npm run gen:assets` rasterizes via sharp → `public/` (pwa-192/512, maskable-512, apple-touch-180, favicon.ico, favicon.svg, og-image 1200×630).
- `index.html`: title, uk description, `og:*` + `twitter:card` (summary_large_image), theme-color.
- Runtime `theme-color` meta synced to the active theme's `--sw-paper` in `Root`.
- Note: `og:image`/`twitter:image` use root-relative `/og-image.png`. Most crawlers resolve these against the page URL; switch to absolute URLs once the production domain is connected if a validator complains.

### Task 3 - Performance
- Chunking (gzip, measured from `npm run build`):
  - **Main entry `index`: 218.7 KB gzip** - under the 250 KB target.
  - `firebase` split out: 130.6 KB gzip (excluded from budget by design).
  - `StatsPage` (charts/recharts) lazy on `/stats`: 121.7 KB gzip.
  - `WeekJumpCalendar` (`@mantine/dates`) lazy on calendar open: 8.4 KB gzip.
  - Shared `time` (dayjs+locales) 22.9 KB, `profileStore` (app services) 26.7 KB.
  - **Total initial JS excluding firebase ≈ 268.7 KB gzip** (entry + runtime + time + profileStore).
- Optimizations applied this phase: firebase split (pre-existing), charts already lazy; **`@mantine/dates` deferred** (lazy calendar), **MonthPage/SettingsPage made lazy**, **Motion switched to `LazyMotion` + `m` + `domAnimation`** (no gestures/layout are used, so domAnimation is feature-complete) - this dropped the initial from ~296 → ~269 KB gzip.
- Budget status: the **entry bundle (218.7) is within the 250 KB target**; the **total initial (≈268.7) is ~19 KB over** once the shared dayjs and app-service chunks are counted. The remaining weight is the irreducible React + Mantine + dnd-kit + dayjs + i18next baseline. The only further lever is deferring dnd-kit (~16 KB) which would land ~252 KB but requires restructuring the week board's `DndContext` - deferred as a post-launch optimization rather than a risky pre-release refactor. **Owner decision: accept ≈269 KB, or invest in the dnd-kit deferral.**
- `index.html` preconnects to `firestore.googleapis.com`, `identitytoolkit.googleapis.com`, `securetoken.googleapis.com`.
- Font subsets already limited to used weights (Nunito 400/600/700, Caveat 400/600).

Owner actions (need prod URL / device):
- [ ] Lighthouse on the production URL (desktop + mobile): PWA installable, perf ≥ 90 / ≥ 80, a11y ≥ 95.
- [ ] Fold-transition trace on a mid-range Android phone after install.
- [ ] Firestore read audit during a session walkthrough (open week ≤ 2 listeners; month ≤ 1 query + ≤ 6 doc reads).

### Task 4 - Robustness
- `ErrorBoundary` (class, the one sanctioned non-arrow component - React has no hook-based boundary) at `Root` wraps the router; cozy `ErrorFallback` (mug doodle + "щось пішло не так" + reload). Logs error + component stack.
- Route guards: `time.ts` now bounds years to **2020–2100** in `isValidWeekId` / `isValidMonthId` / `isValidYear`, so absurd week/month/year ids and `/stats?p=` garbage redirect or fall back to current.
- Auth bootstrap failure: `authStore` gains an `error` status + `retry()`. On first-launch anonymous sign-in failure (offline, no prior session) `Root` shows `AuthErrorScreen` (moon doodle + retry) instead of an infinite splash.
- Read failures: `onSnapshot` error callbacks route through `reportReadError` → a throttled friendly "не вдалося завантажити" notification (skipped when offline / unavailable / not signed-in). Writes keep the Phase-2 friendly save-error notification.
- `beforeunload` is not used; the offline write queue makes it unnecessary.

### Task 5 - Release checklist
- `README.md` rewritten (public-safe: what it is, stack, env setup, scripts, deploy, license - no roadmap internals).
- `.env.local.example` matches the 6 `VITE_FIREBASE_*` vars used by `services/firebase.ts`. No secrets in the repo.
- `LICENSE` is MIT (pre-existing, kept). If a private/all-rights-reserved stance is preferred, that's an owner change.
- `firestore.rules` present and validated (Phase 7 shape checks). Diff vs deployed = owner check via Firebase console / CLI.

Owner actions:
- [ ] Confirm Vercel env vars complete on the production project.
- [ ] Rules file vs deployed diff = none (App Check off for v1 - roadmap note; quota alerts at 80% of free tier).
- [ ] Purchase/connect production domain; add to Vercel + Firebase authorized domains; re-run auth smoke on the final origin.
- [ ] Tag `v1.0.0`.

## Smoke matrix (run on the production domain)

Each cell: open · add/complete/drag a task · switch week (fold) · edit a tracker · go offline and back · switch theme.

- [ ] Desktop Chrome
- [ ] Desktop Firefox
- [ ] Desktop Safari
- [ ] Android Chrome (installed PWA, cold offline launch)
- [ ] iOS Safari (installed PWA, cold offline launch)

## Verify after build

- `npm run build` is green (tsc + vite); `npm run lint` clean.
- `npm run preview`, install the app, redeploy/rebuild, confirm the "Нова версія" prompt appears and reload swaps the build.
- DevTools → Application → Manifest (icons, theme color), Service Worker (activated), offline reload renders shell + last data.
