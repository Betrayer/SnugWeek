# SnugWeek - Technical Design Document

**Status:** v1 scope locked, ready for Phase 1 implementation
**Last updated:** 2026-06-13

## Pitch

**SnugWeek** - a cozy weekly planner-journal that feels like a paper notebook with superpowers. One spread = one week: task columns per day, a sidebar with backlog lists ("Задачі", "Ідеї та мрії", custom), drag-and-drop planning, day mood/energy trackers, a habit grid, a free-form week note. Pages turn with a notebook-like fold animation. Unfinished tasks carry over automatically. Multiple cozy color themes. Works fully offline, syncs when online. Anonymous-first: open the app and start writing, attach an account later without losing anything.

**Audience:** people who love paper planners and bullet journals but want carry-over, stats and sync. Wide consumer audience, "girly"/cozy aesthetic, desktop and mobile from day one.

**Platforms (v1):** responsive web app (desktop + mobile layouts), installable PWA. Telegram Mini App wrapper - post-v1 roadmap.

## Tech Stack (locked)

| Layer | Choice | Rationale |
|-------|--------|-----------|
| Build | Vite 8 + TypeScript 6 (strict) | Owner's standard stack |
| UI | React 19 + Mantine 9 | Owner's standard; no emotion |
| Dates UI | @mantine/dates 9 + dayjs | Calendar popover; dayjs (+isoWeek) for all week math |
| State | Zustand 5 | devtools(persist(...)) pattern from Klikta |
| Backend | Firebase 12 (Firestore + Auth) | Anonymous-first auth; free tier covers launch |
| Offline | Firestore `persistentLocalCache` (multi-tab) + vite-plugin-pwa | Native offline queue + latency compensation; PWA shell cache |
| DnD | @dnd-kit (core + sortable) | Pointer/touch/keyboard sensors, DragOverlay for cozy drag visuals |
| Animation | Motion (`motion/react`) | Page-fold transitions, micro-interactions |
| Routing | react-router 7 | Shareable URLs per week/month, back button |
| Charts | @mantine/charts 9 | Stats; themes natively follow Mantine palette |
| i18n | i18next + react-i18next | en = source language, uk = default UI language |
| Fonts | @fontsource/nunito + @fontsource/caveat | Full Cyrillic coverage, cozy pairing |
| Hosting | Vercel | Owner's existing flow |

**Banned:** external icon libraries (inline SVG or emoji only), additional UI frameworks, Tailwind, CSS-in-JS beyond Mantine's own, `any`, enums, default exports, code comments.

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  React pages & components (shell/)                   │
│  WeekPage / MonthPage / StatsPage / SettingsPage     │
└──────────────┬───────────────────▲──────────────────┘
               │ actions           │ hooks (read)
┌──────────────▼───────────────────┴──────────────────┐
│  Zustand stores (state/)                             │
│  authStore / profileStore / weekStore / listsStore / │
│  settingsStore (device-local) / uiStore (transient)  │
└──────────────┬───────────────────▲──────────────────┘
               │ repo calls        │ onSnapshot feeds
┌──────────────▼───────────────────┴──────────────────┐
│  Services (services/)                                │
│  firebase.ts / repos/* / carryOver.ts / migration.ts │
│  / time.ts (dayjs singleton)                         │
└──────────────┬───────────────────────────────────────┘
               ▼
        Firestore (persistentLocalCache, multi-tab)
```

Rules of the flow:

- **Components never import `firebase/*`.** All Firestore IO lives in `services/repos/*` (plain arrow-function modules, one collection per file).
- **Stores mirror snapshots.** Repos expose `subscribeX(uid, ..., cb)`; stores own subscription lifecycle and hold the mirrored data. Components read stores via hooks.
- **No manual optimistic-update layer.** Firestore latency compensation fires local snapshot events synchronously (even offline), so a write through a repo is reflected in the UI immediately via the same snapshot path. `SnapshotMetadata.hasPendingWrites` + `navigator.onLine` drive the sync badge.
- **Everything works offline.** No UI is gated on a network round-trip. Writes queue in IndexedDB and sync automatically.
- **Dates only through `services/time.ts`** - a single configured dayjs instance (plugins: `isoWeek`, `localeData`, `customParseFormat`; locales `uk`, `en`). No other module imports `dayjs` directly.

## Responsive strategy

One codebase, two arrangements of the same building blocks. The shared atom is `DayColumn` (header + tracker row + task list + composer); layouts differ only in how columns are arranged.

| | Desktop (≥ `md`, 992px) | Mobile (< `md`) |
|---|---|---|
| Week | `WeekBoard`: CSS grid, Mon–Fri wide columns + Sat/Sun stacked in one narrow column (`columnMode: "cozy"`), or 7 equal (`"equal"`) | `MobileDayPager`: swipeable day cards, dot indicator Mon–Sun, opens on today |
| Sidebar lists | Right panel behind a perforated-edge divider, collapsible | Drawer from a header button |
| Week navigation | Header arrows, keyboard, fold animation | Header arrows (fold), swipe inside pager switches days |
| DnD | Full: reorder, day↔day, sidebar↔day | Reorder within a list (long-press); cross-day / cross-list moves via task menu "Move to…" picker |
| Habits / note | Bottom strip under the grid | Sections below the pager (scroll) |
| Nav | Header links | Bottom tab bar: Week / Month / Stats / Settings |

No `isMobile` forks inside leaf components - the arrangement is decided once at the page/layout level (`useMediaQuery` over Mantine breakpoints).

## Routing

| Route | Screen |
|---|---|
| `/` | redirect to `/w/{currentWeekId}` |
| `/w/:weekId` | week board (`weekId` = ISO week, e.g. `2026-W24`; invalid → redirect to current) |
| `/month/:monthId` | month overview (`2026-06`) |
| `/stats` | statistics |
| `/settings` | settings (themes, trackers, modules, account, language) |

`weekId` validation: `/^\d{4}-W\d{2}$/` + range check via `time.ts`. Weeks are ISO-8601, Monday-first, zero-padded (`W01…W53`) so string comparison equals chronological comparison.

## Data model (Firestore)

All user data lives under `users/{uid}` - owner-only access.

```
users/{uid}                          profile (single doc)
users/{uid}/tasks/{taskId}           every task, wherever it lives
users/{uid}/lists/{listId}           sidebar lists
users/{uid}/weeks/{weekId}           per-week journal data
users/{uid}/trackers/{trackerId}     day-tracker definitions
users/{uid}/habits/{habitId}         habit definitions
users/{uid}/stats/{YYYY-MM}          monthly aggregates (increment-only)
users/{uid}/migrations/{anonUid}     account-merge markers (Phase 7)
```

### `users/{uid}` - profile

```ts
{
  schemaVersion: 1,
  createdAt, updatedAt: number,        // epoch ms everywhere
  themeId: "milk",
  moduleToggles: { dayTrackers: true, habits: true, weekNote: true },
  weekend: [6, 7],                     // ISO day numbers, default Sat+Sun
  columnMode: "cozy" | "equal",
}
```

### `users/{uid}/tasks/{taskId}` - flat location fields (simpler rules & indexes than a nested map)

```ts
{
  title: string,                       // 1..500 chars
  status: "open" | "done",
  bucket: "day" | "list",
  weekId: string | null,               // set iff bucket === "day"
  day: number | null,                  // ISO 1..7, iff bucket === "day"
  listId: string | null,               // set iff bucket === "list"
  order: number,                       // fractional ordering
  createdAt, updatedAt: number,
  completedAt: number | null,
  carriedFrom: string | null,          // weekId the task was auto-carried from
}
```

### `users/{uid}/lists/{listId}`

```ts
{
  kind: "tasks" | "ideas" | "custom",  // builtin docs use fixed ids "tasks", "ideas"
  name: string | null,                 // custom only; builtin names come from i18n
  order: number,
  createdAt: number,
}
```

Builtin lists are seeded idempotently (`setDoc(..., { merge: true })`) on first auth. Deleting a custom list re-homes its tasks to `tasks`.

### `users/{uid}/weeks/{weekId}` - created lazily on first write; absence renders as defaults

```ts
{
  note: string,
  daysOff: number[] | null,            // null → fall back to profile.weekend
  trackerValues: { [day: string]: { [trackerId: string]: number | string | boolean } },
  habitChecks: { [habitId: string]: { [day: string]: true } },
  updatedAt: number,
}
```

Day keys inside maps are strings `"1".."7"`. Tracker/habit writes use dotted-path `updateDoc` (`trackerValues.3.mood`) so concurrent devices merge field-wise.

### `users/{uid}/trackers/{trackerId}`

```ts
{
  name: string,
  type: "scale5" | "emoji" | "number" | "checkbox",
  icon: string,                        // emoji char or registry key of an inline SVG
  order: number,
  enabled: boolean,
  createdAt: number,
}
```

Seeded defaults: `mood` (emoji), `energy` (scale5).

### `users/{uid}/habits/{habitId}`

```ts
{ name: string, icon: string | null, order: number, archived: boolean, createdAt: number }
```

### `users/{uid}/stats/{YYYY-MM}` - written only via `increment()`

```ts
{ tasksCompleted: number, perDay: { [isoDate: string]: number }, updatedAt: number }
```

### Ordering

`order` is a float. New item at top = `minOrder - 1024`, at bottom = `maxOrder + 1024`, between = midpoint. When a gap falls below `1e-6`, the repo renormalizes the affected container (batch write, `i * 1024`). Never persist array indexes.

### Composite indexes

Created on demand via the console links Firestore prints, expected set:

- `tasks`: `bucket ASC, weekId ASC` (week subscription)
- `tasks`: `bucket ASC, listId ASC, order ASC` (list subscription)
- `tasks`: `bucket ASC, status ASC, weekId ASC` (carry-over query)
- `tasks`: `status ASC, completedAt ASC` (stats backfill, Phase 6)

## Core algorithms

### Carry-over (lazy, client-side, idempotent)

Trigger: once per session after auth is ready, and on `visibilitychange → visible` (throttled to 1/hour).

1. `cur = currentWeekId()`.
2. Query `tasks` where `bucket == "day" && status == "open" && weekId < cur`, ordered by `weekId`, limit 300.
3. For each: batched update → `{ bucket: "list", listId: "tasks", weekId: null, day: null, carriedFrom: <oldWeekId>, order: <descending top placement>, updatedAt }`.
4. Repeat until the query is empty (batch ≤ 500 writes).

Idempotency is structural: moved tasks leave the query's result set. Offline: the query runs against the local cache and the writes queue. Two devices racing converge to the same end state (doc-level last-write-wins). Browsing past weeks never triggers carry-over - only the session-start/visibility hook does.

### Monthly aggregates

On task completion: `increment(+1)` on `tasksCompleted` and `perDay.<today>` in `stats/{month-of-today}`. On un-completion: `increment(-1)` on the month/day derived from the stored `completedAt`. Increments merge correctly offline and across devices. Habit/tracker statistics are not aggregated - they're computed on demand from `weeks` docs (≤ 53 reads/year, cached locally).

### Anonymous → existing-account merge (Phase 7)

Linking (`linkWithPopup` / `linkWithCredential`) keeps the uid, so data survives with zero work - that's the happy path. The merge path covers `auth/credential-already-in-use` / `auth/email-already-in-use`:

1. Capture `anonUid` and the conflicting credential; explain to the user ("акаунт уже існує - об'єднати дані?").
2. `signInWithCredential` → now authed as `targetUid`; the anon subtree is still readable? **No** - rules are owner-only, so the export must happen *before* sign-in: read all anon docs into memory (collections are small), then sign in, then write.
3. Write `migrations/{anonUid}` marker `{ status: "pending", startedAt }` under target.
4. Batched copy with merge rules: `tasks`, `habits`, `trackers`, custom `lists` - copied as new docs; builtin lists - contents merge by definition (tasks just point at `listId`); `weeks` - deep-merge maps (`trackerValues`, `habitChecks` union; `note` concatenated with a separator if both non-empty; scalars: target wins); `stats` - `increment()` by anon values.
5. Mark `{ status: "done", finishedAt }`; sign back into the anon user is impossible - instead, before step 2, the anon user data was exported; after success, best-effort cleanup: re-auth anon is not possible, so anon orphan data is left and purged by a TTL note in roadmap. v1 accepts the orphan (invisible, owner-only, costs nothing at this scale).
6. Crash mid-way: marker `pending` + idempotent copy (deterministic new-doc ids derived as `m_{anonUid}_{oldId}`) → safe to re-run from the in-memory export; if the export is lost (page closed), the anon session still exists locally until sign-in completed - the flow only signs into the target after the export snapshot is taken.

UI shows a progress modal; on completion the app reloads subscriptions under `targetUid`.

## Auth & account lifecycle

- App boots → `signInAnonymously` if no persisted user. Zero-friction start.
- Header shows a soft CTA for anonymous users: "Зберегти акаунт" → AuthModal (Google button + email/password) → **link** (uid preserved, data intact, no migration).
- If the credential already belongs to an account → merge flow above.
- Sign-out from a linked account → confirm dialog (data is safe in the cloud; the device starts a fresh anonymous session). Sign-in later → normal `signInWithPopup`/`signInWithEmailAndPassword`; if the current session is anonymous *and has data*, offer the merge flow instead of plain sign-in.
- `authStore` state: `{ status: "init" | "ready", uid, isAnonymous, providerIds, displayName, email }`.

## Offline & sync

- `initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) })` - IndexedDB cache + write queue shared across tabs.
- Auth persistence: default (`indexedDBLocalPersistence`).
- Sync badge: `navigator.onLine === false` → "Офлайн - зміни зберігаються локально" pill in the header; pending-writes nuance refined in Phase 7.
- PWA (Phase 8): app-shell precache + font runtime cache so a cold offline launch works.
- Settings split: synced (in the profile doc) - `themeId`, `moduleToggles`, `weekend`, `columnMode`; device-local (`settingsStore`, zustand persist) - `language`, `reduceMotion`, `transition`.

## Theming

Data-driven registry, Klikta-style: a theme is pure data, components know nothing about specific palettes.

```ts
interface ThemeSpec {
  id: string;
  kind: "light" | "dark";
  vars: Record<string, string>;        // CSS custom properties, --sw-*
  mantine: MantineThemeOverride;       // primaryColor, colors, components defaults
  preview: { paper: string; accent: string; ink: string };
}
```

- Applying a theme = set `data-snug-theme="<id>"` on `<html>` (+ Mantine `forceColorScheme` by `kind`) and pass the merged Mantine theme to `MantineProvider`. `tokens.css` holds the var blocks per theme id.
- **Token set:** `--sw-paper`, `--sw-paper-2`, `--sw-card`, `--sw-ink`, `--sw-ink-2`, `--sw-ink-3`, `--sw-line`, `--sw-accent`, `--sw-accent-2`, `--sw-accent-ink`, `--sw-highlight`, `--sw-done`, `--sw-danger`, `--sw-shadow`, `--sw-paper-texture` (url or `none`), `--sw-font-body`, `--sw-font-hand`.
- **Zero hardcoded colors in components** - only tokens or Mantine theme values. This rule starts in Phase 1 so Phase 5 is "add palettes", not "repaint the app".
- v1 palettes: `milk` (default warm cream), `lavender`, `sage`, `peach`, `midnight` (dark). New theme = one data file + var block, zero component changes.
- Fonts: Nunito (body), Caveat (handwritten accents: week note, list headers, empty states). Both ship full Cyrillic.

## Week transitions

```ts
type TransitionId = "fold" | "none";   // "curl" reserved, see below

interface WeekTransition {
  id: TransitionId;
  variants: (direction: 1 | -1) => MotionVariants;  // enter/exit for the page surface
}
```

- `WeekTransitionHost` wraps the week surface, keyed by `weekId`, inside Motion `AnimatePresence` with `custom={direction}`.
- **`fold` (default):** perspective container (~2000px); exiting page rotates `rotateY` toward the spine (origin left edge going forward, right edge going back, ~-70°), with an animated shading gradient overlay; entering page settles from a slight counter-angle. ~450 ms, custom ease. Reads as a notebook page turn without snapshots, stays interactive-safe and 60fps.
- `none`: instant swap. Auto-selected when `prefers-reduced-motion` or `settingsStore.reduceMotion`.
- **`curl` (reserved, post-v1 option):** realistic corner-curl. Requires rasterizing the outgoing page to a static snapshot for the duration of the animation (DOM clone or canvas), because live DnD content cannot be deformed. The registry and settings picker are built so adding `curl` is a new entry + implementation file, no host changes.

## i18n

- i18next + react-i18next; namespaces: `common`, `week`, `tasks`, `trackers`, `stats`, `settings`, `auth`.
- **en is the source language** (keys authored in `src/locales/en/*.json`); **uk is the default UI language** and is hand-authored with the same keys (machine translation is not acceptable for the default language of a cozy product). Locales lazy-load per language via `import.meta.glob` (one chunk per language) - Klikta pattern.
- `language` lives in `settingsStore` (device-local), default `uk`; switching also flips the dayjs locale (week/month labels).
- Klikta's DeepL/Claude translate pipeline can be ported post-v1 if more languages are added; with two hand-maintained languages it is not needed.

## Project structure

```
src/
  main.tsx
  Root.tsx                       MantineProvider + theme, i18n init, RouterProvider
  shell/
    layout/                      AppShell.tsx HeaderBar.tsx SidebarPanel.tsx MobileTabBar.tsx SyncBadge.tsx
    pages/                       WeekPage.tsx MonthPage.tsx StatsPage.tsx SettingsPage.tsx
    components/
      week/                      WeekBoard.tsx DayColumn.tsx DayHeader.tsx WeekendStack.tsx MobileDayPager.tsx
      tasks/                     TaskList.tsx TaskCard.tsx TaskComposer.tsx MoveTaskMenu.tsx
      sidebar/                   ListSection.tsx ListsPanel.tsx AddListControl.tsx
      trackers/                  DayTrackerRow.tsx TrackerControl.tsx TrackerSettings.tsx
      habits/                    HabitGrid.tsx HabitSettings.tsx
      note/                      WeekNote.tsx
      transitions/               WeekTransitionHost.tsx transitions.ts (registry) fold.ts
      calendar/                  WeekJumpPopover.tsx
      month/                     MonthGrid.tsx MonthDayCell.tsx
      stats/                     (Phase 6)
      auth/                      AuthModal.tsx AccountMenu.tsx (Phase 7)
    hooks/                       useIsMobile.ts useWeekParam.ts ...
  state/                         authStore.ts profileStore.ts settingsStore.ts weekStore.ts listsStore.ts uiStore.ts
  services/
    firebase.ts                  app/auth/db init, persistentLocalCache
    time.ts                      dayjs singleton + week/month helpers
    carryOver.ts                 (Phase 3)
    migration.ts                 (Phase 7)
    repos/                       profileRepo.ts tasksRepo.ts listsRepo.ts weeksRepo.ts trackersRepo.ts habitsRepo.ts statsRepo.ts
    ordering.ts                  orderBetween / renormalize helpers
  data/
    themes/                      types.ts registry.ts milk.ts lavender.ts sage.ts peach.ts midnight.ts
    defaults.ts                  builtin lists, default trackers, seed content
  i18n/                          index.ts languages.ts
  locales/                       en/*.json uk/*.json
  styles/                        global.css tokens.css
```

One responsibility per file. Stores in `state/` only; no React Context for app state (Mantine's own providers excepted).

## Security rules (sketch; hardened in Phase 7)

```
match /users/{uid} {
  allow read, write: if request.auth != null && request.auth.uid == uid;
  match /{collection}/{doc} {
    allow read, write: if request.auth != null && request.auth.uid == uid;
  }
}
```

Phase 7 adds shape validation: `title` size 1..500, `status`/`bucket` whitelists, bucket-field consistency (`bucket == "day"` → `weekId`/`day` set and `listId == null`, and vice versa), numeric type checks, `updatedAt is number`.

## Performance budgets

- Initial JS (gzip): ≤ 250 KB excluding the firebase chunk; firebase split into its own chunk (Klikta `advancedChunks` pattern); charts lazy-loaded with the stats route.
- Week switch (fold) holds 60 fps on a mid-range Android phone; transform/opacity-only animation, no layout thrash.
- Week open: ≤ 2 snapshot subscriptions (week doc + week tasks query); month view: ≤ 6 week-doc reads + 1 tasks query.
- Lighthouse (Phase 8 gate): PWA installable; performance ≥ 90 desktop / ≥ 80 mobile.

## Out of scope v1 → roadmap

Recurring tasks; reminders/notifications; sharing a week (read-only link); realistic `curl` page transition; Telegram Mini App wrapper; data export (JSON); orphaned-anon-data TTL cleanup; more palettes & seasonal themes; tablet-optimized split layout; home-screen widgets.
