# SnugWeek - Phase 16: Attachments

**Goal:** tasks, days, and lists can hold memories and references - photos, voice notes, video, files, and links. Images are compressed with thumbnails, voice notes record in-app, links are stored as lightweight cards. All owner-only, themed, with a clean storage abstraction so the backend can be swapped.

**Duration:** ~2–2.5 weeks part-time (~32 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §1, §5, §8. Depends on Phase 10 (the **Task Detail** surface and the shared `BottomSheet` primitive host the task-level attachments UI).

---

## Owner decision before starting (storage backend)

As of **2026-02-03 Firebase Cloud Storage requires the Blaze plan** even for the default bucket (the free "Always Free" allowance still applies, but a billing account must be linked). Pick one before Task 1:

- **A - Firebase Storage (recommended for cohesion):** same SDK/Auth/rules; link a billing account and set a low **budget alert**. Use a free-tier region.
- **B - Cloudflare R2:** cheapest at scale, but needs a tiny Worker for presigned URLs (extra backend).
- **C - Cloudinary / Supabase Storage:** generous media free tiers / transforms, separate service + auth.

This plan is written for **A** but all IO is behind `services/storage/storageService.ts`, so B/C is a swap of that one module.

---

## Definition of Done

- [ ] A task shows a 📎 count when it has attachments; opening it reveals an attachments area to add/view/remove
- [ ] A day (week column / mobile day card) has a small media strip ("спогади"); a list has a reference-files area under its header
- [ ] **Images:** add via picker, drag-drop (desktop), or clipboard paste; auto-compressed with a thumbnail; shown in a grid; open in a themed lightbox; delete works
- [ ] **Voice notes:** record in-app (mic) and/or pick an audio file; play inline in a cozy themed player; duration shown
- [ ] **Video:** pick a video (size-capped) with an optional poster frame; play inline; **Files:** any type within the cap, shown as a chip with name/size and download
- [ ] **Links:** add a URL; stored as a card with best-effort title/favicon; opens in a new tab; works offline (it's just a doc)
- [ ] Uploads show progress and fail gracefully; while offline, file pickers are disabled with a gentle hint but link attachments still work
- [ ] Storage security rules enforce owner-only paths, content-type allowlist, and size caps; deleting an attachment removes its storage object(s)
- [ ] Attachment counts stay correct across add/remove (denormalized, same-batch); all strings en + uk; build/lint/tsc clean; no console errors

**Out of scope:** image editing/filters, audio/video trimming, server-side link unfurling/scraping, cross-target moving of attachments, gallery search, EXIF stripping beyond what re-encoding drops (note: re-encoding via canvas already drops most metadata).

---

## Task Breakdown

### Task 1: Storage Backend & Rules (4h)

**Steps:**

1. If **A**: link the Firebase project to Blaze, set a budget alert, provision the default bucket in a free-tier region; add the bucket to `services/firebase.ts` (`getStorage`). If **B/C**: stand up the chosen backend and credentials.
2. `src/services/storage/storageService.ts`: `uploadFile(uid, path, blob, onProgress) → { path, url }` (resumable for A), `getDownloadUrl(uid, path)`, `deleteObject(path)`, and `attachmentPath(uid, attachmentId, kind, ext)` helpers. This is the **only** module touching the storage SDK.
3. Storage security rules (for A): owner-only `users/{uid}/**`; `request.resource.size` caps (images ≤ 10 MB, audio/video ≤ ~50 MB); `request.resource.contentType` allowlist (`image/*`, `audio/*`, `video/*`, plus a sensible doc set). Deploy.

**Acceptance:**

- [ ] A manual upload/download/delete round-trips for the chosen backend; oversized/disallowed uploads are rejected by rules

### Task 2: Attachments Model & Repo (4h)

**Steps:**

1. `src/services/repos/attachmentsRepo.ts`: the `Attachment` type per addendum §1; `normalizeAttachment`; `subscribeTaskAttachments(uid, taskId, cb)`, `subscribeListAttachments(uid, listId, cb)`, `subscribeDayAttachments(uid, weekId, day, cb)` (each ordered by `order`).
2. `addAttachment(uid, attachment)` and `removeAttachment(uid, attachment)`: when the target is a task or list, adjust the parent's `attachmentCount` (`increment(±1)`) in the **same `writeBatch`**; on remove, also `deleteObject` for `storagePath`/`thumbPath` (best-effort).
3. Extend `Task` with `attachmentCount: number` (default 0) in `normalizeTask`; `firestore.rules` task validator allows `attachmentCount >= 0`. Add the `attachments` composite indexes (addendum §1) from the console links.
4. A small `useTargetAttachments` hook pattern (or per-surface store slices) consistent with existing stores - subscribe only for the open target.

**Acceptance:**

- [ ] Adding/removing a doc-only attachment (e.g. a link) updates `attachmentCount` and the 📎 indicator; subscriptions are scoped and torn down on close

### Task 3: Image Attachments (6h)

**Steps:**

1. Client-side pipeline (`services/storage/imageProcessing.ts`, canvas-based, no dependency): from a `File`, produce a capped original (~max 1600px, re-encoded JPEG/WebP at a sensible quality) + a thumbnail (~320px); read `width/height`. Re-encoding drops most EXIF.
2. Add flows: file picker (`accept="image/*"`, `multiple`), desktop drag-drop onto the attachments area, and clipboard paste (`paste` event → image). Each → compress → `uploadFile` (original + thumb) → `addAttachment({ kind: "image", ... })` with a progress indicator per file.
3. Display: a responsive thumbnail grid; click → a themed lightbox (Mantine `Modal` full-ish, paper bg, prev/next, delete). Tokens only.
4. Offline: pickers/drop disabled with a hint; no broken states.

**Acceptance:**

- [ ] Adding several photos compresses + uploads with progress; grid + lightbox work; a 12 MP photo lands well under the cap; delete removes doc + objects + decrements count

### Task 4: Voice Notes & Audio (5h)

**Steps:**

1. In-app recorder (`MediaRecorder`): a cozy record button (mic permission requested on first use), waveform-ish or a simple animated level/elapsed timer while recording, stop → preview → save (upload + `addAttachment({ kind: "audio", durationMs })`). Choose a broadly-supported mime (e.g. `audio/webm;codecs=opus`, fallback `audio/mp4` where needed via `MediaRecorder.isTypeSupported`).
2. Also support picking an audio file (`accept="audio/*"`).
3. Playback: a themed inline player (custom controls over an `<audio>` element - play/pause, elapsed/duration, a slim seek bar) styled with tokens; show duration.
4. Permission denial for mic → graceful message; file picking still available.

**Acceptance:**

- [ ] Record → preview → save → play back round-trips on desktop and mobile; duration is correct; mic-denied degrades to file pick

### Task 5: Video & Generic Files (5h)

**Steps:**

1. Video: picker (`accept="video/*"`, size-capped); optional poster frame grabbed via a hidden `<video>` + canvas at ~t=0.5 s (best-effort; skip if it fails); upload + `addAttachment({ kind: "video", durationMs, thumbPath? })`.
2. Playback: inline `<video>` with `preload="metadata"`, poster, themed container; open larger in a modal if desired.
3. Generic files: picker (`accept="*"` minus disallowed types per rules), size-capped; `addAttachment({ kind: "file", name, mime, size })`; display as a chip (icon by broad type via inline SVG, name, size, download link).
4. Enforce caps client-side **before** upload with a friendly message (don't rely only on rules rejecting after a long upload).

**Acceptance:**

- [ ] A capped video uploads with a poster and plays; an oversized file is refused client-side with a clear message; file chips download correctly

### Task 6: Link Attachments (3h)

**Steps:**

1. Add-link UI: a small input (URL validation, normalize scheme); store `addAttachment({ kind: "link", href, title, previewImage })`.
2. Best-effort metadata client-side only: try to derive a `title` (fallback to hostname) and a favicon (`https://<host>/favicon.ico` guess or a favicon service URL); **no** server scraping. CORS will block most page fetches - that's fine; the bare card (hostname + favicon + href) is the baseline.
3. Display: a compact link card (favicon, title/hostname, truncated href) opening in a new tab (`rel="noopener"`). Works fully offline.

**Acceptance:**

- [ ] Adding a link shows a tidy card and opens correctly; adding/viewing links works offline

### Task 7: Placement, Polish & Sweep (3h)

**Steps:**

1. Surface the attachments UI in all three places: **task** (a "Вкладення" section inside the Phase 10 Task Detail surface + a 📎 count on the card), **day** (a small media strip in `DayColumn` / mobile day card, gated sensibly so empty days stay clean), **list** (a reference area under the list header). Keep each calm and collapsible.
2. Empty states (Caveat one-liners + a tiny doodle) for "no attachments yet".
3. A lightweight "are you sure" on delete for media (not for links); confirm counts and storage cleanup.
4. i18n (en + uk), token + a11y sweep (lightbox/players keyboard-operable, focus traps, alt text from `name`), real-phone test across all kinds; verify offline behavior end-to-end.

**Acceptance:**

- [ ] All three placements work on desktop + phone; empty/offline states are graceful; full DoD passes in light + dark themes
