# SnugWeek — Phase 24: Day Board & Task Card Rework

**Goal:** make day columns look solid instead of flat and layered, move the add button into the day header, switch to a faster task interaction (click toggles, hover actions, no checkbox), center the empty-day label, and make custom weekends actually show.

**Duration:** ~2 weeks part-time (~28 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §8. Touches `DayColumn.tsx`, `DayHeader.tsx`, `TaskCard.tsx`, `TaskList.tsx`, `WeekBoard.tsx`.

---

## Definition of Done

- [ ] Day cards look tactile and distinct (one clear surface, soft elevation, clean internal spacing) with no muddy overlapping backgrounds; all 10 themes read well
- [ ] Each day has an obvious "+" add control in its header, next to the day kebab; chained entry still works; mobile quick-add unaffected
- [ ] Clicking a task row toggles done; hovering a row reveals three trailing icons — edit (inline title), open (Task Detail), delete (with confirm); the round checkbox is gone
- [ ] On mobile the three icons are always shown (compact, low-emphasis); tapping the title toggles done; long-press opens the detail
- [ ] A general (not per-task) task display-style setting controls how done tasks look (strikethrough / dimmed / dimmed+strikethrough / faded); switching it updates all rows live and persists
- [ ] An empty day shows its "Вільний день" label centered in the card's free space; non-empty days unaffected
- [ ] The off-day card style is clearly distinct (a stronger cozy weekend tint) and follows the actual weekend / per-week days-off for any selected days; Sat/Sun keep their stacked layout position
- [ ] Sound still plays on open→done only; build/lint/tsc clean; strings en + uk

**Out of scope:** the pencil strikethrough rendering (Phase 26 styles it), emoji on tasks (Phase 26).

---

## Task Breakdown

### Task 1: Day Card Visual Pass (5h)

**Steps:**

1. Resolve the layering in `DayColumn.tsx`: choose texture **on the card** xor **on the page** (not both) and remove the redundant one; give the card a real but soft elevation (token shadow + subtle border) and a single clean background.
2. Tighten internal spacing so `DayHeader`, `DayTrackerRow`, `MemoriesStrip`, the task list, and `DayNote` read as sections of one card, not stacked panes.
3. Keep today's accent and the off-day tint token-driven.

**Acceptance:**

- [ ] Day cards look tactile and distinct in every theme; no overlapping-background mush

### Task 2: Add Button In Day Header (3h)

**Steps:**

1. Move the primary add affordance into `DayHeader.tsx`, beside the `ActionMenu` kebab. It opens the day's `TaskComposer` (inline expand or focus).
2. Keep the existing composer behavior (IME-safe Enter, chained entry) and the mobile quick-add path.

**Acceptance:**

- [ ] Every day header has an obvious "+"; chained entry works; mobile add unaffected

### Task 3: New Task Interaction Model (6h)

**Steps:**

1. In `TaskCard.tsx`: clicking the row toggles done (route through the existing toggle that plays `playCheck` on open→done). Remove the round checkbox button.
2. Hover (desktop) reveals three trailing icons: **edit** (inline title edit in place), **open** (opens `TaskDetail` via `uiStore.openTask`), **delete** (existing confirm dialog).
3. Mobile: render the three icons always, compact and low-emphasis; tap on the title text toggles done; long-press opens the detail. Ensure DnD activation (drag) doesn't fight tap/long-press.

**Acceptance:**

- [ ] Click toggles; desktop hover icons work; mobile icons + tap-title-toggle + long-press-open work; no checkbox; DnD still works

### Task 4: Task Display-Style Setting (4h)

**Steps:**

1. Add a `taskDoneStyle` to the profile (synced): `strike` | `dim` | `dimStrike` | `fade`. Default `dimStrike`.
2. `TaskCard` renders the done appearance from this setting (replace the hardcoded `line-through` + ink-3 with style-driven rendering). A `setTaskDoneStyle` writer + `profileStore` mirror; a control in Settings → Appearance.

**Acceptance:**

- [ ] Switching the style updates all rows live and persists; every option reads well in all themes

### Task 5: Centered Empty-Day Label (2h)

**Steps:**

1. Make the empty-day state fill and center within the column's free space: adjust `TaskList`/`EmptyState` so when a day has no tasks the label sits centered vertically and horizontally, not top-aligned.

**Acceptance:**

- [ ] Empty day shows the label centered in the card; non-empty days unaffected

### Task 6: Custom Weekend Fix + Styling (4h)

**Steps:**

1. Strengthen the off-day card style: a clearly distinct, still-cozy weekend tint (not paper-2-≈-card) — add/adjust a token so the difference is visible in every theme.
2. Ensure the off-style follows `week?.daysOff ?? weekend` for **any** selected days (verify `WeekBoard`/`WeekendStack`/`DayColumn` apply `isOff` to the actual selected set).
3. Keep the cozy layout always stacking Sat/Sun in the narrow column (layout position fixed); only the off-color follows the setting. Confirm a non-Sat/Sun day off (e.g. Wednesday) is visibly styled.

**Acceptance:**

- [ ] Choosing Wednesday as a day off visibly styles Wednesday; Sat/Sun stay stacked and only carry the off-style if still in the weekend set; reads in all themes
