# SnugWeek - Phase 19: Privacy & Portability

**Goal:** treat the journal as personal - an optional app lock (PIN or device passkey/biometric) that gates entry, and full JSON export/import so the data is provably the user's to keep, back up, and restore.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §1, §2. Reuses merge/dedup ideas from `services/migration.ts`.

---

## Definition of Done

- [ ] Lock can be enabled with a PIN (and, where supported, a device passkey/biometric); when enabled, opening or returning to the app after the idle timeout shows a cozy lock screen that must be passed
- [ ] PIN is stored only as a salted hash on the device (never plaintext, never synced); passkey uses WebAuthn with the credential id stored locally; copy is honest that this is a device deterrent, not end-to-end encryption
- [ ] Auto-lock after a configurable idle period; manual "lock now"; forgetting the PIN has a clear (data-safe) recovery path documented (e.g. sign-out → data stays in the cloud; or a reset that disables the lock without touching data)
- [ ] Export downloads a complete, versioned JSON of the user's data (profile, tasks, lists, weeks, trackers, habits, tags, routines, stats; attachments as links/metadata)
- [ ] Import parses + validates a previous export and writes it idempotently (deterministic ids, deep-merge like account-merge), so re-importing the same file changes nothing; a progress + summary is shown
- [ ] All of it works offline where it can (lock fully; export over cache; import queues writes); strings en + uk; build/lint/tsc clean; no console errors

**Out of scope:** end-to-end encryption of stored data, re-uploading attachment binaries on import (links/metadata only), cross-account import merging beyond the documented dedup, server-side backups.

---

## Task Breakdown

### Task 1: Lock Core (4h)

**Steps:**

1. `services/lock/lockService.ts`: PIN set/verify using a salted hash (Web Crypto `subtle.digest` over PIN+random salt; store salt+hash in a device-local localStorage key, never in the store/profile). Passkey path via WebAuthn (`navigator.credentials.create/get`) storing the credential id locally; feature-detect and offer only where supported.
2. `settingsStore` (bump version): `lockEnabled` (default false), `lockMethod: "pin"|"passkey"|null`, `lockAfterMin` (default 5). PIN hash/salt + passkey id live in plain localStorage (sensitive), not the persisted store.
3. Idle tracking: a small idle timer (reset on interaction) + lock on `visibilitychange`/return after the timeout.

**Acceptance:**

- [ ] Setting a PIN and verifying works; passkey works where supported / hidden where not; nothing sensitive is synced

### Task 2: Lock Screen & Flow (4h)

**Steps:**

1. `shell/components/lock/LockScreen.tsx`: a cozy full-screen gate (paper + wordmark + PIN pad / passkey prompt), shown by a gate in `Root` when `lockEnabled` and locked. Blocks the app until passed; themed; reduced-motion-safe.
2. Settings → Замок: enable/disable (set/clear PIN or register passkey), change PIN, choose method, auto-lock minutes, "lock now". Honest copy about the deterrent nature + recovery.
3. Recovery: a documented, data-safe path - e.g. a "forgot PIN" that requires re-auth (sign-in) and then disables the lock, leaving all data intact (since data is owner-only in the cloud, not encrypted by the PIN).

**Acceptance:**

- [ ] Lock gates entry and post-idle return; recovery works and never destroys data; flows clear on desktop + phone

### Task 3: Export (3h)

**Steps:**

1. `services/portability/exportData.ts`: read all collections for the uid into a versioned JSON envelope (`{ schema: "snugweek-export@1", exportedAt, data: { profile, tasks, lists, weeks, trackers, habits, tags, routines, stats } }`); attachments included as their metadata + view URLs (no binaries). Trigger a file download (no storage needed).
2. Settings → Дані: an "Експортувати" action with a brief note on what's included.

**Acceptance:**

- [ ] Export produces a complete, well-formed JSON over cache (offline-friendly); large datasets export without hanging the UI (chunk reads if needed)

### Task 4: Import (5h)

**Steps:**

1. `services/portability/importData.ts`: parse + validate the envelope (version check, shape checks); write idempotently with deterministic ids (`imp_{sourceId}` or reuse source ids when safe) and deep-merge rules borrowed from `migration.ts` (weeks maps unioned, scalars: incoming vs existing per a documented rule, stats via increment or set - choose set-from-source for determinism). Batched writes (≤450), progress modal, summary (created/merged counts).
2. UI: an "Імпортувати" file picker with a confirm dialog explaining merge behavior; re-importing the same file is a no-op.
3. Validation/error UX: malformed or wrong-version files are rejected with a friendly message; partial failures are reported, state stays consistent.

**Acceptance:**

- [ ] Importing a prior export reconstructs the data; re-import changes nothing; bad files are refused gracefully

### Task 5: Rules, i18n & Sweep (3h)

**Steps:**

1. `firestore.rules`: ensure imported shapes pass the existing validators (no special rules needed if writes match v1/v0.2 shapes); confirm batch writes succeed.
2. en + uk for lock + export/import (and the honest privacy copy); a11y on the lock pad and dialogs.
3. Real-phone test (lock + biometric where available; export/import round-trip); offline checks; token/contrast sweep of the lock screen in all themes.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; i18n missing-key warnings zero
