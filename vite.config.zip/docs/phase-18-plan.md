# SnugWeek - Phase 18: Reflection & Focus

**Goal:** two small features that make the week feel rewarding and calm - a gentle weekly recap card (a kind end-of-week summary) and a cozy focus (Pomodoro) timer that can attach to a task and chimes through the Phase 9 sound system.

**Duration:** ~1 week part-time (~16 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §4. Depends on Phase 9 (sound) and the shipped stats (Phases 6).

---

## Definition of Done

- [ ] A weekly recap card assembles from existing data: tasks completed this week, a mood/energy trend glimpse, best/active habit streak, and a warm closing line; it appears on the week view on Sundays (dismissible) and as a permanent panel in Stats
- [ ] The recap reads correctly for sparse weeks (no NaN, graceful "тихий тиждень" copy) and respects module toggles (hides habit/tracker bits when those modules are off)
- [ ] A focus timer can be started (25/5 presets + a custom duration), optionally "focusing on <task>"; it counts down with a calm UI and chimes softly at phase boundaries (via the sound service, respecting the sound toggle/volume)
- [ ] The timer keeps correct time across tab backgrounding (wall-clock based, not naive interval drift) and survives a reload mid-session (device-local state); pausing/resetting works
- [ ] Optional: completed focus sessions per day surface as a small stat; no sync required for timer state
- [ ] Strings en + uk; reduced-motion respected; build/lint/tsc clean; no console errors

**Out of scope:** long-term focus analytics, strict Pomodoro rule enforcement, background notifications when the app is closed (timer is foreground), syncing timer state across devices.

---

## Task Breakdown

### Task 1: Weekly Recap Assembler (3h)

**Steps:**

1. `services/recap/weeklyRecap.ts`: from the week's tasks + week doc + stats helpers, compute `{ completed, total, completionPct, moodAvg?, energyAvg?, bestStreak?, topHabit? }` for a given `weekId`. Reuse existing stats utilities (`monthStatsData`/streak helpers) where possible; guard all divisions.
2. Respect module toggles (omit habit/tracker fields when off). Localized warm copy variants (great week / steady / quiet) chosen by simple thresholds.

**Acceptance:**

- [ ] Numbers reconcile with a hand-counted week; sparse/empty weeks produce graceful copy, no NaN

### Task 2: Recap Card UI (4h)

**Steps:**

1. `shell/components/recap/RecapCard.tsx`: a cozy card (Caveat headline, a tiny sparkline/ring from existing chart pieces, the closing line). 
2. Placement: on the **week view**, show it for the current week on Sundays (and for any fully-past week when viewed?), dismissible per week (a small device-local "dismissed recap" set or a week-doc flag - prefer device-local to avoid writes); in **Stats**, a permanent "Цей тиждень" panel.
3. Tokens only; reads in all themes; reduced-motion-safe.

**Acceptance:**

- [ ] Recap appears at the right time, dismisses cleanly, and also lives in Stats; looks good light + dark

### Task 3: Focus Timer (5h)

**Steps:**

1. `services/focus/focusTimer.ts` + a small device-local store (`focusStore.ts`, or zustand persist): wall-clock-based countdown (`endsAt` epoch), `start(durationMin, taskId?)`, `pause`, `resume`, `reset`, phase tracking (focus/break for presets). Reload restores from `endsAt`. Computes remaining from `Date.now()` so backgrounding doesn't drift.
2. Chimes: at phase boundaries, call the Phase 9 sound service (a soft start/end tone); respect `soundEnabled`/volume; no chime when disabled.
3. UI `shell/components/focus/FocusTimer.tsx`: a compact, calm timer (presets 25/5 + custom), optional "focusing on <task>" (set from a task's detail or the timer itself), play/pause/reset, a gentle progress ring. Reachable from the header overflow or a small dock; mobile-friendly.

**Acceptance:**

- [ ] Timer counts correctly across backgrounding and a reload; chimes respect sound settings; presets + custom work

### Task 4: Focus Stat, i18n & Sweep (4h)

**Steps:**

1. Optional small stat: count completed focus sessions per day (device-local tally or a tiny `stats`-style increment if you want it synced - device-local is enough); surface as a minor line in Stats or near the timer.
2. en + uk for recap copy variants, timer labels, presets.
3. A11y (timer controls labelled, recap readable), token sweep, real-phone test; reduced-motion check.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; i18n missing-key warnings zero
