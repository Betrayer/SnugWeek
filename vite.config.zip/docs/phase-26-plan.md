# SnugWeek — Phase 26: Typography & Task Emoji

**Goal:** let people pick fonts (with scope), make the done-task strikethrough look hand-drawn, and give tasks and lists their own emoji.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §6. Uses the `--sw-font-*` tokens and the Phase 24 display-style setting.

---

## Definition of Done

- [ ] A curated set of ~5 self-hosted OFL fonts is selectable in Settings → Appearance, with a scope control (all / everything except tasks / only tasks), wired through the font tokens; choice persists (synced) and stays readable and perf-friendly (subset + preload)
- [ ] Done tasks render a hand-drawn pencil strikethrough with a few variants (single / heavier scribble / double), selectable in the display-style setting; reads across all themes; reduced-motion shows the static stroke
- [ ] Users can set and clear an emoji on a task and on a list (including custom lists' headers); it shows before the title; offline-safe; rules updated
- [ ] Strings en + uk; build/lint/tsc clean

**Out of scope:** arbitrary user font uploads; emoji reactions/search beyond the picker.

---

## Task Breakdown

### Task 1: Curated Font Set + Self-Hosting (4h)

**Steps:**

1. Add ~5 OFL fonts, self-hosted under `public/fonts/` with subset `@font-face` like the current ones: a rounded sans (current Nunito), a softer geometric sans, a friendly serif, and two handwriting options for the hand/accent slot. Latin + Cyrillic subsets.
2. Register them in a `data/fonts.ts` registry (id, display name, the CSS stacks for body/hand). Preload only the active body + hand faces (extend the boot/preload approach).

**Acceptance:**

- [ ] All fonts load self-hosted with correct Cyrillic coverage; no layout shift; perf budget respected

### Task 2: Font Setting + Scope (4h)

**Steps:**

1. Profile (synced): `fontBodyId`, `fontHandId`, `fontScope` (`all` | `exceptTasks` | `onlyTasks`); `profileRepo` writers + `profileStore` mirror; defaults match today.
2. Apply via tokens: drive `--sw-font-body` / `--sw-font-hand` from the selected ids; add a `--sw-font-tasks` token and have task text read it so `fontScope` can target tasks independently.
3. Settings → Appearance: two font selects (body, hand) + a scope segmented control, with a live preview.

**Acceptance:**

- [ ] Changing font + scope updates the app live and persists; tasks honor the scope; everything stays readable

### Task 3: Pencil Strikethrough (4h)

**Steps:**

1. Replace the plain CSS `line-through` on done tasks (`TaskCard.tsx`) with a hand-drawn pencil overlay (inline-SVG / `mask` stroke), themed via tokens so it looks drawn over the text.
2. Variants `single` | `scribble` | `double`, folded into the Phase 24 `taskDoneStyle` options (so the display-style control offers the pencil variants where strikethrough applies).
3. Reduced-motion shows the final static stroke (no draw animation).

**Acceptance:**

- [ ] Done tasks read as pencil-crossed; variants switch live; works across themes; reduced-motion-safe

### Task 4: Emoji On Tasks & Lists (5h)

**Steps:**

1. A compact emoji picker: a curated cozy grid plus a native emoji input fallback (no heavy dependency).
2. Data: optional `emoji: string | null` on the task doc and the list doc; writers in `tasksRepo`/`listsRepo`; show the emoji before the title on the card and before custom list headers; clear option. `firestore.rules` allow the field (string ≤ a small length, or null).
3. Surface the picker from the Task Detail and the list header menu.

**Acceptance:**

- [ ] Users can add/clear an emoji on tasks and lists; it shows on the card/list header; offline-safe; rules accept it

### Task 5: i18n & Sweep (1h)

**Steps:**

1. en + uk for font/scope/strikethrough/emoji strings; token + a11y sweep; real-phone check.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; i18n missing-key warnings zero
