# SnugWeek - v0.2 Roadmap (Phases 9–21)

This is the index for the whole v0.2 expansion. Read `docs/design-addendum.md` for the architecture behind it, and each `docs/phase-N-plan.md` for the step-by-step work. v1 (Phases 1–8) is shipped; everything here is additive.

## Why this order

Two foundation phases come first so the rest lands cleanly, then features, then the tour:

1. **Foundation first.** P9 (sensory) fixes the splash/font flash and adds the `sound` + `notify` services that later phases import. P10 (UX & layout) reorganizes ergonomics and builds the **shared primitives** - above all the **Task Detail surface** - that almost every later feature plugs into (subtasks, tags, time/reminders, attachments). Doing P10 before the feature-heavy phases means each feature has a ready home instead of cramming the task card.
2. **Features in dependency order.** Tags/subtasks (P12) extend the task; scheduling (P13) needs `notify`/sound; routines (P14) need scheduling; attachments (P16) need the Detail surface + a storage backend; focus timer (P18) needs sound; recap (P18) needs stats (already shipped).
3. **Tour last.** The guided tour (P21) documents the finished feature set, so it's built once everything exists (with a lightweight contextual-hint primitive that earlier phases can register into).

You run these **serially, one at a time**; each phase is independently shippable.

## Renumbering from the v0.2 draft you already have

| You received (draft) | Now | Note |
|---|---|---|
| Phase 9 - Sensory Layer | **Phase 9** | unchanged |
| Phase 10 - Theme Expansion | **Phase 11** (Themes & Texture) | + paper textures, + system-follow |
| Phase 11 - Scheduling & Reminders | **Phase 13** | unchanged scope; time UI now lives in the P10 Task Detail surface |
| Phase 12 - Attachments | **Phase 16** | unchanged scope; uses the P10 Detail surface + bottom-sheet primitive |
| (new) | **Phase 10** | UX & Layout Refinement |
| backlog A1+A2 | **Phase 12** | Subtasks & Tags |
| backlog A4 | **Phase 14** | Recurring & Routines |
| backlog A3 | **Phase 15** | Search & Quick Actions |
| backlog B1+B2 | **Phase 17** | Personalization & Decoration |
| backlog C1+C2 | **Phase 18** | Reflection & Focus |
| backlog D1+A5 | **Phase 19** | Privacy & Portability |
| backlog D2+D3+E4 | **Phase 20** | Output & Sharing |
| (your tour idea) | **Phase 21** | Onboarding & Guided Tour |

Nothing is built yet, so renumbering costs nothing - it just puts the foundation phases where they belong.

## The phases

| # | Phase | Effort | Key dependencies |
|---|---|---|---|
| 9  | Sensory Layer (splash, sound, notifications) | ~1 wk | - |
| 10 | UX & Layout Refinement | ~1.5 wk | - |
| 11 | Themes & Texture | ~1 wk | P9 (boot-splash theme map) |
| 12 | Tasks Deepened (subtasks, tags) | ~1.5 wk | P10 (Task Detail) |
| 13 | Scheduling & Reminders | ~2 wk | P9 (notify/sound), P10 (Task Detail) |
| 14 | Recurring & Routines | ~1 wk | P13 |
| 15 | Search & Quick Actions | ~1 wk | P10 |
| 16 | Attachments | ~2.5 wk | P10, storage backend (owner decision) |
| 17 | Personalization & Decoration | ~1.5 wk | - |
| 18 | Reflection & Focus | ~1 wk | P9 (sound), stats (shipped) |
| 19 | Privacy & Portability | ~1.5 wk | - |
| 20 | Output & Sharing | ~1.5 wk | rules care |
| 21 | Onboarding & Guided Tour | ~1 wk | most features present |

**Total ≈ 18–19 weeks part-time (~4.5–5 months).** Order is flexible after the two foundation phases - e.g. you can pull Themes (P11) or Personalization (P17) earlier for a quick aesthetic win, or do Privacy (P19) whenever trust matters most. Only hard rule: **P10 before the feature phases**, and **P13 before P14**.

## New dependencies introduced across v0.2

- **None** for most phases (Web Audio, canvas, MediaRecorder, print CSS, WebAuthn are platform APIs).
- **`@mantine/spotlight`** (Mantine-official) for the search/command surface (P15).
- **A storage backend** for attachments (P16) - Firebase Storage (Blaze) or an alternative; owner decision.
- The guided tour (P21) is **custom** (Mantine Popover + overlay) to stay dependency-free and on-brand.

## Owner decisions / inputs

- **Before P16:** choose the storage backend (Firebase Storage + Blaze with a budget alert, or Cloudflare R2 / Cloudinary).
- **For P9:** optionally provide one cozy CC0 page-turn sound (otherwise a synthesized fallback is used).
- **Before P19 passkeys:** confirm whether PIN is enough or you want WebAuthn/passkey biometrics too.

## Deferred to a later major update (parked, not in v0.2)

- **Web Push / closed-app reminders (FCM)** - finishes P13 for the fully-closed app; needs a backend sender.
- **Additional UI languages** beyond uk/en - the en-source pipeline supports it.
- **Telegram Mini App wrapper** - RU/UA reach.

P13's reminder copy and the settings IA are written to leave room for these without depending on them.
