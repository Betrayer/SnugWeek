# SnugWeek — Phase 30: Task Card — Checkboxes & Pencil Strikethrough

**Goal:** bring back checkboxes as the default (with the checkbox-less mode kept as an option), make the done-task strikethrough a plain line by default, and add genuinely pencil-looking strike variants with a soft pencil sound.

**Duration:** ~1 week part-time (~16 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `CLAUDE.md`. Touches `TaskCard.tsx`, `profileRepo.ts`, `global.css`, `services/sound/*`.

---

## Definition of Done

- [ ] Tasks show a round checkbox by default; clicking it toggles done; a setting can hide it and fall back to the current click-the-row-to-toggle mode
- [ ] With the checkbox shown: the checkbox toggles done, clicking the row body opens the detail, and hover/mobile actions are edit + delete; with it hidden: clicking the row toggles, and actions are edit + open + delete
- [ ] The done strikethrough defaults to a clean straight line (as before); the current smooth wavy "single" look is gone
- [ ] Pencil strike variants are available and look like real graphite (grainy, slightly irregular, semi-opaque) — at minimum: line, pencil (single), cross (crisscross), double — selectable in the display-style setting
- [ ] Completing a task plays one of 2–3 short pencil sounds at random (when sound is on); with no sound assets present it falls back to a synthesized scratch and never errors
- [ ] Everything reads well in all 10 themes; build/lint/tsc clean; strings en + uk

**Out of scope:** changing the toggle/sound behavior on undo (no strike sound on un-complete), per-task style overrides.

---

## Task Breakdown

### Task 1: Checkbox Option (4h)

**Steps:**

1. Profile: add `showTaskCheckbox: boolean` (default `true`) to `profileRepo` (`DEFAULT_SHOW_TASK_CHECKBOX`, normalize, the profile type) + a `setShowTaskCheckbox` writer + `profileStore` mirror.
2. `TaskCard.tsx`: when `showTaskCheckbox`, render a round checkbox on the left (the cozy custom check used historically — fill + check on done, token-colored), wired to `onToggle`. In this mode, the row body click calls `onOpen` (detail) and the trailing actions are edit + delete.
3. When `showTaskCheckbox` is false, keep the current behavior (row click toggles; trailing actions edit + open + delete).
4. Settings → Appearance: a switch for the checkbox.

**Acceptance:**

- [ ] Checkbox on by default; toggles done; row opens detail; hiding it restores click-to-toggle with the open action present

### Task 2: Strike Styles — Plain Default + Pencil Variants (6h)

**Steps:**

1. Extend `TaskStrikeStyle` to `"line" | "pencil" | "cross" | "double"` (replace `single`/`scribble`); set `DEFAULT_TASK_STRIKE_STYLE = "line"`. Migrate old values (`single`→`line`, `scribble`→`pencil`, `double`→`double`) in `normalizeTaskStrikeStyle`.
2. `global.css`: `line` = a clean straight strike (a 2px token-ink rule centered on the text, no wave). Remove the smooth-bezier masks.
3. Pencil variants use a real graphite look, not a clean vector: one reusable inline SVG `<filter>` (`feTurbulence` fractalNoise + `feDisplacementMap` to roughen + a slight `feComponentTransfer` grain) applied to a slightly hand-jittered stroke, rendered as the `::after` mask/overlay, tinted with `--sw-ink` at ~0.7 opacity for graphite. `pencil` = one rough stroke; `cross` = two diagonal strokes crossing the text (X / crisscross); `double` = two roughly-parallel pencil strokes. Keep them readable and centered across wrapping lines.
4. Wire the variant selection (already `taskStrikeStyle` on the profile) into the display-style control; show the variants only where strikethrough applies (`strike` / `dimStrike`).

**Acceptance:**

- [ ] Default is a clean straight line; pencil/cross/double genuinely read as graphite (grainy, slightly irregular) in every theme; switching is live

### Task 3: Pencil Sound (4h)

**Steps:**

1. Add `playStrike()` to `services/sound` mirroring `playFlip` (sampled with fallback): load `/sounds/pencil-1.{webm,mp3}`, `pencil-2`, `pencil-3` into buffers on unlock; `playStrike` picks one at random; if no assets/decode fails, fall back to a short synthesized noise-burst scratch. Respect the sound enable/volume and `document.hidden`; throttle.
2. Call `playStrike()` on the task open→done edge (the same place `playCheck` fires today — replace or layer per taste; default: pencil sound on completion). No sound on undo.
3. `public/sounds/`: document the three expected pencil files; the build must not fail when absent.

**Acceptance:**

- [ ] Completing a task plays a random pencil sound when sound is on; with no assets a synthesized scratch plays; undo is silent; no console errors

### Task 4: i18n & Sweep (2h)

**Steps:**

1. en + uk for the checkbox setting and any new strike-variant labels; token/a11y sweep (checkbox has an accessible label, strike overlay `aria-hidden`); real-phone check.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; i18n missing-key warnings zero
