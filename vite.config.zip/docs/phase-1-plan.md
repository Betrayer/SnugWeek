# SnugWeek - Phase 1: Foundation & Walking Skeleton

**Goal:** a deployed, responsive, offline-capable app skeleton: anonymous auth, themed shell with routing and i18n, the week grid rendered for any week, and one full vertical slice through every layer - the week note (UI → store → repo → Firestore → offline → sync).

**Duration:** ~1.5–2 weeks part-time (~25 h)
**Phase end criterion:** the Definition of Done below passes 100%.

---

## Definition of Done

Manual smoke test at end of phase. All must pass:

- [ ] `npm run build`, `npm run lint`, `npx tsc -b` - all clean
- [ ] Opening the deployed URL silently signs in anonymously and redirects `/` → `/w/<current week>`
- [ ] Desktop (≥992px): header, week grid (Mon–Fri wide + Sat/Sun stacked), sidebar panel placeholder behind a divider, week note block
- [ ] Mobile (<992px): compact header, swipeable day pager opening on today, bottom tab bar (Тиждень / Місяць / Статистика / Налаштування), note section below the pager
- [ ] Day headers show correct dates for the week from the URL; weekend days render dimmed
- [ ] UI is in Ukrainian by default; switching to English in the header menu translates everything including date labels; choice survives reload
- [ ] The cozy look is visible: cream paper background, Nunito body, Caveat in the note, rounded cards - zero default-Mantine blue
- [ ] Typing in the week note persists across reloads
- [ ] Offline test: DevTools → Network → Offline → edit the note → reload (still offline) → note is there → go online → the write reaches Firestore (visible in console)
- [ ] Two browser tabs: a note edit in one appears in the other within a second
- [ ] Offline pill appears in the header when the network is down
- [ ] App deployed on Vercel, direct URL `/w/2026-W30` works (SPA rewrite)
- [ ] No console errors during all of the above

**Out of scope for Phase 1:** tasks, lists, DnD, trackers, habits, carry-over, month view, stats, transitions, extra themes, auth UI beyond silent anonymous, PWA.

---

## Prerequisites

1. **Node 22 LTS** (`node -v` → 22.x), npm 10+
2. Empty private GitHub repo `SnugWeek` cloned locally; these docs (`CLAUDE.md`, `docs/`) copied into the root. **Do not commit before Task 1 step 2 creates `.gitignore`** - it hides `CLAUDE.md` and `docs/` from git.
3. **Firebase project created** in the console: name `snugweek`, Firestore enabled (production mode, region `europe-west`), Authentication → Anonymous provider enabled, a Web App registered → config values at hand
4. **Vercel account** connected to the GitHub repo (import later in Task 7)
5. Claude Code running in the project directory

---

## Task Breakdown

Seven tasks. Stop and verify acceptance after each before moving on.

### Task 1: Project Bootstrap (3h)

**Goal:** Vite + React + TS scaffold with the exact dependency set, strict tooling, and the folder skeleton.

**Steps:**

1. `npm create vite@latest . -- --template react-ts`, then `npm install`.
2. Create `.gitignore` (before anything else is committed):

   ```
   logs
   *.log
   node_modules
   dist
   dist-ssr
   *.local
   .vscode/*
   !.vscode/extensions.json
   .idea
   .DS_Store
   .claude/
   CLAUDE.md
   docs/
   ```

3. Runtime deps:

   ```
   npm i @mantine/core@^9 @mantine/hooks@^9 @mantine/dates@^9 @mantine/notifications@^9 zustand@^5 firebase@^12 react-router@^7 i18next react-i18next dayjs @fontsource/nunito @fontsource/caveat
   ```

4. Dev deps (template already has react/vite ones):

   ```
   npm i -D prettier eslint-plugin-react-hooks eslint-plugin-react-refresh typescript-eslint @eslint/js globals
   ```

5. `tsconfig.app.json` compiler options - copy the Klikta set: `strict`, `noUncheckedIndexedAccess`, `noUnusedLocals`, `noUnusedParameters`, `erasableSyntaxOnly`, `noFallthroughCasesInSwitch`, `verbatimModuleSyntax`, `moduleResolution: "bundler"`, `target/lib ES2023`.
6. `eslint.config.js` - flat config: `@eslint/js` recommended + `typescript-eslint` recommended + `react-hooks` flat recommended + `react-refresh` vite preset, `globalIgnores(["dist"])`.
7. `.prettierrc` → `{}` (defaults). Add scripts: `"lint": "eslint ."`, `"format": "prettier --write src"`.
8. Delete template noise (`App.css`, logo assets, demo markup). Create the folder skeleton from DESIGN.md "Project structure" (empty dirs are fine).
9. `.env.local.example`:

   ```
   VITE_FIREBASE_API_KEY=your-api-key
   VITE_FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
   VITE_FIREBASE_PROJECT_ID=your-project-id
   VITE_FIREBASE_STORAGE_BUCKET=your-project-id.firebasestorage.app
   VITE_FIREBASE_MESSAGING_SENDER_ID=000000000000
   VITE_FIREBASE_APP_ID=1:000000000000:web:0000000000000000000000
   ```

10. First commit by the owner.

**Acceptance:**

- [ ] `npm run dev` serves the (gutted) app at localhost:5173
- [ ] `npx tsc -b` and `npm run lint` pass
- [ ] `git status` shows `CLAUDE.md` and `docs/` as ignored
- [ ] Folder skeleton matches DESIGN.md

### Task 2: Time Service & i18n Runtime (3h)

**Goal:** the dayjs singleton with all week math, and a working uk/en i18n runtime with lazy locale chunks.

**Steps:**

1. `src/services/time.ts`: configure dayjs with `isoWeek`, `localeData`, `customParseFormat`; import `dayjs/locale/uk` and `dayjs/locale/en`. Export helpers: `currentWeekId()`, `weekIdFromDate(date)`, `isValidWeekId(s)`, `addWeeks(weekId, n)`, `mondayOf(weekId)`, `daysOfWeek(weekId)` (array of 7 dayjs objects), `monthIdOf(date)`, `weekTitle(weekId)` (→ "Червень 2026 · W24" in the active locale), `dayLabel(d)` ("Пн 8.06"), `setTimeLocale(lang)`.
2. `src/i18n/languages.ts`: `SUPPORTED_LANGS = ["uk", "en"]`, `DEFAULT_LANGUAGE = "uk"`, `isSupportedLang` guard.
3. `src/i18n/index.ts`: i18next singleton, lazy per-language bundles via `import.meta.glob("../locales/*/**.json")` (Klikta pattern - one chunk per language), namespaces `common | week | tasks | trackers | stats | settings | auth`. Initial namespaces: `common`, `week`, `settings`.
4. Author `src/locales/en/{common,week,settings}.json` and hand-written `src/locales/uk/...` mirrors. Seed keys used this phase: app name, nav labels, offline pill, note placeholder, language names, settings headings.
5. `src/state/settingsStore.ts` (device-local, `devtools(persist(...))`, `version: 1`, `partialize`): `{ language, reduceMotion, transition: "fold" }` + setters; `setLanguage` flips i18next and `setTimeLocale`.
6. Wire i18n init into `Root.tsx` (suspense-free: await init before render or use a tiny gate).

**Acceptance:**

- [ ] `weekIdFromDate(new Date("2026-01-01"))` → `2026-W01`-style correctness verified for year-boundary dates (manually log 2025-12-29 → `2026-W01`, 2027-01-01 → `2026-W53`)
- [ ] Locale switch changes both UI strings and dayjs output
- [ ] Language persists in localStorage under a versioned key

### Task 3: Theme Foundation (3h)

**Goal:** the token system with the `milk` palette, fonts, and a Mantine theme - the app stops looking like default Mantine.

**Steps:**

1. `src/data/themes/types.ts` - `ThemeSpec` exactly as in DESIGN.md. `src/data/themes/milk.ts` - the default palette (warm cream paper `#faf6ef`-family, soft brown ink, dusty-rose accent, gentle line color, `--sw-done` sage). `registry.ts` - `THEMES: Record<string, ThemeSpec>` with `milk` only + `DEFAULT_THEME_ID`.
2. `src/styles/tokens.css` - `[data-snug-theme="milk"] { --sw-paper: ...; }` block generated from the spec vars (keep the file hand-readable; one block per theme).
3. `src/styles/global.css` - body background `var(--sw-paper)` (+ optional subtle texture via `--sw-paper-texture`), selection color from accent, scrollbar styling, `@fontsource` imports for nunito (400/600/700) and caveat (400/600).
4. `src/shell/theme.ts` - `buildMantineTheme(spec)`: fontFamily Nunito, headings Nunito 700, `defaultRadius: "lg"`, primary color generated from the accent (10-shade tuple), component defaults (Paper/Card with token-driven bg via CSS vars).
5. `Root.tsx`: read `themeId` (hardcode `milk` until profileStore exists in Task 6 - leave a `DEFAULT_THEME_ID` constant), set `data-snug-theme` on `<html>`, render `MantineProvider` with the built theme + `Notifications` mount.

**Acceptance:**

- [ ] App shows cream paper background, Nunito text, rounded surfaces; nothing default-blue
- [ ] Grepping `src/shell` and `src/components` for `#` hex colors returns nothing (tokens only)
- [ ] Toggling the `data-snug-theme` attr in DevTools to a bogus value falls back gracefully (vars cascade from `:root` defaults - define `:root` fallbacks equal to milk)

### Task 4: Routing & Responsive App Shell (4h)

**Goal:** all routes, the desktop shell and the mobile shell, navigation between pages.

**Steps:**

1. `Root.tsx` → `createBrowserRouter`: `/` (redirect to `/w/${currentWeekId()}`), `/w/:weekId` (validate via `isValidWeekId`, else redirect current), `/month/:monthId`, `/stats`, `/settings`, `*` → redirect `/`.
2. `src/shell/hooks/useIsMobile.ts` - `useMediaQuery("(max-width: 62em)")` wrapper (single source of the breakpoint).
3. `src/shell/layout/AppShell.tsx` - Mantine AppShell: header always; on desktop an `aside` slot for the future lists panel (render `SidebarPanel` placeholder: section headings "Задачі" / "Ідеї та мрії" behind a perforated left edge - dashed border + radial-gradient "holes", pure CSS, tokens only); on mobile no aside, `MobileTabBar` fixed bottom (4 tabs with inline-SVG icons: week/month/stats/settings).
4. `src/shell/layout/HeaderBar.tsx` - left: app wordmark (Caveat); center: week title + nav arrow placeholders (wired in Phase 3); right: language menu (uk/en), `SyncBadge`.
5. `src/shell/layout/SyncBadge.tsx` - `navigator.onLine` listener (`useSyncExternalStore`), offline → soft pill "Офлайн - зміни зберігаються локально".
6. Placeholder pages for month/stats/settings (Caveat "скоро тут буде затишно" empty states); Settings already renders the working language picker from settingsStore.

**Acceptance:**

- [ ] All routes render inside the shell; invalid `/w/abc` redirects to the current week
- [ ] Resizing across 992px swaps desktop aside ↔ bottom tabs live
- [ ] DevTools offline toggle shows/hides the pill
- [ ] Tab bar navigation works on a phone-sized viewport with comfortable hit targets (≥44px)

### Task 5: Firebase & Anonymous Auth (3h)

**Goal:** initialized Firebase with offline persistence and a silent anonymous session.

**Steps:**

1. `src/services/firebase.ts`: `initializeApp` from `VITE_FIREBASE_*`; `initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) })`; `getAuth`. Export `db`, `auth`. This must be the only file importing `firebase/app`.
2. `src/state/authStore.ts`: `{ status: "init" | "ready", uid: string | null, isAnonymous: boolean }` + `bootstrap()` - `onAuthStateChanged`; if no user → `signInAnonymously`. Call once from `Root.tsx`. Gate the routed app on `status === "ready"` with a soft splash (wordmark on paper, no spinner storm).
3. `firestore.rules` in repo root - owner-only as in DESIGN.md sketch. Deploy via console paste (note for owner; CLI optional).
4. Owner fills `.env.local` from the Firebase console.

**Acceptance:**

- [ ] First load creates an anonymous user (visible in Firebase console → Authentication)
- [ ] Reload keeps the same uid (persistence works)
- [ ] App boots with DevTools offline after a prior visit (auth + cache from IndexedDB)
- [ ] No firebase imports outside `src/services/`

### Task 6: Week Skeleton + Vertical Slice: Week Note (5h)

**Goal:** the week board renders any week's structure from the URL, and the week note round-trips through Firestore.

**Steps:**

1. Types in `src/services/repos/weeksRepo.ts`: `WeekDoc` per DESIGN.md; `subscribeWeek(uid, weekId, cb)` (missing doc → `cb(null)`), `setWeekNote(uid, weekId, note)` - `setDoc(..., { merge: true })` with `updatedAt`.
2. `src/services/repos/profileRepo.ts`: `ensureProfile(uid)` - idempotent `setDoc` merge of the default profile (DESIGN.md shape); `subscribeProfile(uid, cb)`.
3. `src/state/profileStore.ts`: mirrors the profile doc; starts subscription when authStore turns ready; exposes `themeId`, `weekend`, `columnMode`, `moduleToggles`. `Root.tsx` now drives the theme attr from here.
4. `src/state/weekStore.ts`: `{ weekId, week: WeekDoc | null, status }`, `open(uid, weekId)` manages the subscription (unsubscribe previous), `setNote(text)` → local debounce 400ms → repo.
5. `src/shell/pages/WeekPage.tsx`: reads `:weekId`, calls `weekStore.open`, renders desktop vs mobile arrangement.
6. Desktop `WeekBoard.tsx`: CSS grid per `columnMode` - `"cozy"`: 5 wide columns + 1 narrow `WeekendStack` (Sat over Sun, horizontal divider); `"equal"`: 7 columns. Each cell = `DayColumn` with `DayHeader` (dayLabel, dimmed when ISO day ∈ effective daysOff = `week.daysOff ?? profile.weekend`) and an empty task area placeholder ("+ Додати" non-functional button, wired in Phase 2).
7. Mobile `MobileDayPager.tsx`: horizontal swipe between 7 `DayColumn`s (scroll-snap implementation is fine; no library), dot indicator with day initials, initial index = today when the URL week is the current one else Monday.
8. `WeekNote.tsx`: Caveat-styled `Textarea` (autosize, transparent paper look) bound to `weekStore`; placed bottom-left under the grid (desktop) / as a section below the pager (mobile). Subtle "збережено" tick fading in after the debounced write settles.

**Acceptance:**

- [ ] `/w/2026-W24` and `/w/2026-W30` show correct dates; weekend dimming follows the profile default
- [ ] Note edits survive reload; second tab sees them live
- [ ] Offline note editing works and syncs after reconnect (verify the doc in the console)
- [ ] Mobile pager swipes through all 7 days and opens on today for the current week
- [ ] Firestore shows exactly `users/{uid}` and `users/{uid}/weeks/{weekId}` - no stray writes

### Task 7: Vercel Deploy (2h)

**Goal:** the skeleton lives on a public URL.

**Steps:**

1. `vercel.json`: `{ "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }] }`.
2. Import the GitHub repo in Vercel; framework preset Vite; add the six `VITE_FIREBASE_*` env vars.
3. Add the Vercel domain to Firebase Auth → Authorized domains.
4. Production smoke: the full DoD list above on the deployed URL, desktop + a real phone.

**Acceptance:**

- [ ] Deployed URL passes the Phase 1 Definition of Done end-to-end
