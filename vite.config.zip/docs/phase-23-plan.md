# SnugWeek — Phase 23: Shell Rework — Top Bar, Navigation & Settings IA

**Goal:** rebuild the two weakest surfaces — the cluttered, partly-duplicated header (especially on mobile) and the left-glued, meaning-mixed settings — so navigation is obvious, nothing is duplicated, the mobile top bar is usable, and settings are grouped and use the full width.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §8. Reuses `BottomSheet`, `ActionMenu`, `SettingsLayout`.

---

## Definition of Done

- [ ] Desktop header reads calmly: left wordmark/name, center week title with prominent prev/next + "Сьогодні", right a small cluster — search, one **tools** overflow menu (decorate / focus timer / week options / language), account, sync dot; no two controls look like the same kind of menu
- [ ] Mobile header is stripped to essentials (name, week title + arrows, one tools overflow); navigation lives in the bottom tab bar; nothing is duplicated between header and bottom bar; every header control is tappable one-handed
- [ ] Settings are split into two top-level tabs — **«Налаштування»** (Appearance/theme/font, Sound, Reminders, Lock, Data, Account, About) and **«Блокнот»** (Weekend & columns, Modules, Trackers, Habits, Tags, Routines) — with related items grouped together
- [ ] Settings content fills the available width (section nav left, content centered to a readable max — no large empty right area); mobile keeps the accordion
- [ ] Focus order, ARIA on menus, escape-to-close all correct; every moved control still works; build/lint/tsc clean

**Out of scope:** new settings (those land in their feature phases); the task/day surface (Phase 24).

---

## Task Breakdown

### Task 1: Desktop Header Redesign (4h)

**Steps:**

1. Rework `HeaderBar.tsx` into three deliberate zones. Left: wordmark/notebook name (+ optional compact nav). Center: `WeekNav` (title + prev/next + "Сьогодні") as the visual primary. Right: `HeaderSearchSlot`, then a single **tools** `ActionMenu` overflow that folds `DecorateButton`, `FocusTimerButton`, `WeekToolbarMenu`, and `LanguageMenu`; then `AccountMenu`; then `SyncBadge`.
2. Remove the now-redundant separate icons from the right cluster (they move into the tools menu). Keep the lists button off the desktop header (the sidebar panel is already visible on desktop).

**Acceptance:**

- [ ] Header is uncluttered; week nav is the obvious primary; the tools menu groups the secondary actions; nothing duplicated

### Task 2: Mobile Header + Navigation (4h)

**Steps:**

1. Mobile header: name + week title + prev/next + one tools overflow only. Move list/sidebar access off the cramped header to the board area (a small lists button near the week) and keep nav in `MobileTabBar`.
2. Keep the bottom bar at 4 tabs (Week / Month / Stats / Settings); quick-add stays the existing `MobileQuickAdd` docked control.
3. Verify thumb reach, safe-area insets, and no overflow at 360px width.

**Acceptance:**

- [ ] Mobile header controls are reachable one-handed; no header/bottom-bar duplication; nothing overflows on a narrow phone

### Task 3: Settings Split Into Two Tabs (4h)

**Steps:**

1. In `SettingsPage.tsx`, group the sections into two top-level tabs: **Налаштування** = Appearance, Sound, Reminders, Lock, Data, Account, About; **Блокнот** = Schedule (weekend/columns), Modules, Trackers, Habits, Tags, Routines.
2. Implement the two-tab split in/around `SettingsLayout.tsx` (a top-level `Tabs`, each tab rendering its own sectioned layout). Move tracker/habit management fully under «Блокнот».
3. Add localized tab labels (en + uk).

**Acceptance:**

- [ ] Settings open into two clear tabs; "how the app behaves" is separated from "how the notebook/week is arranged"; every control still works

### Task 4: Settings Layout — Use the Width (3h)

**Steps:**

1. Replace the `maw={760}` left-glued column with a balanced layout: vertical section nav on the left, content filling the remaining width to a comfortable readable max (centered, not hugging the left edge).
2. Keep the mobile accordion behavior unchanged.

**Acceptance:**

- [ ] No large empty right area on desktop; settings feel centered and width-aware; mobile accordion unchanged

### Task 5: A11y & Regression (3h)

**Steps:**

1. Tab order through the new header and the tools menu; ARIA roles/labels on the overflow; escape-to-close.
2. Regression of every moved control (decorate, focus, week options, language, search, account, sync) on desktop + mobile.

**Acceptance:**

- [ ] Keyboard-navigable header and settings; no functional regressions
