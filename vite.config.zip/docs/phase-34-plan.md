# SnugWeek — Phase 34: Font Picker Expansion & Unification

**Goal:** add more cute fonts, make both font dropdowns offer the *same* unified list (so any font — including the handwriting font used in notes — can be chosen for either slot), and keep the Ukrainian UI safe by requiring Cyrillic coverage.

**Duration:** ~0.5–1 week part-time (~10 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `CLAUDE.md`. Touches `data/fonts/registry.ts`, `data/fonts/types.ts`, `AppearanceSection.tsx`, `global.css`, `profileRepo.ts`.

---

## Definition of Done

- [ ] Both font dropdowns (body and hand) offer the **same** unified list of all fonts; any font can be selected for either slot
- [ ] The handwriting font used in notes (Caveat) is selectable in both dropdowns, so it can be applied to body/tasks too
- [ ] Several new cute fonts are added and self-hosted, each with **Latin + Cyrillic** coverage (no broken Ukrainian text); each renders correctly in the dropdown preview and when applied
- [ ] Defaults are unchanged (body = Nunito, hand = Caveat); the scope control (all / except tasks / only tasks) still works; preloading still covers the active faces
- [ ] Reads well in all themes; build/lint/tsc clean; strings en + uk

**Out of scope:** per-weight selection, arbitrary user font uploads, fonts without Cyrillic.

---

## Task Breakdown

### Task 1: Add New Cute Fonts (4h)

**Steps:**

1. Add several cute, self-hosted fonts under `public/fonts/` (Latin + Cyrillic woff2, same subset pattern as the existing ones). Vetted candidates with confirmed Cyrillic: **Pangolin** (cute felt-tip handwriting), **Rubik** (friendly rounded sans), **Amatic SC** (tall hand-drawn). Optionally add 1–2 more cozy faces, but only if they ship Cyrillic — **verify Cyrillic before adding** (e.g. Pacifico/Fredoka must be checked and dropped if Latin-only). Use a self-hosting helper to fetch the woff2 + ranges.
2. Add a `FontSpec` for each (id, name, stack with a sensible fallback, `preload` paths). Drop or keep the `slot` field per Task 2.

**Acceptance:**

- [ ] Each new font loads self-hosted with Cyrillic; Ukrainian text renders correctly in every new font; no missing-glyph boxes

### Task 2: Unify the Registry (3h)

**Steps:**

1. Merge `BODY_FONTS` and `HAND_FONTS` into a single exported `FONTS` array containing every font; replace `bodyFontById`/`handFontById` with one `fontById(id)` over `FONTS` (keep sensible fallbacks: missing body → Nunito, missing hand → Caveat). The `slot` field becomes informational or is removed (both selects use the full list).
2. Keep `resolveFontVars` working with the unified lookup: `--sw-font-body`/`--sw-font-tasks` from the body selection (honoring scope), `--sw-font-hand` from the hand selection; `preload` = the two active faces. Defaults unchanged.
3. Update `profileRepo` normalize/imports to the unified lookup (the stored `fontBodyId`/`fontHandId` stay the same fields).

**Acceptance:**

- [ ] One `FONTS` list backs everything; resolve + scope + preload behave exactly as before for the defaults; any id resolves safely

### Task 3: Settings UI — Identical Dropdowns (2h)

**Steps:**

1. In `AppearanceSection`, point **both** the body select and the hand select at the unified `FONTS` list (identical options), each rendering the option label in its own font as a preview. Keep the live preview of the result.
2. Confirm picking a handwriting font (e.g. Caveat/Pangolin) for the body and a sans (e.g. Nunito) for the hand both work and apply through the tokens.

**Acceptance:**

- [ ] Both dropdowns show the same options with in-font previews; cross-slot picks apply correctly and persist

### Task 4: i18n & Sweep (1h)

**Steps:**

1. en + uk for any new labels; verify preload of the active faces (incl. new fonts) and perf budget; token/contrast check of the previews across themes; real-phone check.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; no missing glyphs; i18n missing-key warnings zero
