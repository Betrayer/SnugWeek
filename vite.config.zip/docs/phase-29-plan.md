# SnugWeek — Phase 29: Time Picker, Sharing & Layering

**Goal:** replace the painful time input with a real picker, make shared weeks look like the actual week (with an option to include unscheduled tasks), and stop the sidebar overlay from stealing clicks from modals.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `TaskTimeReminder.tsx`, `share/buildSnapshot.ts`, `weekview/WeekView.tsx`, `SidebarDrawer.tsx`, `ResponsiveDialog.tsx`.

---

## Definition of Done

- [ ] Setting a time is fast and pleasant on desktop + mobile — a dropdown picker with hour/minute selection plus quick presets — reused by task time, routines, and the focus timer
- [ ] A shared link renders the week in the actual board layout at readable size (the cozy 5+2 / equal columns), not shrunken auto-fill cards
- [ ] A share option includes unscheduled tasks (the sidebar lists), rendered as a side panel next to the week like the app; revoke still works
- [ ] With the sidebar open, opening any dialog/sheet is fully interactive — no backdrop steals clicks
- [ ] Strings en + uk; build/lint/tsc clean; DoD verified on phone + desktop, light + dark

**Out of scope:** natural-language time entry, editable/collaborative shares, sharing month/stats.

---

## Task Breakdown

### Task 1: Real Time Picker (5h)

**Steps:**

1. Replace the bare `TimeInput` with a cozy dropdown time picker: hour/minute columns plus quick presets (e.g. 09:00, 12:00, 18:00) and fine selection; themed with tokens.
2. Extract it as one reusable component and use it everywhere a time is picked: `TaskTimeReminder`, routines (`RoutinesSection`), and the focus timer.
3. Keep value semantics ("HH:mm" / null) and the clear action.

**Acceptance:**

- [ ] Picking a time is quick and pleasant on desktop + mobile; reused in all three places; clearing works

### Task 2: Share — Real Layout (4h)

**Steps:**

1. Render the shared week (`WeekView.tsx`) with the actual board layout (cozy 5+2 / equal columns) at full readable size instead of `minmax(170px, …)` auto-fill, mirroring the app (read-only).
2. Keep print (`variant="print"`) working with its own column rules.

**Acceptance:**

- [ ] A shared link looks like the real week at readable size on desktop + phone; print unaffected

### Task 3: Share — Include Unscheduled Tasks (4h)

**Steps:**

1. Extend `ShareInclude` with `lists` (unscheduled tasks); capture the sidebar list tasks in `buildSnapshot.ts` and the snapshot type (`shareTypes.ts`).
2. Render them as a side panel next to the week in `WeekView` (mirroring the app's sidebar), shown only when included.
3. Add the toggle to `ShareDialog.tsx` (privacy-conservative default).

**Acceptance:**

- [ ] The share dialog can include/exclude unscheduled tasks; when on, they appear as a side panel; revoke still works

### Task 4: Overlay Layering Fix (3h)

**Steps:**

1. Coordinate overlays so a modal/sheet always sits above the sidebar `Drawer`: a consistent `zIndex` scheme, or auto-close the drawer when a dialog opens, or route the sidebar through the same layering as `ResponsiveDialog`.
2. Verify across task detail, move-task, pickers, and the lists drawer.

**Acceptance:**

- [ ] With the sidebar open, any dialog/sheet is fully interactive; no backdrop blocks input

### Task 5: Final Sweep (2h)

**Steps:**

1. Any small fixes surfaced across Phases 22–28; token/a11y/i18n sweep; full DoD pass on phone + desktop, light + dark.

**Acceptance:**

- [ ] Build/lint/tsc clean; no regressions
