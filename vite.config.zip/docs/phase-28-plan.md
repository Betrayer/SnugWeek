# SnugWeek — Phase 28: Trackers & Statistics

**Goal:** make multi-line tracker charts legible, count only tasks that still exist, represent routines in stats, and add a tasteful set of new views.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `trackersRepo.ts`, `statsRepo.ts`, the `stats/*` services and components.

---

## Definition of Done

- [ ] Each tracker has a distinct color; `TrackerTrendChart` draws mood, energy, and any custom trackers as their own colored lines with a legend; colors read in all themes
- [ ] Deleting a completed task decrements the completion stat for its `completedAt` date, so stats reflect only existing tasks; undo paths don't double-count; a one-tap recount reconciles historical drift
- [ ] Stats include a routines view (per active routine: generated vs completed adherence over the period), respecting usage
- [ ] New stat views ship: completion by weekday, time-of-day distribution for timed tasks, tags breakdown (completed by tag), tracker averages trend, habit consistency %, current-vs-best streak summary, and month-over-month comparison — month + year, lazy-loaded, themed, with graceful empty states
- [ ] Strings en + uk; build/lint/tsc clean

**Out of scope:** custom date ranges, exporting stats, per-list breakdowns.

---

## Task Breakdown

### Task 1: Distinct Tracker Colors (4h)

**Steps:**

1. Add an optional `color` to trackers (a curated, token-aligned swatch set like `tagColors.ts`), with sensible defaults for `mood`/`energy`; `trackersRepo` writer + normalize + `trackersStore` mirror; a swatch control in tracker settings.
2. Use the color in `TrackerTrendChart` (one color per line) and add a legend; optionally tint the day tracker control.

**Acceptance:**

- [ ] Mood vs energy vs custom trackers are clearly distinguishable in the multi-line chart; colors read in all themes

### Task 2: Count Only Existing Tasks (4h)

**Steps:**

1. On delete of a **done** task (the `weekStore`/`listsStore` remove paths or `deleteTask`), decrement the completion stat for the date derived from its stored `completedAt` (mirror of `bumpCompletion(-1)`), so removed tasks stop counting.
2. Re-verify toggle/undo so a normal un-complete still decrements once and a delete-after-complete decrements once (no double).
3. Expose a one-tap **recount** using the existing `backfillStats` for already-drifted data (Settings → Data or About).

**Acceptance:**

- [ ] Deleting a completed task lowers the count; recount reconciles historical drift; no double counting on undo

### Task 3: Routines In Stats (4h)

**Steps:**

1. Compute per-routine adherence for the period from `routines` + generated tasks (`routineId`) + their completion: generated count vs completed count, as a rate.
2. Add a routines panel to the stats views (month + year) alongside habits; respect routines that are inactive/unused.

**Acceptance:**

- [ ] Routine adherence shows for the selected month/year and reconciles with the underlying tasks

### Task 4: Expanded Stat Views (7h)

**Steps:**

1. Add the new views, reusing existing chart pieces and assemblers (`monthStatsData`/`yearStatsData`): completion by weekday (most/least productive day), time-of-day distribution for timed tasks, tags breakdown (completed by tag), tracker averages trend, habit consistency %, a current-vs-best streak summary, and a month-over-month comparison.
2. Keep them lazy on the stats route, themed, with graceful empty/sparse states.

**Acceptance:**

- [ ] All new views render for month + year, lazy-loaded, themed, and degrade gracefully when data is sparse

### Task 5: i18n & Sweep (3h)

**Steps:**

1. en + uk for all new labels; token/a11y sweep (chart aria, legends); real-phone check; verify lazy chunking still holds.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; i18n missing-key warnings zero
