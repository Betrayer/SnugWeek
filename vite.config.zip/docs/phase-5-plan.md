# SnugWeek - Phase 5: Theming & Cozy Polish

**Goal:** the app earns its aesthetic: five switchable palettes (including dark), a delightful theme picker, handwriting details, micro-interactions, lovable empty states, and a first-run seed week - all on the token system laid in Phase 1, so this phase adds data and delight, not repaints.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.

---

## Definition of Done

- [ ] Settings → Тема shows 5 cards (Молоко / Лаванда / Шавлія / Персик / Північ) with live mini-previews; clicking applies instantly, syncs per account (second device follows)
- [ ] Every screen - week, month, settings, drawers, modals, notifications, drag overlay - fully restyles with the theme; grep audit confirms zero hardcoded colors
- [ ] Північ (dark) passes a contrast check (≥ 4.5:1 body text) and Mantine renders in dark scheme (inputs, popovers)
- [ ] Completing a task plays a small spring (checkbox pop + soft strikethrough draw); adding a task pops in; the drag overlay tilts and lifts; all springs respect reduced-motion
- [ ] Sidebar perforated edge, ruled note lines, round checkboxes, Caveat headers - the notebook character is consistent across themes
- [ ] Empty states (empty day, empty list, empty month) show short Caveat phrases with a tiny inline-SVG doodle
- [ ] Fresh account receives a seed week: 3–4 sample tasks in "Задачі" (localized), mood set for today, one sample habit - only when the account has zero data
- [ ] Focus-visible rings themed and visible in all palettes; axe DevTools shows no serious issues on week + settings
- [ ] Build, lint, tsc clean

**Out of scope:** seasonal/extra themes, user-built themes, sound effects, the `curl` transition.

---

## Task Breakdown

### Task 1: Palette Data (4h)

**Steps:**

1. Author `lavender.ts`, `sage.ts`, `peach.ts` (light) and `midnight.ts` (dark) ThemeSpecs: full `--sw-*` var sets + Mantine overrides (`colors` 10-shade tuples for primary, `primaryShade`, dark-specific surface mapping for midnight). Keep paper tones soft and warm; accents pastel; `midnight` = deep ink paper, candle-warm accent.
2. Mirror each as a block in `tokens.css`; `:root` fallback stays = milk.
3. `registry.ts` exports all five; `preview` swatches filled.
4. Root applies `forceColorScheme` from `spec.kind` and rebuilds the Mantine theme on change (memoized by themeId).

**Acceptance:**

- [ ] Switching via DevTools attr previews all five correctly before any picker exists
- [ ] Midnight: Mantine inputs/popovers/modals readable; no light flashes on load (attr set before first paint - inline script in `index.html` reading localStorage profile cache is overkill; acceptable: brief default; verify no jarring flash)

### Task 2: Theme Picker (3h)

**Steps:**

1. `ThemePicker.tsx` in Settings: card per theme - name (i18n), mini week-spread thumbnail rendered from `preview` tokens (pure CSS, ~3 columns + dots), active ring.
2. Click → `profileStore.setTheme(id)` → profile doc write; theme applies optimistically via the snapshot path.
3. Sync check: second tab/device follows within a second.

**Acceptance:**

- [ ] Picker is itself fully themed; keyboard navigable; selection announced

### Task 3: Notebook Details (4h)

**Steps:**

1. Sidebar perforation refined: torn-edge illusion (radial-gradient hole row + subtle inner shadow), works on all paper tones.
2. Note ruled lines + slight rotate(-0.3deg) on the note block; list section headers in Caveat with a hand-drawn underline (inline SVG path, stroke = accent).
3. Custom checkbox finalized: circle, ink check path animating `stroke-dashoffset` on toggle.
4. Card shadows softened per theme (`--sw-shadow`), hover lift 1px.
5. Day header date styling: today gets a hand-drawn circle accent (inline SVG ellipse).

**Acceptance:**

- [ ] Details read well in all 5 themes (esp. midnight); nothing relies on a specific paper color

### Task 4: Micro-interactions (4h)

**Steps:**

1. Motion springs: task complete (checkbox spring + title strike draw 250ms), task add (scale/opacity pop), task remove (collapse), list section expand.
2. Drag overlay: ~2° tilt, scale 1.03, stronger shadow; drop settles with a soft spring (dnd-kit `dropAnimation` tuned).
3. Page elements stagger on week open (children fade/slide 20ms apart, ≤ 200ms total) - subtle, once per navigation.
4. Every animation gated by the reduced-motion resolver from Phase 3.

**Acceptance:**

- [ ] 60fps trace during complete/add/drag on a mid phone; reduced-motion kills all of it

### Task 5: Empty States & Seed Week (4h)

**Steps:**

1. `data/defaults.ts` seed content: localized starter tasks ("Спланувати тиждень ✨", "Випити води", …), one habit ("Прогулянка"), today's mood unset (let the user touch it) - keep it light, 3–4 items.
2. `seedFirstRun(uid)` in the ensure-profile flow: runs only when `tasks` and `habits` are both empty AND profile `createdAt` is fresh (< 5 min) - guarded, idempotent (marker field `seeded: true` on profile).
3. Empty-state components: tiny inline-SVG doodles (sparkle, leaf, mug) + Caveat one-liners for empty day / list / month / stats placeholder.
4. Localize seed by the device language at the moment of seeding.

**Acceptance:**

- [ ] Brand-new anonymous account lands on a friendly, non-empty week; existing accounts never get re-seeded

### Task 6: A11y & Audit (3h)

**Steps:**

1. Contrast audit per theme (axe + manual spot checks); fix token values, not components.
2. Focus-visible ring token (`--sw-accent` outline) applied app-wide; modal/popover focus traps verified.
3. Final greps: hex colors, raw `dayjs` imports, `firebase/` imports outside services, missing i18n keys.

**Acceptance:**

- [ ] Audit checklist clean; DoD sweep on desktop + phone in at least milk and midnight
