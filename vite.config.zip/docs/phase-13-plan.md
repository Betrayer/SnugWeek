# SnugWeek - Phase 13: Scheduling & Reminders

**Goal:** tasks can have a time of day, and optional gentle reminders that fire on time. Times show as cozy chips and order the day; reminders surface as a soft in-app toast plus a system notification (when permitted) and a sound - all client-side, working offline, no backend. True closed-app push is deferred to the backlog.

**Duration:** ~1.5–2 weeks part-time (~26 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §1, §2, §7, §8. Depends on Phase 9 (sound + notify helper) and Phase 10 (the **Task Detail** surface - the time & reminder editor lives there, not on the card).

---

## Definition of Done

- [ ] A day-task can be given a time ("HH:mm"); it shows a small time chip and timed tasks sort by time within the open group (untimed keep manual order); clearing the time is easy
- [ ] A day-task with a time can get a reminder offset (At time / 5 / 10 / 30 / 60 min before); the choice persists on the task and syncs
- [ ] List-bucket tasks may display a time chip but can't hold a reminder; moving a timed task to a list (incl. carry-over) clears `time` + `remindOffsetMin`
- [ ] When a reminder is due and the app is open (focused or backgrounded), it fires: a cozy in-app toast + a system notification (if permission granted) + a gentle reminder sound
- [ ] Setting the first reminder triggers a friendly permission request for system notifications; denial is respected (in-app + sound still work while the app is open); the choice is never nagged again
- [ ] Reminders that came due while the app was closed are surfaced once on next open if still recent (within a short grace window), de-duplicated so they never double-fire across reloads or tabs
- [ ] Completing a task before its reminder cancels that reminder; changing the time/offset re-schedules correctly; deleting the task cancels it
- [ ] Settings → Нагадування: master enable switch + default offset (device-local); a clear note that closed-app reminders are limited (and a pointer to the future push option)
- [ ] Times/labels are localized (en + uk) and respect the active dayjs locale; everything works offline; build/lint/tsc clean; no console errors

**Out of scope:** reminders that fire when the app is fully closed (→ backlog "Web Push / closed-app reminders"), recurring reminders (→ backlog "Recurring & routines"), snooze, calendar (ICS) export, reminders on list tasks.

---

## Task Breakdown

### Task 1: Task Timing Model (3h)

**Steps:**

1. Extend `Task` (and `normalizeTask`) in `tasksRepo.ts` with `time: string | null` and `remindOffsetMin: number | null` (read defensively → `null` when absent/invalid; validate `time` against `^([01]\d|2[0-3]):[0-5]\d$`).
2. Add writers: `setTaskTime(uid, taskId, time | null)` and `setTaskReminder(uid, taskId, offsetMin | null)` (`updateDoc`, bump `updatedAt`). Setting `time` to `null` must also null `remindOffsetMin` in the same write.
3. `createTask` keeps defaults `time: null, remindOffsetMin: null`.
4. `moveTask` already nulls `carriedFrom`; extend it to **null `time` + `remindOffsetMin` when the destination bucket is `list`** (a list task has no date for a reminder). Day→day moves keep the time.
5. `time.ts`: add `dateTimeOf(weekId, day, "HH:mm") → Date` (compose via the dayjs singleton) and `formatTime("HH:mm") → localized label`.

**Acceptance:**

- [ ] Old tasks load unchanged (null timing); setting/clearing time and offset round-trips offline
- [ ] Moving a timed task into a list clears its time + reminder

### Task 2: Time & Reminder Editor UI (4h)

**Steps:**

1. A compact time-and-reminder editor lives inside the **Task Detail surface** (Phase 10) - a "Час і нагадування" section, not a separate kebab entry. It opens a small inline editor / sheet:
   - **Time:** a cozy time control - `@mantine/dates` `TimeInput` (already a lazy dep) or a custom hour/minute picker styled with tokens; a "Прибрати час" clear button.
   - **Reminder:** a segmented/select of offsets (Без / Вчасно / за 5 / 10 / 30 / 60 хв), disabled until a time is set; default reflects `defaultReminderOffsetMin`.
2. Mobile: the same editor as a bottom sheet; large hit targets.
3. Keep the card UI calm - the editor is on demand, not inline clutter.

**Acceptance:**

- [ ] Setting a time + offset from desktop and mobile persists and reflects on the card
- [ ] Clearing the time disables and clears the reminder

### Task 3: Time Display & Sort (3h)

**Steps:**

1. `TaskCard`: when `time` is set, render a small time chip (token accent-2 tint, like the `carriedFrom` chip) before/after the title; when a reminder is set, a tiny bell glyph (inline SVG) next to it. Done tasks dim the chip.
2. Sorting: extend the day task sort so the **open** group orders timed tasks by `time` ascending, then untimed by manual `order`; the **done** group keeps existing behavior. Centralize in the existing `taskSort.ts` so week board + mobile pager + month logic agree.
3. Ensure DnD still works: manual reordering of untimed tasks is unchanged; reordering a timed task is allowed but its time still governs display order (document this in the editor copy: "час визначає порядок").

**Acceptance:**

- [ ] Timed tasks appear in chronological order above untimed ones; reload preserves it; DnD of untimed tasks unaffected

### Task 4: Reminder Scheduler (6h)

**Steps:**

1. `src/services/reminders/reminderScheduler.ts` (client-side, no backend):
   - **Source of upcoming reminders:** derive from already-subscribed task data for the **current and next week** (so today/tomorrow are always covered). Add a light subscription to next week's day-tasks if not already loaded, or compute from a small dedicated query `bucket=="day" && weekId in [current, next]` filtered client-side to tasks with `time != null && remindOffsetMin != null`.
   - **Fire time** per task = `dateTimeOf(weekId, day, time)` minus `remindOffsetMin` (via `time.ts`).
   - **Timers:** maintain `setTimeout`s only for reminders firing within a rolling horizon (e.g. next 12 h); re-arm on data change, on `visibilitychange → visible`, and when the horizon rolls. Never hold thousands of timers.
   - **On fire:** call `notify` (cozy in-app toast "🔔 <title> - зараз/за N хв"), show a system `Notification` if `Notification.permission === "granted"`, and `playPop()`/a dedicated reminder sound. Mark the reminder fired in a local de-dupe set keyed by `taskId + fireEpoch` in `localStorage` (`snugweek-reminded`), pruned of old entries.
   - **Cancellation:** if the task is completed, deleted, or its time/offset changes, drop its timer and don't fire (the subscription-driven recompute handles this - completed/changed tasks no longer match or have a new fire time).
2. **Missed-while-closed:** on scheduler start, scan due reminders whose fire time passed within a short grace window (e.g. last 1 h) and aren't in the de-dupe set → fire once (toast + optional system notification), then record them. Older-than-grace are silently skipped (a stale reminder is noise).
3. **Multi-tab safety:** the `localStorage` de-dupe set is shared across tabs (storage event optional); two tabs racing the same reminder converge to one fired record (guard: check-then-set, tolerate a rare double - acceptable).
4. Start/stop the scheduler from `Root` alongside the other stores (only when auth is ready); tear down timers on uid change.

**Acceptance:**

- [ ] A reminder set for ~1–2 min ahead fires once while the app is open (test focused and with the tab backgrounded)
- [ ] Completing the task before fire cancels it; changing the offset re-schedules
- [ ] Closing the app across a due time, then reopening within the grace window, surfaces it once (and not again on a second reload)

### Task 5: Permission UX & Settings (3h)

**Steps:**

1. Permission flow: the **first** time a user sets a reminder, show a gentle dialog explaining the benefit ("Showсповіщення нагадають вчасно - дозволити?") with an action that calls `Notification.requestPermission()`. Store that we've asked (device-local boolean) so it's never nagged again; honor `denied` (in-app toast + sound only); honor `granted` going forward.
2. `settingsStore` (bump `version` to `4`): add `remindersEnabled` (default `true`) + `defaultReminderOffsetMin` (default `10`) to `PersistedSettings`, setters, `partialize`, `migrate`. When `remindersEnabled` is off, the scheduler arms nothing.
3. Settings → Нагадування section: enable switch, default-offset select, current permission state with a button to re-request if `default` (not if `denied`), and a short honest note: reminders fire while SnugWeek is open in a tab or installed; a closed-app option is planned. (Link/anchor optional.)

**Acceptance:**

- [ ] First reminder triggers the permission ask exactly once; denial degrades gracefully; the toggle disables all scheduling
- [ ] Default offset is reflected in the task editor

### Task 6: Rules, i18n & Sweep (3h)

**Steps:**

1. `firestore.rules`: extend the task validator - `time` is `null` or matches the `HH:mm` regex; `remindOffsetMin` is `null` or a non-negative number; consistency: `remindOffsetMin == null` whenever `bucket == "list"`. Deploy; re-run a quick regression of the Phase 2 task paths.
2. i18n: add all new keys (editor labels, offsets, chips, toasts, permission dialog, settings) to en + uk; verify dayjs time formatting matches the locale.
3. Token + a11y sweep (editor focus trap, bell glyph `aria-hidden`, time chip readable in all 10 themes incl. mono/noir); real-phone test of set/fire/cancel.

**Acceptance:**

- [ ] Invalid timing writes are rejected by rules; valid app flows pass; DoD sweep passes on desktop + phone, light + dark themes
