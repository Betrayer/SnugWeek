# SnugWeek — Fixes Roadmap (Phases 22–29)

Continues from Phase 21. Eight grouped phases turning the fix list into work, written against the actual v0.2 code. Foundation first (refactor + load, then shell/nav/settings), then the visual/feature fixes. Run serially; each phase is independently shippable. Conventions unchanged (`CLAUDE.md`).

| # | Phase | Effort | Focus |
|---|---|---|---|
| 22 | Refactor, Load & Splash/Cover | ~1.5 wk | dedup chips/glyphs/fields, kill font pop (preload Cyrillic + `font-display`), surface the cover |
| 23 | Shell Rework: Top Bar, Nav & Settings IA | ~1.5 wk | header desktop+mobile, tools overflow, settings split into Налаштування/Блокнот, full-width layout |
| 24 | Day Board & Task Card Rework | ~2 wk | card visuals/elevation, add button in day header, click-toggle + hover icons + no checkbox, display-style setting, centered empty day, custom-weekend fix + styling |
| 25 | Habits in Days & Cheerful Delight | ~1.5 wk | per-day habit checks, management→settings (with streaks), reusable cheer system + intensity setting |
| 26 | Typography & Task Emoji | ~1.5 wk | curated OFL fonts + scope, pencil strikethrough variants, emoji on tasks/lists |
| 27 | Stickers Expansion & Authoring | ~1 wk | dozens more stickers, file-drop path, `docs/STICKERS.md`, palette at scale |
| 28 | Trackers & Statistics | ~1.5 wk | distinct tracker colors, count only existing tasks + recount, routines in stats, expanded views |
| 29 | Time Picker, Sharing & Layering | ~1.5 wk | real time picker, share real layout + unscheduled toggle, sidebar/modal layering fix |

**Total ≈ 12–13 weeks part-time.** Order is flexible after Phases 22–23 (the foundation).

## Decisions (all confirmed)

- Cover shows as the boot/splash background + a short "open the notebook" reveal into the week.
- Header: search, account, and the sync dot stay top-level; decorate, focus timer, week options, and language fold into one **tools** overflow menu. Mobile keeps the **4 bottom tabs** (Week / Month / Stats / Settings) + the existing docked quick-add (no 5th tab).
- Settings split into two top-level tabs: **Налаштування** (theme/font, sound, reminders, lock, data, account, about) and **Блокнот** (weekend/columns, modules, trackers, habits, tags, routines).
- Task row: click toggles done; desktop hover shows edit/open/delete; mobile shows the three icons compact + tap-title-toggle + long-press-open; checkbox removed; a profile `taskDoneStyle` controls done appearance.
- Weekend: Sat/Sun keep their stacked layout position; only the (now clearly distinct) off-color follows the weekend setting for any selected days.
- Cheer system: intensity setting (off / subtle / full), default subtle, milestone-weighted.
- Fonts: ~5 curated OFL faces, self-hosted, with a scope control (all / except tasks / only tasks).
- Emoji: curated cozy grid + native input.
- Stickers: large batch in the current style + a file-drop path for richer designed SVGs later.
- Stats additions: weekday productivity, time-of-day distribution, tags breakdown, tracker trends, habit consistency %, streak summary, month-over-month.
- Time picker: dropdown hour/minute + quick presets, reused everywhere.
- Share: actual board layout at full size; unscheduled tasks shown as a side panel when included.
