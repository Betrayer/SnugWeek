# SnugWeek - Phase 14: Recurring Tasks & Routines

**Goal:** define routines that auto-fill day columns - a morning checklist, a weekly review, "every Mon/Wed/Fri" habits-as-tasks - so the user sets them up once and the week arrives pre-planned. Materialization is lazy and idempotent, mirroring the carry-over pattern, and never duplicates or fights manual edits.

**Duration:** ~1 week part-time (~16 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §1. Depends on Phase 13 (reuses task `time`/`remindOffsetMin`).

---

## Definition of Done

- [ ] A routine can be created: title, frequency (daily / specific weekdays), optional time + reminder, active toggle
- [ ] On opening the app, the current and next week get their routine tasks materialized into the right day columns, exactly once each - reopening, multiple tabs, and offline starts never duplicate them
- [ ] Routine-generated tasks are normal tasks (can be completed, edited, moved, deleted) and carry a subtle "повторюється" indicator; deleting one for a given week does not resurrect it that week
- [ ] Editing or pausing a routine affects **future** materialization only; already-generated tasks are untouched
- [ ] Routines list: view/edit/pause/delete; deleting a routine leaves past generated tasks alone
- [ ] Works offline (materializes from cache, syncs later); strings en + uk; build/lint/tsc clean; no console errors

**Out of scope:** complex recurrence (monthly, "every 2nd Tuesday", intervals), end dates/limits, routine-level reminders independent of the generated tasks (the generated task carries the reminder), retroactive backfill of past weeks.

---

## Task Breakdown

### Task 1: Routine Model & Repo (3h)

**Steps:**

1. `users/{uid}/routines/{routineId}` per addendum §1 (`title`, `freq: "daily"|"weekly"`, `days: number[]`, `time`, `remindOffsetMin`, `active`, `createdAt`). `services/repos/routinesRepo.ts`: CRUD + `subscribeRoutines`.
2. Guard collection `users/{uid}/routineRuns/{weekId}`: a doc recording which routine ids have been materialized for that week (`{ routineIds: string[], updatedAt }`).
3. `firestore.rules`: validate routine shape (freq whitelist, `days` ISO 1..7, time regex/null) + run-guard shape.

**Acceptance:**

- [ ] Routine CRUD round-trips; run-guard reads/writes correctly offline

### Task 2: Materializer (5h)

**Steps:**

1. `services/routines/materializeRoutines.ts`: for `weekId in [current, next]`, read active routines + the week's `routineRuns` guard; for each active routine not yet listed in the guard, create its tasks for the matching days of that week (`daily` → all 7 or all working days - decide and document; `weekly` → its `days`), with `bucket:"day"`, the routine's `time`/`remindOffsetMin`, `routineId` set, and a top/`order` placement; then add the routine id to the guard. Use a `writeBatch` per week.
2. **Idempotency** is structural: a routine id present in the week's guard is skipped. Deleting a generated task for a week leaves the guard intact, so it is not recreated that week (matches user intent).
3. Trigger from `Root` alongside carry-over (after auth ready + on `visibilitychange → visible`, throttled), only when authed. Offline: runs against cache, writes queue.
4. Multi-tab/multi-device safety: two runners racing the same week converge (guard is check-then-add; tolerate a rare duplicate create - acceptable, and de-dupe by `routineId+day+weekId` if you want to be strict).

**Acceptance:**

- [ ] First open of a fresh week creates routine tasks once; reopening/another tab/offline start creates none extra
- [ ] Deleting a generated task doesn't resurrect it that week; next week still generates

### Task 3: Routine Editor & List (4h)

**Steps:**

1. A "Рутини" area (Settings section or a small manager reachable from the week toolbar): list routines with active toggles; create/edit via a form (title, daily/weekday chips, optional time + reminder reusing the Phase 13 editor), delete.
2. Pausing (`active: false`) stops future materialization; editing changes future runs only.
3. Copy clarifies the model: changes apply to upcoming weeks, not already-planned ones.

**Acceptance:**

- [ ] Create/edit/pause/delete behave; the "future only" semantics are clear and correct

### Task 4: Card Indicator, i18n & Sweep (4h)

**Steps:**

1. `TaskCard`/`TaskDetail`: a subtle "повторюється" chip (token-styled) when `routineId` is set; optionally a link from the task to its routine in the detail.
2. en + uk for all strings; verify weekday chips + time labels follow the locale.
3. Token/a11y sweep; real-phone test; verify carry-over and routines coexist (a routine task left open still carries over per Phase 3 rules, losing `routineId`? - decide: carry-over moves to a list and nulls `routineId` like other location-moved fields, so it won't be regenerated; document this interaction).

**Acceptance:**

- [ ] Indicator reads well; routines + carry-over interact predictably and are documented; full DoD passes desktop + phone
