# SnugWeek — Phase 25: Habits in Days & Cheerful Delight

**Goal:** rework habits so they're managed in settings and checked inside each day, and add gentle "well done" moments (short messages + tiny animations) that make positive actions feel warm.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §4. Touches `HabitGrid.tsx`/`ListsPanel.tsx`, `HabitSettings.tsx`, `DayColumn.tsx`, `weekStore`.

---

## Definition of Done

- [ ] Each day shows its active habits with a one-tap per-day check (writes that day's `habitChecks`); the full-week habit grid is removed from the sidebar
- [ ] All habit management (add / rename / archive / icon / reorder) lives in Settings → Блокнот, including the streak 🔥 display, which survives the move
- [ ] A reusable cheerful-feedback system plays a brief (1–2 s) cue — a gentle localized message and/or a small floating heart/sparkle — on habit check, task completion, and small milestones (streaks, all day-tasks done)
- [ ] An intensity setting (off / subtle / full, default subtle) controls how often cheers appear; cheers are milestone-weighted, never block interaction, and respect reduced-motion (message without motion)
- [ ] Works offline + multi-tab; strings en + uk; build/lint/tsc clean

**Out of scope:** habit analytics in stats (Phase 28 covers routines/habits stats), new habit data types.

---

## Task Breakdown

### Task 1: Per-Day Habit Checks (5h)

**Steps:**

1. Add a compact habit row to the day surface (in `DayColumn`, near `DayTrackerRow`), gated by the `habits` module toggle: for each active habit, one check toggle for *that day* via the existing `weekStore.toggleHabit(habitId, day)`; show the habit icon + a small label or tooltip.
2. Remove the full-week `HabitGrid` render from `ListsPanel` (the sidebar).
3. Keep it tidy on mobile (in the day card) and desktop (in the column).

**Acceptance:**

- [ ] Each day shows its habits with one-tap checking; the sidebar no longer shows the week grid; offline + two tabs converge

### Task 2: Habit Management In Settings (4h)

**Steps:**

1. Ensure `HabitSettings` (Settings → Блокнот) covers add / rename / archive / restore / icon / reorder.
2. Move the streak 🔥 display into the settings list (per habit current streak), so it's preserved after removing the grid.
3. Remove any now-dead grid-only code paths.

**Acceptance:**

- [ ] Everything about habits except the daily check is managed in settings, including streaks; nothing lost

### Task 3: Cheerful Delight System (7h)

**Steps:**

1. `services/cheer/cheerService.ts` + a small overlay component: a pool of localized gentle messages and a few micro-animations (a heart/star floating up, a soft sparkle burst) lasting 1–2 s, rendered above content without blocking pointer events.
2. Triggers: habit check, task complete (open→done), and milestones (streak reaches 3/7/…, all day-tasks for a day done). Milestone-weighted so it doesn't fire on literally everything.
3. Intensity setting (device-local in `settingsStore`, bump version): `cheerLevel` = `off` | `subtle` | `full`, default `subtle`; `subtle` favors milestones, `full` allows per-action cues. Reduced-motion shows the message without motion.
4. Add the setting control (Settings → Appearance or Блокнот) and localized copy (en + uk).

**Acceptance:**

- [ ] The chosen moments show a brief, tasteful cheer; intensity setting changes frequency; reduced-motion-safe; never blocks interaction
