# SnugWeek — Phase 31: Month Tracker View

**Goal:** add a second month view in the bullet-journal "daily habit tracker" style — colored day columns across the top, and colored per-day fills for each habit, routine, and task — switchable with the current calendar view.

**Duration:** ~2 weeks part-time (~28 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `CLAUDE.md`. Touches `MonthPage.tsx`, a new `month/MonthTracker*` set, `monthStore.ts`, `time.ts`.

---

## Design (decided)

- A view toggle at the top of the Month page switches between **Календар** (the current grid) and **Трекер** (the new view); one is shown at a time; the choice is remembered (device-local).
- The tracker is a grid: a left **name column**, then **day columns 1..N** with softly-colored headers (a pleasant per-day color sequence from the theme). Rows are grouped into labelled **sections with horizontal dividers**, in this order: **Звички**, **Рутини**, **Задачі** (no sidebar lists — they don't fit this view).
  - **Звички / Рутини:** one row each; a colored cell on every day the habit was checked / the routine's task was completed (a lighter cell for a routine scheduled-but-not-done).
  - **Задачі:** one row per day-bucket task that falls in the month, sorted by day; a solid colored cell on its day if done, a light/hatched cell if still open.
- Cell fills use the row's color (assigned per row from the curated palette) with a soft hatch/solid look reminiscent of the reference. Tapping a cell opens that day's week; the name column is sticky and the day header is sticky; the grid scrolls horizontally on mobile.

---

## Definition of Done

- [ ] The Month page has a Календар/Трекер toggle; the choice persists; both render correctly
- [ ] The tracker shows day-number columns with colored headers and three labelled sections (Звички, Рутини, Задачі) with horizontal dividers
- [ ] Habits/routines show colored cells on their active/checked/completed days; tasks show one row each (sorted by day) with solid (done) vs light (open) cells; the general task lists are not shown
- [ ] Each row has its own color; fills read clearly in all 10 themes (incl. mono/noir); today's column is marked
- [ ] The name column and day header stay put while scrolling; the grid scrolls horizontally on phones; tapping a cell opens that day's week
- [ ] Empty month and module-off cases degrade gracefully (a section with no rows is hidden); works offline; build/lint/tsc clean; strings en + uk

**Out of scope:** editing checks directly from the tracker (read-only overview; tap opens the week), per-cell tooltips beyond date, exporting the tracker.

---

## Task Breakdown

### Task 1: Month Tracker Data (6h)

**Steps:**

1. Extend `monthStore` (or add a `buildMonthTracker` assembler) to produce, for the open month: per-habit per-day checks (from the month's week docs `habitChecks`), per-routine per-day completion (from day tasks carrying `routineId` + their status), and the list of day-bucket tasks in the month with their day + status. Reuse the month's already-loaded week docs / day tasks.
2. Shape it as ordered sections of rows, each row = `{ id, label, icon?, color, cells: Map<dateKey, "full" | "light" | none> }`.
3. Assign a row color deterministically from the curated palette (cycle by index) so each row is visually distinct.

**Acceptance:**

- [ ] The assembler returns correct per-day cells for habits, routines, and tasks for a seeded month; offline from cache

### Task 2: Day Headers & Grid Shell (5h)

**Steps:**

1. `time.ts`: a helper for the month's day list (1..N with weekday + weekend flag).
2. `MonthTracker.tsx`: a CSS-grid (or sticky-positioned) table — sticky left name column, sticky top day-header row with softly-colored day cells (a theme-derived color sequence; weekend days tinted), today's column marked. Horizontal scroll container for narrow screens.

**Acceptance:**

- [ ] Day headers render colored and aligned; name column + header stay fixed while scrolling; today marked; scrolls on mobile

### Task 3: Sections & Cells (5h)

**Steps:**

1. Render the three labelled sections (Звички / Рутини / Задачі) with horizontal dividers and section headers; hide a section with no rows.
2. `MonthTrackerCell`: a colored fill in the row color — `full` solid (done/checked), `light` a soft/hatched tint (open/scheduled), empty otherwise; subtle borders so the grid reads like the reference. Tap → open that day's week (`onOpenWeek(weekId, iso)` like the calendar).
3. Row label: icon + name (habit/routine name, or the task title for task rows), truncated with a tooltip.

**Acceptance:**

- [ ] Sections, dividers, and colored cells render like the reference; cells open the right week; long labels truncate cleanly

### Task 4: View Toggle & Wiring (4h)

**Steps:**

1. `MonthPage.tsx`: a Календар/Трекер segmented control; persist the choice device-local (`settingsStore`, e.g. `monthView`); render the chosen view.
2. Keep the month nav (prev/next/today) shared across both views.

**Acceptance:**

- [ ] Toggling views is instant and remembered; nav works for both

### Task 5: Polish, A11y & Sweep (4h)

**Steps:**

1. Color/contrast pass for fills and day headers across all themes (esp. mono/noir — use shape/opacity, not just hue, so mono stays legible).
2. A11y: the grid has sensible roles/labels; cells are reachable and labelled (date + entity + state); horizontal scroll is keyboard-operable.
3. en + uk for section labels, toggle, and cell aria; real-phone test of the horizontal scroll; empty/sparse months.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; i18n missing-key warnings zero
