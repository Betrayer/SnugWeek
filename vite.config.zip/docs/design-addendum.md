# SnugWeek - Design Addendum v0.3 (Phases 9+)

**Status:** extends `docs/DESIGN.md`. Everything here is **additive** - no breaking changes to the v1 data model, stores, or conventions. Where this document and `DESIGN.md` disagree, the more specific statement here wins for v0.2 features only.
**Last updated:** 2026-06-15
**Covers:** the full v0.2 roadmap (Phases 9–21). Section numbers §1–§7 are stable from v0.2; §8 (UX principles) and §9 (onboarding) are new and apply to every phase.

All v1 conventions still hold (no `any`, no comments, arrow consts + named exports, Mantine-only, no external icon libs, tokens only, dates only via `services/time.ts`, components never import `firebase/*`, no manual optimistic state, everything works offline, device-local settings in `settingsStore` / synced settings in the profile doc). Read `CLAUDE.md` first, then `docs/roadmap.md` for sequence and rationale.

---

## 1. Data model deltas

All new task fields are nullable and normalized to `null`/defaults when absent, so old docs keep working. New collections live under `users/{uid}`. Each new collection/field lists the phase that introduces it.

### `users/{uid}/tasks/{taskId}` - new optional fields

```ts
{
  // ...existing v1 fields...
  time: string | null,             // "HH:mm" local; day-bucket only           (P13)
  remindOffsetMin: number | null,  // null = no reminder; 0|5|10|30|60          (P13)
  attachmentCount: number,         // denormalized, default 0                   (P16)
  tagIds: string[],                // default []                                (P12)
  subtaskCount: number,            // denormalized total, default 0             (P12)
  subtaskDone: number,             // denormalized done count, default 0        (P12)
  routineId: string | null,        // set on routine-generated tasks            (P14)
}
```

- A reminder's absolute fire moment is **computed, never stored**: `dateOf(weekId, day)` at `time`, minus `remindOffsetMin`. `time`/`remindOffsetMin` are meaningful only when `bucket === "day"`; moving a timed task into a list (incl. carry-over) nulls both, like `carriedFrom`.
- `attachmentCount`/`subtaskCount`/`subtaskDone` drive card indicators (📎, "2/5") without extra subscriptions; maintained in the same write as the change.

### `users/{uid}/tasks/{taskId}/items/{itemId}` - subtasks (P12)

A subcollection (not an embedded array) so long checklists stay cheap and reorderable:

```ts
{ title: string, done: boolean, order: number, createdAt: number }
```

Add/remove/toggle updates the parent's `subtaskCount`/`subtaskDone` in the same `writeBatch`.

### `users/{uid}/tags/{tagId}` - labels (P12)

```ts
{ name: string, color: string, order: number, createdAt: number }
```

`color` is an **id into a curated, token-aligned palette** (not freeform hex), so tags stay on-brand across themes. Filtering a week/list by tag is client-side over loaded tasks plus, if needed, an `array-contains` query (`tagIds array-contains <id>`).

### `users/{uid}/routines/{routineId}` - recurring (P14)

```ts
{
  title: string,
  freq: "daily" | "weekly",
  days: number[],                  // ISO 1..7 for weekly; ignored for daily
  time: string | null,
  remindOffsetMin: number | null,
  active: boolean,
  createdAt: number,
}
```

A lazy materializer (same pattern as carry-over) instantiates routine tasks into the current/next week on session start, idempotently: generated tasks carry `routineId`, and a per-week guard doc `users/{uid}/routineRuns/{weekId}` records which routines have been materialized for that week. Editing/pausing a routine never touches already-generated tasks.

### `users/{uid}/attachments/{attachmentId}` - files & links (P16)

Polymorphic target (task | list | day); full shape in v0.2 addendum §5 (unchanged): `targetType`, the matching id fields, `kind` (`image|audio|video|file|link`), `order`, `createdAt`, file fields (`storagePath`, `url`, `name`, `mime`, `size`, `thumbPath`, `width`, `height`, `durationMs`) or link fields (`href`, `title`, `previewImage`).

### `users/{uid}/weeks/{weekId}` - new optional maps

```ts
{
  // ...existing v1 fields...
  decorations: Decoration[] | null,   // stickers/washi/doodles placed on the spread (P17)
}
```

`Decoration = { id, kind: "sticker"|"washi"|"doodle", asset: string, target: "week"|number /* ISO day */, x, y, rotation, scale }`. Kept on the week doc (bounded count, written together). `asset` is a registry key of a curated inline-SVG, never a URL.

### `users/{uid}/shares/{shareId}` - read-only sharing (P20)

A **snapshot copy** of one week's chosen data (never a public grant on live docs):

```ts
{
  weekId: string,
  createdAt: number,
  include: { tasks: boolean, note: boolean, trackers: boolean, habits: boolean, decorations: boolean },
  snapshot: { /* the included, denormalized week data */ },
}
```

Public read is allowed only on `shares/{shareId}` (unguessable id); revoke = delete the doc. The owner picks what's included (notes/attachments may be excluded for privacy). Attachments are referenced as view URLs only if the owner opts in.

### Profile doc - new synced fields

```ts
{
  // ...existing v1 fields...
  autoTheme: { light: string, dark: string } | null,   // follow-system, default null (P11)
  notebookName: string | null,                           // personalization (P17)
  coverStyle: string | null,                             // personalization (P17)
  paperTextureEnabled: boolean,                          // default false (P11)
}
```

### Device-local only (never synced - see §2)

Journal lock (P19), focus-timer state (P18), onboarding/tour progress (P9/§9), sound, reminders master toggle, search recents.

### `firestore.rules` additions (per introducing phase)

Validators extend per collection: task `time` matches `^([01]\d|2[0-3]):[0-5]\d$` or null, `remindOffsetMin` null-or-non-negative, `tagIds` a list, counts `>= 0`; subtasks/tags/routines/attachments/decorations shape + size caps; `shares` readable publicly but writable owner-only. Indexes: `tags`-filter (`tagIds array-contains`), attachments by target, etc. - created from console links as they appear.

---

## 2. Device-local settings (settingsStore) deltas

`settingsStore` is the single device-local persisted store. Phases extend `PersistedSettings` and bump `version` (currently `2`); each bump's `migrate` spreads `defaultSettings` then the stored partial.

```ts
interface PersistedSettings {
  language; reduceMotion; transition;                 // v1
  soundEnabled: boolean;            // default true            (P9)
  soundVolume: number;              // 0..1, default 0.6       (P9)
  remindersEnabled: boolean;        // default true            (P13)
  defaultReminderOffsetMin: number; // default 10              (P13)
  lockEnabled: boolean;             // default false           (P19)
  lockMethod: "pin" | "passkey" | null; // default null        (P19)
  lockAfterMin: number;             // auto-lock idle, default 5 (P19)
  tourSeen: boolean;                // default false           (P9 infra / §9)
}
```

PIN hashes, passkey credential ids, focus-timer presets/state, search recents, the boot-splash theme cache (`snugweek-theme`), and per-task "we already asked for notification permission" live in **plain localStorage keys**, not the store (either sensitive, hot, or pre-paint).

Rationale for device-local: volume, "notify on this device", lock, and tour progress are per-device. Per-task data (reminders, tags, subtasks) is synced (it lives on the task docs).

---

## 3. Theme expansion & texture (P11)

Themes remain pure data (a `ThemeSpec` file + a `tokens.css` block + a registry entry); **no component changes, no new color tokens.** Five new ids (total 10): `snow` (minimal white), `mono` (light greyscale), `noir` (dark greyscale), `sky` (soft blue), `cocoa` (warm coffee). `THEME_ORDER` is reorganized into labelled groups for the picker.

**Paper texture (P11):** the `--sw-paper-texture` token already exists (currently `none`). P11 wires a few tasteful low-contrast textures behind `profile.paperTextureEnabled`, gated by the same contrast checks. **Optional follow-system** writes `profile.autoTheme` (a light/dark pair) and resolves via `matchMedia` in `Root` + the pre-paint inline script.

---

## 4. Sound (P9)

Self-contained `src/services/sound/` over the **Web Audio API - no new dependency.** Lazy `AudioContext` unlocked on first gesture; a master `GainNode` reads `soundEnabled`/`soundVolume` at call time; per-sound throttle; no-op when disabled / `document.hidden` / locked. `check`/`pop`/`swoosh` are synthesized (ship immediately); `flip` uses an optional tiny sample (`public/sounds/flip.webm` + `.mp3`) with a synthesized fallback. Hooks: `playFlip()` on user-initiated week navigation only; `playCheck()` on `open → done`; `playPop()`/`playSwoosh()` on add/delete. The focus timer (P18) reuses this service for chimes.

---

## 5. Attachments pipeline (P16)

Unchanged from v0.2 addendum. **Storage backend is an owner decision** (Firebase Storage requires the Blaze plan as of 2026-02-03 - free allowance still applies, billing account required; alternatives: Cloudflare R2, Cloudinary/Supabase). All IO behind `services/storage/storageService.ts` so the backend is swappable. Images compressed + thumbnailed client-side; in-app voice notes via `MediaRecorder`; video/files size-capped; links are doc-only and work offline. Owner-only storage rules with content-type allowlist + size caps.

---

## 6. Splash & font stability (P9)

Unchanged from v0.2 addendum: self-host the five faces under `public/fonts/` (explicit `@font-face`, replacing `@fontsource` `@import`s), preload the splash-critical faces, render a static boot splash **inside** `#root`, and a pre-paint inline `<script>` reading `localStorage["snugweek-theme"]` to set `data-snug-theme` + the splash paper so there's no font swap and no dark-theme flash. The React `Splash` is unified and gains a reduced-motion-aware breathing loop. The inline theme map must include all 10 theme ids (P11).

---

## 7. Notifications policy (P9)

`@mantine/notifications` is wired (error-only today). v0.2+ adds **cozy, sparse** confirmations via `services/notify.ts` (themed, de-duped, throttled). Notify only for: background/async events the user can't see (carry-over moved N, routine generated tasks, reminder fired, export/import done), consequences of destructive actions (list/tag deleted), and cross-state successes (account saved/linked, merge done, share created). **Never** for actions with immediate visible feedback (add task, check box, edit, switch theme/week).

---

## 8. UX & layout principles (P10 - and binding on every later phase)

P10 is a dedicated pass; these principles also govern how **every** feature phase places its UI. The goal Bohdan asked for: things land where the hand and eye expect them, on desktop and on the phone.

- **One primary action per surface, obvious and reachable.** The week's primary action is "add a task"; it must be a single, consistent affordance in every column/list and a thumb-reachable quick-add on mobile. Secondary/rare actions live in an overflow menu, not scattered as loose buttons.
- **The task card stays calm; depth lives in a Task Detail surface.** Tapping a card body opens a **Task Detail** panel (desktop side panel/popover) or **bottom sheet** (mobile) that hosts everything beyond the title: subtasks (P12), tags (P12), time & reminder (P13), attachments (P16), notes. The card itself only shows the checkbox, title, and small indicators (chips/counters). This single pattern is the home for most v0.2 features, so it is built in P10 and reused everywhere.
- **Mobile uses sheets, not top-anchored dropdowns.** Menus, pickers, and editors open as bottom sheets with large hit targets (≥ 44px), within thumb reach. A shared `ResponsiveMenu`/`BottomSheet` primitive (P10) backs the kebab menus, the Move-to picker, the time editor, etc.
- **Consistent action surface.** A shared `ActionMenu` standardizes kebab contents, order, destructive styling (`--sw-danger`), and confirmation behavior, so every entity (task, list, tag, habit, attachment) feels the same.
- **Settings are sectioned and navigable.** As settings grow (appearance/theme/texture, modules, schedule, sound, reminders, lock, account, about), they are grouped with a clear sub-navigation (tabs or an accordion index), not one long scroll.
- **Header carries only what matters.** Wordmark/account, the week title + nav (prominent), "today", and the search/command entry (P15). Everything else folds into menus; the mobile header stays minimal with the bottom tab bar owning navigation.
- **Empty, loading, and skeleton states are consistent and cozy** (Caveat one-liners + a small doodle), reused via shared components.
- **Motion & sound respect the same reduced-motion/disabled switches** already established; new UI never bypasses them.
- **Accessibility is non-negotiable:** logical tab order, themed focus-visible rings (done), ARIA on menus/sheets/dialogs, escape-to-close, and contrast verified in all 10 themes (incl. mono/noir).

Shared primitives delivered in P10 and reused by later phases: `TaskDetail` (panel/sheet), `BottomSheet`/`ResponsiveMenu`, `ActionMenu`, `SectionedSettings`, a unified `AddControl`, and standard empty/skeleton components.

---

## 9. Onboarding & guided tour (P21, with hooks from P9)

A first-run **guided product tour** ("coach marks"): an overlay dims the screen with a spotlight cutout over a target element while a cozy Mantine `Popover` bubble explains it, with Back / Next / Skip and progress dots.

- **Build approach:** a lightweight **custom** tour (Mantine `Popover` anchored to element refs + an SVG/again overlay with a highlighted cutout + a small ordered step registry) - keeps it on-brand and dependency-free, honoring the Mantine-only / no-extra-UI-libs rule. (Driver.js is an acceptable fallback if a custom overlay proves fiddly, but theme it to match.)
- **Step registry:** each step = `{ id, targetRef, title, body, placement, mobileOnly?/desktopOnly? }`. Targets are provided via a tiny ref-registry context so components register their anchor without coupling to the tour.
- **Trigger:** after first-run seeding completes, a gentle "Show me around?" prompt; gated by the device-local `tourSeen` flag (§2). Re-runnable from Settings → "Повторити тур".
- **Content:** ~6–10 core steps - week board, add a task, the Task Detail surface, drag-and-drop, sidebar lists, day trackers + habits, the week note, month overview, stats, themes/settings. Skippable; mobile-aware (anchors to mobile elements / bottom bar where layout differs).
- **Advanced features use contextual one-time hints, not the main tour:** a small reusable `Hint` (a one-time themed `Popover` shown the first time a feature surface is opened - tags, attachments, reminders, decorations), tracked by per-feature flags in localStorage. This scales as features land without bloating the initial tour. P21 ships the main tour + the `Hint` primitive; each feature phase from P12 on can register its own hint.

---

## 10. Phase map (full v0.2 roadmap)

| Phase | Theme | Core deltas |
|------|-------|-------------|
| 9  | Sensory Layer | splash/font stability, sound service, notifications policy |
| 10 | UX & Layout Refinement | ergonomics, button placement, Task Detail surface, shared primitives, sectioned settings, mobile sheets, a11y |
| 11 | Themes & Texture | 5 new themes (incl. minimal-white & mono), grouped picker, paper textures, optional system-follow |
| 12 | Tasks Deepened | subtasks/checklists, tags + filtering |
| 13 | Scheduling & Reminders | task time + client-side reminder scheduler (in-app + Web Notifications) |
| 14 | Recurring & Routines | routine definitions + lazy idempotent materializer |
| 15 | Search & Quick Actions | command/search surface (visible entry + optional ⌘K), quick-add |
| 16 | Attachments | storage backend, images/voice/video/files/links on tasks/days/lists |
| 17 | Personalization & Decoration | stickers/washi/doodles, notebook name & cover |
| 18 | Reflection & Focus | weekly recap card, focus (Pomodoro) timer |
| 19 | Privacy & Portability | journal lock (PIN/passkey), JSON export/import |
| 20 | Output & Sharing | print/PDF of a week, read-only week sharing, PWA shortcuts |
| 21 | Onboarding & Guided Tour | first-run product tour + contextual hint primitive |

**Deferred to a later major update** (explicitly parked, remember for the future, not in v0.2): **Web Push / closed-app reminders (FCM)** - completes Phase 13's reminders when the app is fully closed (needs a backend sender); **additional UI languages** beyond uk/en (the en-source i18n pipeline supports it); **Telegram Mini App wrapper** (RU/UA reach). Phase 13's reminder copy and Phase 15/settings should leave room for these without depending on them.
