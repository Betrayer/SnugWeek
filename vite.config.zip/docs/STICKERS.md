# Adding Stickers (Decorations)

SnugWeek's decorations live in two places. You can add new ones without touching any component code.

1. **Inline set** - hand-authored entries in [`src/data/decorations.tsx`](../src/data/decorations.tsx). These are the curated built-ins.
2. **File-drop set** - any `.svg` file under [`src/data/stickers/`](../src/data/stickers/). Dropped files are auto-registered at build time via `import.meta.glob` (see [`src/data/stickerDrops.tsx`](../src/data/stickerDrops.tsx)) and appear in the palette next to the built-ins. No code changes needed.

This guide covers the file-drop path - the easiest way to add a sticker.

---

## Where to put it

```
src/data/stickers/<category>/<name>.svg          # tintable (themed)
src/data/stickers/<category>/<name>.color.svg     # colorful (rendered as-is)
```

- `<category>` is the folder. It must be one of the known categories (anything else falls back to `misc`):
  `hearts`, `celestial`, `weather`, `plants`, `animals`, `food`, `seasonal`, `scene`, `misc`, `washi`, `doodle`.
  The folder decides which palette tab the sticker shows under.
- `<name>` becomes part of the sticker id (`drop-<category>-<name>`) and is what the palette search box matches on. Use a short kebab-case English word, e.g. `clover-leaf`.
- The `.color` infix (before `.svg`) marks a **colorful** sticker. Without it, the sticker is **tintable**.

## Two kinds

### Tintable (single-color, themed)

Use `currentColor` for every fill/stroke you want recolored. The sticker is tinted with the theme accent and stays readable across all 10 themes - exactly like the built-in stickers.

- `fill="currentColor"` / `stroke="currentColor"` -> the themed tint.
- `fill="var(--sw-card)"` -> a paper-colored knock-out for cut-out details (eyes, holes, highlights).
- You may also use any `--sw-*` token (e.g. `var(--sw-ink-2)`) for a fixed accent detail.

### Colorful (as-is)

Give the file a `.color.svg` name and use whatever fixed colors you like (`#hex`, named colors). The sticker is rendered unmodified - the theme tint is ignored. Good for multi-color art.

## Format rules

- **SVG only.** Plain SVG syntax is fine here (kebab-case attributes like `stroke-width` are OK - these files are not JSX).
- Keep a `viewBox`. Square (`0 0 32 32`) matches the built-ins best, but any ratio works.
- **Sizing is automatic.** The on-page size is normalized from the `viewBox` aspect ratio (longest side ~54px), so dropped files place consistently regardless of the numbers you draw with. You do not set width/height for placement.
- Single, self-contained art. Do not rely on external references, `<script>`, or remote URLs. Gradients/filters work for colorful stickers but won't be themed.
- The outer `<svg>` wrapper and any XML prolog / comments are stripped automatically; only the inner shapes are kept.

## The animated flag

Dropped stickers are animatable by default: once placed, the decoration popover lets you pick an animation (`Sway`, `Spin`, `Float`, `Pulse`) just like built-in stickers. There is nothing to set in the file.

---

## Copy-paste templates

### Tintable - `src/data/stickers/plants/clover-leaf.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="32" height="32">
  <circle cx="16" cy="11" r="5" fill="currentColor" />
  <circle cx="11" cy="18" r="5" fill="currentColor" />
  <circle cx="21" cy="18" r="5" fill="currentColor" />
  <circle cx="16" cy="16" r="2.4" fill="var(--sw-card)" />
  <path d="M16 18v9" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" />
</svg>
```

### Colorful - `src/data/stickers/scene/balloons.color.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="32" height="32">
  <path d="M11 17.5 16 27M21 18 16 27M16 15 16 27" stroke="#9a8a73" stroke-width="1" fill="none" />
  <ellipse cx="16" cy="9" rx="5" ry="6" fill="#e3ad6f" />
  <ellipse cx="11" cy="11.5" rx="5.5" ry="6.5" fill="#df8c6e" />
  <ellipse cx="21" cy="12" rx="5" ry="6" fill="#7aa6d6" />
</svg>
```

Both example files ship in [`src/data/stickers/scene/`](../src/data/stickers/scene/) - drop a new file next to them, run the app, and it shows up in the palette.

---

## Adding to the inline set instead

If you want a sticker bundled as a first-class built-in (e.g. to set a specific default tint token), add a `DecorationAsset` entry to `INLINE_DECORATIONS` in [`src/data/decorations.tsx`](../src/data/decorations.tsx). The shape:

```tsx
{
  id: "heart",
  kind: "sticker",
  category: "hearts",
  tint: "var(--sw-accent)",
  w: 54,
  h: 54,
  viewBox: "0 0 32 32",
  body: (
    <path d="M16 27C16 27 4 19.4 4 11.4A6 6 0 0 1 16 9.2 6 6 0 0 1 28 11.4C28 19.4 16 27 16 27Z" fill="currentColor" />
  ),
},
```

Note: `body` here is **JSX**, so attributes are camelCase (`strokeWidth`, not `stroke-width`). The `inner` helper (a soft highlight token) is in scope for layered details. For everything else, the file-drop path above is simpler.
