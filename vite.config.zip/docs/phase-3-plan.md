# SnugWeek - Phase 3: Week Flow - Navigation, Fold Transition, Carry-over, Month Overview

**Goal:** weeks become a navigable notebook: arrows/calendar/URL navigation with the page-fold animation, unfinished tasks auto-carry into "Задачі", and the month overview gives the bird's-eye view.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.

---

## Definition of Done

- [ ] Header arrows move ±1 week; "Сьогодні" button returns to the current week; URL always reflects the open week
- [ ] Clicking the week title opens a mini-calendar popover; picking any date jumps to its week
- [ ] Forward navigation folds the page left (notebook-like), backward folds right; ~450ms, 60fps, content stays crisp
- [ ] `prefers-reduced-motion` or the settings toggle replaces the fold with an instant swap; Settings has a transition picker (Перегортання / Без анімації)
- [ ] Opening the app in a new week moves last week's unfinished day-tasks into "Задачі", each with a "з W##" chip; nothing duplicates on repeated opens, second devices, or offline starts
- [ ] `/month/2026-06` renders a month grid: rows = weeks, cells = days with date, open-count dot and done-count tick; today highlighted; weekend dimmed
- [ ] Month navigation: arrows ±1 month, "Сьогодні"; clicking a week row opens that week; clicking a day cell opens its week (mobile: lands the pager on that day)
- [ ] Month view works on mobile (compact cells) and offline
- [ ] Build, lint, tsc clean; no console errors

**Out of scope:** the realistic `curl` transition (registry slot only), tracker/mood data in month cells (Phase 4 enriches them), stats.

---

## Task Breakdown

### Task 1: Week Navigation (3h)

**Steps:**

1. `npm i motion`.
2. `useWeekParam.ts` hook: parse/validate `:weekId`, expose `goTo(weekId)`, `next()`, `prev()`, `today()` via `useNavigate`; track `direction: 1 | -1` for the transition (store last navigation delta in `uiStore`).
3. HeaderBar: wire arrows + "Сьогодні" (hidden when already current); keyboard `Alt+←/→`.
4. Mobile: same header arrows; preserve `activeMobileDay` when switching weeks (if the new week is current → today).

**Acceptance:**

- [ ] Browser back/forward replays navigation correctly, including direction-aware animation later in Task 3
- [ ] Deep link to a far-future week works

### Task 2: Week Jump Calendar (2h)

**Steps:**

1. `WeekJumpPopover.tsx`: Mantine Popover anchored to the week title; `@mantine/dates` `Calendar` with `getDayProps` highlighting the hovered/selected ISO week row; locale follows the app language; Monday-first.
2. Pick a date → `goTo(weekIdFromDate(date))`, close.
3. Header month label inside the title links to `/month/<current>`.

**Acceptance:**

- [ ] Whole-week row highlight on hover (the sketch's "календар?" intent)
- [ ] uk/en month/day names correct

### Task 3: Transition System + Fold (5h)

**Steps:**

1. `transitions/transitions.ts`: `TransitionId = "fold" | "none"`, registry `TRANSITIONS: Record<TransitionId, WeekTransition>` per DESIGN.md; `resolveTransition(settings, prefersReducedMotion)`.
2. `WeekTransitionHost.tsx`: wraps the week surface (board or pager) in `AnimatePresence mode="popLayout"` with `custom={direction}`, child keyed by `weekId`; applies a `perspective` wrapper; the exiting/entering variants come from the active transition.
3. `fold.ts`: exiting page `rotateY` toward the spine (forward: origin left, to ≈ -70°; backward mirrored), an absolutely-positioned shading gradient overlay animating opacity (gives the paper-bend read), entering page settles from a slight counter-angle + small x shift. 450ms, custom cubic-bezier; transform/opacity only.
4. `none.ts`: zero-duration variants.
5. Settings: transition select (saved in `settingsStore.transition`); `reduceMotion` setting + media query override to `none`.
6. Keep DnD safe: transitions only run on `weekId` change, never during a drag (guard via `uiStore.dragging`).
7. Add a short `transitions/curl-notes.md`-style block as comments? - no comments allowed; instead document the `curl` slot in `docs/DESIGN.md` (already done) and leave the registry union ready.

**Acceptance:**

- [ ] Fold reads as a notebook page turn in both directions; Chrome performance trace shows no layout thrash, 60fps on a mid phone
- [ ] Reduced-motion path verified via emulation
- [ ] Spamming arrows doesn't break state (AnimatePresence handles interrupts; final week matches URL)

### Task 4: Carry-over Engine (4h)

**Steps:**

1. `src/services/carryOver.ts`: `runCarryOver(uid)` exactly per DESIGN.md algorithm (query `bucket=="day" && status=="open" && weekId < currentWeekId()` ordered by `weekId`, batched moves to `listId:"tasks"` top with `carriedFrom`, loop until empty). Create the composite index from the console link.
2. Trigger wiring: after auth ready (post `ensureProfile`), and on `visibilitychange → visible` throttled to once/hour (timestamp in `settingsStore`-like volatile module state, not persisted).
3. `TaskCard`: `carriedFrom` renders a soft chip "з W24" (i18n, accent-2 tint); chip clears if the user completes or manually moves the task (`moveTask` nulls `carriedFrom`).
4. Multi-device sanity: simulate two tabs racing (both run carry-over) - converges, no dupes (moves are updates, not copies).
5. Offline start: airplane-mode boot in a new week still carries over from cache; syncs later.

**Acceptance:**

- [ ] Seed open tasks in a past week (temporarily navigate back and add) → reload → they sit on top of "Задачі" with chips
- [ ] Re-running is a no-op; done past tasks never move; future weeks untouched
- [ ] Works offline end-to-end

### Task 5: Month Overview (6h)

**Steps:**

1. `time.ts` additions: `weeksOfMonth(monthId)` (ISO weeks intersecting the month), `monthTitle(monthId)`, `addMonths(monthId, n)`.
2. `monthStore` (or extend a small `monthData` service): for the visible month, subscribe to tasks of its weeks - one query per week id is wasteful; instead a single query `bucket=="day" && weekId in [..]` (Firestore `in` supports ≤ 30 values; a month spans ≤ 6 weeks) → group client-side into per-day open/done counts.
3. `MonthPage.tsx` + `MonthGrid.tsx`: header (title, arrows, Сьогодні), grid rows = weeks (week number gutter, clickable), 7 day cells: date, open-count dot (accent, count), done tick count (done token); today ring; weekend dim; other-month days faded.
4. `MonthDayCell` click → `goTo(week)` and (mobile) set `activeMobileDay`.
5. Mobile layout: tighter cells, week-number column stays tappable.
6. Empty month → gentle Caveat note.

**Acceptance:**

- [ ] Counts match reality for a seeded month; updates live when a task is completed in another tab
- [ ] Boundary months (Dec/Jan, weeks spanning years) render correct week ids and dates
- [ ] Offline render from cache works

### Task 6: Phase Polish (2h)

**Steps:**

1. Navigation affordances: arrow hover states, popover focus trap, `aria-label`s.
2. Verify i18n coverage for all new strings (en+uk), dayjs month names in both.
3. Perf pass: transition layer promotes its own compositing layer (`will-change: transform` only during animation).

**Acceptance:**

- [ ] DoD sweep on desktop + real phone, online + offline
