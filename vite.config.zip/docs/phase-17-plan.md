# SnugWeek - Phase 17: Personalization & Decoration

**Goal:** the heart of the cozy/handmade feel - let people decorate the week spread with stickers, washi tape, and doodles, and make the notebook theirs with a name and a cover. This is the biggest delight-per-effort aesthetic bet in the roadmap.

**Duration:** ~1.5 weeks part-time (~22 h)
**Phase end criterion:** Definition of Done passes 100%.
**Prerequisite reading:** `docs/design-addendum.md` §1 (decorations on the week doc; profile name/cover).

---

## Definition of Done

- [ ] A decoration palette lets the user place stickers, washi strips, and doodles onto the week spread (and onto a specific day); each can be moved, rotated, scaled, and removed
- [ ] Decorations persist per week, render after reload, sync across devices, and work offline; they never block interaction with tasks underneath (a clear edit/view mode or a non-intrusive layer)
- [ ] The decoration set is curated inline-SVG art that looks good and tints sensibly across all 10 themes (incl. mono/noir)
- [ ] The notebook can be given a name (shown in the header/wordmark area and optionally the splash) and a cover style chosen from a few token-built options
- [ ] Placement is comfortable on desktop (drag) and mobile (touch drag + a simple transform control); reduced-motion users get no idle animation
- [ ] Strings en + uk; build/lint/tsc clean; no console errors; performance stays smooth with a spread full of decorations

**Out of scope:** user-uploaded sticker images (curated set only - uploads belong to Attachments), freeform drawing/ink, decoration layering z-order UI beyond add-order, animated stickers.

---

## Task Breakdown

### Task 1: Decoration Model & Asset Registry (4h)

**Steps:**

1. `data/decorations.ts`: a curated registry of inline-SVG assets grouped by kind (`sticker`, `washi`, `doodle`), each with an id; design them to use `currentColor`/token tints where it makes sense so they harmonize with themes. One `DecorationArt` component resolves an asset id → SVG (same pattern as `TrackerIcon`).
2. Data: `decorations: Decoration[]` on the week doc per addendum §1 (`id`, `kind`, `asset`, `target: "week"|day`, `x`, `y`, `rotation`, `scale`). `weeksRepo` writers: `addDecoration`, `updateDecoration`, `removeDecoration` (the array is bounded; write the whole field or use arrayUnion/remove carefully with full objects).
3. `firestore.rules`: validate decoration shape + a sane cap on count.

**Acceptance:**

- [ ] Adding/updating/removing a decoration round-trips offline; the registry renders all assets

### Task 2: Decoration Layer & Placement (6h)

**Steps:**

1. `shell/components/decor/DecorationLayer.tsx`: an absolutely-positioned layer over the week spread rendering placed decorations by `x/y/rotation/scale` (percentages relative to the spread so it scales across viewports). A view mode (decorations are non-interactive, pointer-events pass through to tasks) and an **edit mode** (decorations become draggable/selectable).
2. Placement: in edit mode, dragging moves a decoration (pointer + touch); a small transform control (rotate/scale handles or a compact popover with sliders) adjusts it; a delete affordance removes it. Desktop drag + mobile touch both smooth.
3. Add flow: a decoration palette (a sheet/panel from the week toolbar) - pick a kind + asset → it drops onto the spread (or the selected day) at a default position for the user to nudge.
4. Persistence on drop/transform end (debounced); reduced-motion disables any idle wiggle.

**Acceptance:**

- [ ] Place/move/rotate/scale/remove works on desktop + phone; view mode never blocks task interaction; many decorations stay smooth

### Task 3: Day-Targeted Decorations & Polish (3h)

**Steps:**

1. Allow targeting a specific day (decoration `target` = ISO day) so a sticker can live in a day column; render within/over that column and keep its relative position on resize and across the desktop/mobile arrangements.
2. Tasteful constraints: clamp positions within the spread; sensible min/max scale; snap rotation to nice angles optionally.
3. Theme tint check for every asset in light + dark themes.

**Acceptance:**

- [ ] Day-targeted decorations stay with their day across layouts; assets read well in all themes

### Task 4: Notebook Name & Cover (5h)

**Steps:**

1. Profile: `notebookName: string | null`, `coverStyle: string | null` (addendum §1) + `profileRepo` writers + `profileStore` mirror.
2. Settings → Вигляд: a name field and a cover picker (a few cover styles built purely from tokens - e.g. paper + accent motifs; cards like the theme picker). Show the name in the header/wordmark area; optionally feed it to the boot splash via the existing `snugweek-theme`-style cache (a separate small key) so a returning user sees "<name>" pre-paint.
3. A gentle personalized greeting using the name where it fits (e.g. an empty-week line) - optional, localized.

**Acceptance:**

- [ ] Name + cover persist and sync; the name appears where intended; covers read well in all themes

### Task 5: i18n, A11y & Sweep (4h)

**Steps:**

1. en + uk for palette, edit-mode, name/cover, greeting.
2. A11y: edit mode operable by keyboard where feasible (select + arrow-nudge), decorations have accessible names, the palette is navigable; ensure the decoration layer doesn't trap focus in view mode.
3. Performance pass with a spread full of decorations (transform-only, no layout thrash); real-phone test of placement; offline verification.

**Acceptance:**

- [ ] Full DoD passes desktop + phone, light + dark; performance smooth; i18n missing-key warnings zero
